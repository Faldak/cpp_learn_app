"""
ai_client.py
============
Thin wrapper around the Groq API (OpenAI-compatible chat completions).

Design goals (spec sections 1 & 6):
  - API key NEVER hardcoded. Read from OS keychain via `keyring`, with an
    env var (`GROQ_API_KEY`) fallback for power users / CI.
  - Configurable model with a sensible default; gracefully report when the
    configured model has been deprecated by Groq.
  - Retry with exponential backoff on HTTP 429 (rate limits).
  - Hard timeout; on any failure return a friendly Russian fallback string,
    NEVER raise into the UI.
  - Log every request/response locally (timestamps) to logs/ai.log.
  - A Russian-language output validator: if the model drifts into English,
    retry once with a stronger reminder, then fall back to a static RU message.

The AI is ONLY an explainer. It never decides task correctness.
"""

from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

import config

# requests is in requirements.txt; import lazily so the rest of the app works
# even if it's not yet installed.
try:
    import requests  # type: ignore
except Exception:  # pragma: no cover
    requests = None  # type: ignore

try:
    import keyring  # type: ignore
except Exception:  # pragma: no cover
    keyring = None  # type: ignore


KEYRING_SERVICE = "cpp_learning_app"
KEYRING_USER = "groq_api_key"

# --- Static Russian fallbacks ------------------------------------------------
FALLBACK_TIMEOUT = (
    "Не удалось получить ответ от ИИ-помощника. Попробуй ещё раз через минуту, "
    "либо посмотри объяснение в теории урока."
)
FALLBACK_NO_KEY = (
    "ИИ-помощник пока не настроен (нет ключа). Это не страшно — приложение "
    "полностью работает и без него. Можешь добавить ключ Groq в настройках, "
    "если хочешь получать подсказки от ИИ."
)
FALLBACK_NOT_RUSSIAN = (
    "ИИ-помощник сейчас ответил не на русском языке. Попробуй нажать кнопку ещё раз."
)
FALLBACK_MODEL_GONE = (
    "Выбранная модель ИИ больше недоступна у Groq. Открой настройки и выбери "
    "другую модель из списка доступных."
)


@dataclass
class AIResult:
    ok: bool
    text: str
    error_kind: str = ""  # "", "no_key", "timeout", "rate_limit", "model_gone", "not_russian", "other"


# ---------------------------------------------------------------------------
# API key storage (keyring, with env fallback)
# ---------------------------------------------------------------------------
def get_api_key() -> Optional[str]:
    import os

    if keyring is not None:
        try:
            k = keyring.get_password(KEYRING_SERVICE, KEYRING_USER)
            if k:
                return k
        except Exception:
            pass
    return os.environ.get("GROQ_API_KEY") or None


def set_api_key(key: str) -> bool:
    if keyring is not None:
        try:
            keyring.set_password(KEYRING_SERVICE, KEYRING_USER, key)
            return True
        except Exception:
            pass
    # If keyring unavailable, we don't write plaintext anywhere; tell caller.
    return False


def delete_api_key() -> bool:
    """Remove the stored key from the OS keychain. Returns True if removed
    (or there was nothing to remove). An env-var key cannot be deleted here."""
    if keyring is not None:
        try:
            existing = keyring.get_password(KEYRING_SERVICE, KEYRING_USER)
            if existing:
                keyring.delete_password(KEYRING_SERVICE, KEYRING_USER)
            return True
        except Exception:
            return False
    return True


def key_in_keyring() -> bool:
    """True only if a key is stored in the OS keychain (not just an env var)."""
    if keyring is None:
        return False
    try:
        return bool(keyring.get_password(KEYRING_SERVICE, KEYRING_USER))
    except Exception:
        return False


def is_configured() -> bool:
    return bool(get_api_key())


def get_model() -> str:
    try:
        import progress_db
        return progress_db.get_setting("ai_model", config.DEFAULT_AI_MODEL) or config.DEFAULT_AI_MODEL
    except Exception:
        return config.DEFAULT_AI_MODEL


# ---------------------------------------------------------------------------
# System prompt
# ---------------------------------------------------------------------------
SYSTEM_PROMPT = """You are a friendly C++ teaching assistant for a COMPLETE beginner who has zero programming experience.

CRITICAL LANGUAGE RULE — REPEAT: YOUR ENTIRE ANSWER MUST BE IN RUSSIAN.
Even though the code, compiler errors, and technical terms you are shown are in English, you MUST write your whole response in Russian. Technical keywords and identifiers (like `int`, `nullptr`, `segmentation fault`, function/variable names) may stay in their original English/technical form — that is normal in Russian programming education — but every sentence, explanation, and all grammar around them MUST be Russian. If you find yourself writing an English sentence, STOP and rewrite it in Russian. ANSWER ONLY IN RUSSIAN.

TEACHING STYLE:
- Explain like to a first-grader: short sentences, simple words, everyday analogies (a variable is like a labeled box, etc.).
- Define any technical term the moment you use it, in plain Russian words.
- Keep it SHORT: 3-6 sentences for a typical explanation. Longer only if the user explicitly asks for more detail.

HARD RULES:
- You must NEVER declare a task "correct" or "incorrect". That has already been decided by deterministic code. You ONLY explain the result you are given. Never re-judge it.
- Do NOT paste a full corrected solution UNLESS the user's message explicitly asks to see the answer (Russian phrases like "покажи решение", "дай ответ", "покажи код целиком"). Otherwise, explain the concept and point toward where the problem is, but let the student write the fix themselves.
- If you are unsure, or the question is outside C++ teaching, say so honestly in Russian rather than guessing.

Remember: respond ONLY in Russian."""


def build_messages(user_content: str, *, context: Optional[str] = None,
                   stronger_russian: bool = False) -> list[dict]:
    sys_prompt = SYSTEM_PROMPT
    if stronger_russian:
        sys_prompt += ("\n\nREMINDER: Your previous answer drifted into English. "
                       "This is NOT allowed. Write the ENTIRE answer in Russian only.")
    messages = [{"role": "system", "content": sys_prompt}]
    if context:
        messages.append({"role": "system", "content": f"Контекст урока:\n{context}"})
    messages.append({"role": "user", "content": user_content})
    return messages


# ---------------------------------------------------------------------------
# Russian-output validator
# ---------------------------------------------------------------------------
_EN_STOPWORDS = {
    "the", "and", "is", "are", "you", "your", "this", "that", "with", "for",
    "have", "should", "code", "error", "function", "variable", "line", "here",
    "because", "when", "which", "what", "make", "sure", "need", "let", "will",
}


def looks_russian(text: str) -> bool:
    """Heuristic: enough Cyrillic, and not dominated by English stop-words."""
    if not text.strip():
        return False
    # Strip code blocks so C++ keywords don't count against us.
    no_code = re.sub(r"`[^`]*`|```.*?```", " ", text, flags=re.DOTALL)
    cyr = len(re.findall(r"[а-яёА-ЯЁ]", no_code))
    lat_words = re.findall(r"\b[a-zA-Z]{2,}\b", no_code)
    en_stop = sum(1 for w in lat_words if w.lower() in _EN_STOPWORDS)
    if cyr < 10:
        return False
    # If there are many English stop-words relative to Cyrillic, it drifted.
    if en_stop >= 4 and en_stop * 8 > cyr:
        return False
    return True


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
def _log(kind: str, payload: object) -> None:
    try:
        config.ensure_dirs()
        with open(config.AI_LOG_FILE, "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now().isoformat(timespec='seconds')}] {kind}: "
                    f"{json.dumps(payload, ensure_ascii=False)[:4000]}\n")
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Core request
# ---------------------------------------------------------------------------
def _post_chat(messages: list[dict], *, model: str, max_tokens: int = 500) -> AIResult:
    if requests is None:
        return AIResult(False, FALLBACK_TIMEOUT, "other")
    key = get_api_key()
    if not key:
        return AIResult(False, FALLBACK_NO_KEY, "no_key")

    headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
    body = {"model": model, "messages": messages, "temperature": 0.3, "max_tokens": max_tokens}

    backoff = 1.0
    last_err = "other"
    for attempt in range(config.AI_MAX_RETRIES):
        try:
            _log("request", {"model": model, "attempt": attempt})
            resp = requests.post(
                config.GROQ_CHAT_ENDPOINT, headers=headers, json=body,
                timeout=config.AI_REQUEST_TIMEOUT_SECONDS,
            )
        except Exception as e:
            _log("exception", str(e))
            last_err = "timeout"
            time.sleep(backoff)
            backoff *= 2
            continue

        if resp.status_code == 429:
            _log("rate_limit", resp.text[:500])
            last_err = "rate_limit"
            time.sleep(backoff)
            backoff *= 2
            continue

        if resp.status_code == 404 or (
            resp.status_code == 400 and "model" in resp.text.lower()
            and ("decommission" in resp.text.lower() or "does not exist" in resp.text.lower())
        ):
            _log("model_gone", resp.text[:500])
            return AIResult(False, FALLBACK_MODEL_GONE, "model_gone")

        if resp.status_code != 200:
            _log("http_error", {"status": resp.status_code, "body": resp.text[:500]})
            last_err = "other"
            time.sleep(backoff)
            backoff *= 2
            continue

        try:
            data = resp.json()
            text = data["choices"][0]["message"]["content"].strip()
            _log("response", text[:2000])
            return AIResult(True, text, "")
        except Exception as e:
            _log("parse_error", str(e))
            return AIResult(False, FALLBACK_TIMEOUT, "other")

    return AIResult(False, FALLBACK_TIMEOUT if last_err != "rate_limit" else FALLBACK_TIMEOUT, last_err)


# ---------------------------------------------------------------------------
# Public helpers
# ---------------------------------------------------------------------------
def ask(user_content: str, *, context: Optional[str] = None) -> AIResult:
    """Ask the assistant, enforcing Russian output (one retry on drift)."""
    try:
        import progress_db
        progress_db.record_ai_call()
    except Exception:
        pass

    model = get_model()
    res = _post_chat(build_messages(user_content, context=context), model=model)
    if not res.ok:
        return res
    if looks_russian(res.text):
        return res
    # Drifted into English -> retry once with a stronger reminder.
    res2 = _post_chat(
        build_messages(user_content, context=context, stronger_russian=True),
        model=model,
    )
    if res2.ok and looks_russian(res2.text):
        return res2
    return AIResult(False, FALLBACK_NOT_RUSSIAN, "not_russian")


def explain_compiler_error(*, source: str, raw_error: str, lesson_context: str = "") -> AIResult:
    user = (
        "Ученик написал такой код на C++:\n\n```cpp\n" + source[:4000] + "\n```\n\n"
        "Компилятор выдал такую ошибку:\n\n```\n" + raw_error[:2000] + "\n```\n\n"
        "Объясни простыми словами, что не так и куда смотреть, но НЕ пиши готовое "
        "исправление целиком."
    )
    return ask(user, context=lesson_context or None)


def explain_task_result(*, summary: str, lesson_context: str = "") -> AIResult:
    user = (
        "Вот уже посчитанный программой результат проверки задания (НЕ оценивай "
        "заново, только поясни его простыми словами на русском):\n\n" + summary[:3000]
    )
    return ask(user, context=lesson_context or None)


def test_key(key: str, model: Optional[str] = None) -> AIResult:
    """Make one trivial call to verify a key works (used in onboarding)."""
    if requests is None:
        return AIResult(False, "Модуль requests не установлен.", "other")
    headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
    body = {
        "model": model or config.DEFAULT_AI_MODEL,
        "messages": [{"role": "user", "content": "Ответь одним словом по-русски: привет"}],
        "max_tokens": 10,
    }
    try:
        resp = requests.post(config.GROQ_CHAT_ENDPOINT, headers=headers, json=body, timeout=15)
    except Exception as e:
        return AIResult(False, f"Ошибка соединения: {e}", "timeout")
    if resp.status_code == 200:
        return AIResult(True, "Ключ работает ✅", "")
    if resp.status_code == 401:
        return AIResult(False, "Ключ неверный или недействителен.", "other")
    if resp.status_code == 429:
        return AIResult(False, "Слишком много запросов — попробуй позже.", "rate_limit")
    return AIResult(False, f"Groq вернул ошибку {resp.status_code}.", "other")


if __name__ == "__main__":
    print("configured:", is_configured(), "| model:", get_model())
    print("looks_russian('Привет, это переменная'):", looks_russian("Привет, это переменная — как коробка."))
    print("looks_russian(english):", looks_russian("You should check the variable on this line because it is wrong"))
