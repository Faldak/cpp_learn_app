"""
progress_db.py
==============
SQLite-backed progress storage. Pure data aggregation — NO AI anywhere in this
module (per spec section 2). All functions are safe to call frequently; the
dashboard reads exclusively from here.

Schema (spec section 5):
  - lessons_progress
  - task_attempts
  - task_status
  - error_log
  - daily_activity
  - app_settings  (key/value; raw Groq key is NOT stored here, only a flag)

The raw Groq API key lives in the OS keychain via `keyring` (see ai_client.py).
"""

from __future__ import annotations

import json
import sqlite3
import threading
from contextlib import contextmanager
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Iterable, Optional

import config

_LOCK = threading.Lock()


# ---------------------------------------------------------------------------
# Connection / schema
# ---------------------------------------------------------------------------
def _connect(db_path: Optional[Path] = None) -> sqlite3.Connection:
    config.ensure_dirs()
    path = str(db_path or config.DB_PATH)
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA foreign_keys=ON;")
    return conn


_SCHEMA = """
CREATE TABLE IF NOT EXISTS lessons_progress (
    lesson_id          TEXT PRIMARY KEY,
    status             TEXT NOT NULL DEFAULT 'not_started',
    first_opened_at    TEXT,
    completed_at       TEXT,
    time_spent_seconds INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS task_attempts (
    attempt_id         INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id            TEXT NOT NULL,
    lesson_id          TEXT,
    submitted_at       TEXT NOT NULL,
    passed             INTEGER NOT NULL,
    submitted_code     TEXT,
    compiler_errors    TEXT,
    rubric_results_json TEXT,
    attempt_number     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS task_status (
    task_id        TEXT PRIMARY KEY,
    lesson_id      TEXT,
    best_status    TEXT NOT NULL DEFAULT 'not_attempted',
    passed_at      TEXT,
    total_attempts INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS error_log (
    id                     INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp              TEXT NOT NULL,
    task_id                TEXT,
    raw_error_text         TEXT,
    matched_tier1_pattern_id TEXT,
    used_ai_fallback       INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS daily_activity (
    date                  TEXT PRIMARY KEY,
    lessons_opened_count  INTEGER NOT NULL DEFAULT 0,
    tasks_attempted_count INTEGER NOT NULL DEFAULT 0,
    tasks_passed_count    INTEGER NOT NULL DEFAULT 0,
    total_time_seconds    INTEGER NOT NULL DEFAULT 0,
    ai_calls_made_count   INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS app_settings (
    key   TEXT PRIMARY KEY,
    value TEXT
);

CREATE INDEX IF NOT EXISTS idx_attempts_task ON task_attempts(task_id);
CREATE INDEX IF NOT EXISTS idx_errorlog_pattern ON error_log(matched_tier1_pattern_id);
"""


def init_db(db_path: Optional[Path] = None) -> None:
    with _LOCK, _connect(db_path) as conn:
        conn.executescript(_SCHEMA)
        conn.commit()


@contextmanager
def _cursor(db_path: Optional[Path] = None):
    with _LOCK:
        conn = _connect(db_path)
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _today() -> str:
    return date.today().isoformat()


# ---------------------------------------------------------------------------
# Lessons
# ---------------------------------------------------------------------------
def open_lesson(lesson_id: str) -> None:
    """Mark a lesson opened; set in_progress and record first_opened_at once."""
    with _cursor() as conn:
        row = conn.execute(
            "SELECT lesson_id, status FROM lessons_progress WHERE lesson_id=?",
            (lesson_id,),
        ).fetchone()
        if row is None:
            conn.execute(
                "INSERT INTO lessons_progress(lesson_id,status,first_opened_at) "
                "VALUES(?,?,?)",
                (lesson_id, "in_progress", _now()),
            )
        elif row["status"] == "not_started":
            conn.execute(
                "UPDATE lessons_progress SET status='in_progress', "
                "first_opened_at=COALESCE(first_opened_at,?) WHERE lesson_id=?",
                (_now(), lesson_id),
            )
        _bump_daily(conn, lessons_opened=1)
        _set_setting(conn, "last_opened_lesson_id", lesson_id)


def complete_lesson(lesson_id: str) -> None:
    with _cursor() as conn:
        conn.execute(
            "INSERT INTO lessons_progress(lesson_id,status,completed_at) VALUES(?, 'completed', ?) "
            "ON CONFLICT(lesson_id) DO UPDATE SET status='completed', completed_at=?",
            (lesson_id, _now(), _now()),
        )


def add_lesson_time(lesson_id: str, seconds: int) -> None:
    if seconds <= 0:
        return
    with _cursor() as conn:
        conn.execute(
            "INSERT INTO lessons_progress(lesson_id,status,time_spent_seconds) "
            "VALUES(?, 'in_progress', ?) "
            "ON CONFLICT(lesson_id) DO UPDATE SET "
            "time_spent_seconds=time_spent_seconds+?",
            (lesson_id, seconds, seconds),
        )
        _bump_daily(conn, total_time=seconds)


def get_lesson_status(lesson_id: str) -> str:
    with _cursor() as conn:
        row = conn.execute(
            "SELECT status FROM lessons_progress WHERE lesson_id=?", (lesson_id,)
        ).fetchone()
        return row["status"] if row else "not_started"


# ---------------------------------------------------------------------------
# Task attempts / status
# ---------------------------------------------------------------------------
def record_attempt(
    *,
    task_id: str,
    lesson_id: Optional[str],
    passed: bool,
    submitted_code: str,
    compiler_errors: Optional[str] = None,
    rubric_results: Optional[dict | list] = None,
) -> int:
    """Insert a task attempt, update task_status + daily_activity. Returns attempt_number."""
    with _cursor() as conn:
        prev = conn.execute(
            "SELECT total_attempts FROM task_status WHERE task_id=?", (task_id,)
        ).fetchone()
        attempt_number = (prev["total_attempts"] if prev else 0) + 1

        conn.execute(
            "INSERT INTO task_attempts(task_id,lesson_id,submitted_at,passed,"
            "submitted_code,compiler_errors,rubric_results_json,attempt_number) "
            "VALUES(?,?,?,?,?,?,?,?)",
            (
                task_id,
                lesson_id,
                _now(),
                1 if passed else 0,
                submitted_code,
                compiler_errors,
                json.dumps(rubric_results, ensure_ascii=False) if rubric_results is not None else None,
                attempt_number,
            ),
        )

        # Upsert task_status
        best_status = "passed" if passed else "failed"
        existing = conn.execute(
            "SELECT best_status FROM task_status WHERE task_id=?", (task_id,)
        ).fetchone()
        if existing and existing["best_status"] == "passed":
            best_status = "passed"  # never downgrade a previously-passed task
        conn.execute(
            "INSERT INTO task_status(task_id,lesson_id,best_status,passed_at,total_attempts) "
            "VALUES(?,?,?,?,1) "
            "ON CONFLICT(task_id) DO UPDATE SET best_status=?, "
            "passed_at=COALESCE(passed_at, ?), total_attempts=total_attempts+1",
            (
                task_id, lesson_id, best_status,
                _now() if passed else None,
                best_status,
                _now() if passed else None,
            ),
        )

        _bump_daily(conn, tasks_attempted=1, tasks_passed=1 if passed else 0)
        return attempt_number


def get_task_status(task_id: str) -> dict:
    with _cursor() as conn:
        row = conn.execute(
            "SELECT best_status,total_attempts,passed_at FROM task_status WHERE task_id=?",
            (task_id,),
        ).fetchone()
        if not row:
            return {"best_status": "not_attempted", "total_attempts": 0, "passed_at": None}
        return dict(row)


def get_task_attempt_count(task_id: str) -> int:
    return get_task_status(task_id)["total_attempts"]


def get_attempts(task_id: str) -> list[dict]:
    with _cursor() as conn:
        rows = conn.execute(
            "SELECT * FROM task_attempts WHERE task_id=? ORDER BY attempt_number",
            (task_id,),
        ).fetchall()
        return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# Error log
# ---------------------------------------------------------------------------
def log_error(
    *,
    task_id: Optional[str],
    raw_error_text: str,
    matched_tier1_pattern_id: Optional[str],
    used_ai_fallback: bool,
) -> None:
    with _cursor() as conn:
        conn.execute(
            "INSERT INTO error_log(timestamp,task_id,raw_error_text,"
            "matched_tier1_pattern_id,used_ai_fallback) VALUES(?,?,?,?,?)",
            (_now(), task_id, raw_error_text[:8000], matched_tier1_pattern_id,
             1 if used_ai_fallback else 0),
        )


def top_error_patterns(limit: int = 5) -> list[dict]:
    """Most frequent compile-error patterns.

    Returns dicts with keys: pattern_id, count, title_ru (human Russian title
    resolved from the error dictionary; falls back to the id if unknown).
    """
    import error_dictionary  # local import to avoid circular import at module load
    with _cursor() as conn:
        rows = conn.execute(
            "SELECT matched_tier1_pattern_id AS pattern_id, COUNT(*) AS cnt "
            "FROM error_log WHERE matched_tier1_pattern_id IS NOT NULL "
            "GROUP BY matched_tier1_pattern_id ORDER BY cnt DESC LIMIT ?",
            (limit,),
        ).fetchall()
        out = []
        for r in rows:
            pid = r["pattern_id"]
            title = error_dictionary.pattern_title(pid) or pid
            out.append({"pattern_id": pid, "count": r["cnt"], "title_ru": title})
        return out


# ---------------------------------------------------------------------------
# Daily activity
# ---------------------------------------------------------------------------
def _bump_daily(
    conn: sqlite3.Connection,
    *,
    lessons_opened: int = 0,
    tasks_attempted: int = 0,
    tasks_passed: int = 0,
    total_time: int = 0,
    ai_calls: int = 0,
) -> None:
    conn.execute(
        "INSERT INTO daily_activity(date,lessons_opened_count,tasks_attempted_count,"
        "tasks_passed_count,total_time_seconds,ai_calls_made_count) VALUES(?,?,?,?,?,?) "
        "ON CONFLICT(date) DO UPDATE SET "
        "lessons_opened_count=lessons_opened_count+?, "
        "tasks_attempted_count=tasks_attempted_count+?, "
        "tasks_passed_count=tasks_passed_count+?, "
        "total_time_seconds=total_time_seconds+?, "
        "ai_calls_made_count=ai_calls_made_count+?",
        (_today(), lessons_opened, tasks_attempted, tasks_passed, total_time, ai_calls,
         lessons_opened, tasks_attempted, tasks_passed, total_time, ai_calls),
    )


def record_ai_call() -> None:
    with _cursor() as conn:
        _bump_daily(conn, ai_calls=1)


def get_day(d: Optional[str] = None) -> dict:
    d = d or _today()
    with _cursor() as conn:
        row = conn.execute("SELECT * FROM daily_activity WHERE date=?", (d,)).fetchone()
        if not row:
            return {
                "date": d, "lessons_opened_count": 0, "tasks_attempted_count": 0,
                "tasks_passed_count": 0, "total_time_seconds": 0, "ai_calls_made_count": 0,
            }
        return dict(row)


def get_last_n_days(n: int = 7) -> list[dict]:
    """Return list of dicts for the last n calendar days (oldest first), zero-filled."""
    today = date.today()
    out: list[dict] = []
    with _cursor() as conn:
        for i in range(n - 1, -1, -1):
            d = (today - timedelta(days=i)).isoformat()
            row = conn.execute("SELECT * FROM daily_activity WHERE date=?", (d,)).fetchone()
            out.append(dict(row) if row else {
                "date": d, "lessons_opened_count": 0, "tasks_attempted_count": 0,
                "tasks_passed_count": 0, "total_time_seconds": 0, "ai_calls_made_count": 0,
            })
    return out


def current_streak() -> int:
    """Consecutive days (ending today or yesterday) with >=1 task attempted."""
    with _cursor() as conn:
        rows = conn.execute(
            "SELECT date FROM daily_activity WHERE tasks_attempted_count>0"
        ).fetchall()
    active_days = {r["date"] for r in rows}
    if not active_days:
        return 0
    streak = 0
    cur = date.today()
    # allow streak to count if today not yet active but yesterday was
    if cur.isoformat() not in active_days:
        cur = cur - timedelta(days=1)
    while cur.isoformat() in active_days:
        streak += 1
        cur -= timedelta(days=1)
    return streak


def recent_daily_task_average(days: int = 7) -> float:
    data = get_last_n_days(days)
    if not data:
        return 0.0
    return sum(d["tasks_passed_count"] for d in data) / len(data)


# ---------------------------------------------------------------------------
# Overall progress
# ---------------------------------------------------------------------------
def passed_task_ids() -> set[str]:
    with _cursor() as conn:
        rows = conn.execute(
            "SELECT task_id FROM task_status WHERE best_status='passed'"
        ).fetchall()
        return {r["task_id"] for r in rows}


def count_passed_tasks() -> int:
    return len(passed_task_ids())


# ---------------------------------------------------------------------------
# App settings (key/value)
# ---------------------------------------------------------------------------
def _set_setting(conn: sqlite3.Connection, key: str, value: str) -> None:
    conn.execute(
        "INSERT INTO app_settings(key,value) VALUES(?,?) "
        "ON CONFLICT(key) DO UPDATE SET value=?",
        (key, value, value),
    )


def set_setting(key: str, value: str) -> None:
    with _cursor() as conn:
        _set_setting(conn, key, value)


def get_setting(key: str, default: Optional[str] = None) -> Optional[str]:
    with _cursor() as conn:
        row = conn.execute("SELECT value FROM app_settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default


def is_onboarding_completed() -> bool:
    return get_setting("onboarding_completed", "0") == "1"


def set_onboarding_completed(done: bool = True) -> None:
    set_setting("onboarding_completed", "1" if done else "0")


# ---------------------------------------------------------------------------
# Resume point
# ---------------------------------------------------------------------------
def get_resume_point(ordered_lesson_ids: Iterable[str]) -> Optional[str]:
    """
    Return the lesson to continue from:
      1) the most recently opened in_progress lesson, else
      2) the first not_started/not-yet-touched lesson in curriculum order, else
      3) the last lesson (course finished) or None if list empty.
    """
    ordered = list(ordered_lesson_ids)
    if not ordered:
        return None
    last_opened = get_setting("last_opened_lesson_id")
    if last_opened and get_lesson_status(last_opened) == "in_progress":
        return last_opened
    with _cursor() as conn:
        statuses = {
            r["lesson_id"]: r["status"]
            for r in conn.execute("SELECT lesson_id,status FROM lessons_progress").fetchall()
        }
    for lid in ordered:
        if statuses.get(lid, "not_started") != "completed":
            return lid
    return ordered[-1]


if __name__ == "__main__":
    # Quick round-trip smoke test against a temp DB.
    import tempfile

    tmp = Path(tempfile.mktemp(suffix=".db"))
    init_db(tmp)
    config.DB_PATH = tmp  # type: ignore
    open_lesson("block1_lesson1")
    n = record_attempt(task_id="block1_task1", lesson_id="block1_lesson1",
                       passed=True, submitted_code="int main(){}")
    print("attempt#", n, "passed:", count_passed_tasks(),
          "resume:", get_resume_point(["block1_lesson1", "block1_lesson2"]),
          "streak:", current_streak())
