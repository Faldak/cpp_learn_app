"""
error_dictionary.py
===================
Tier-1 compiler-error explanation (NO AI). A list of (regex -> friendly Russian
explanation template) patterns for the most common beginner g++/clang errors.

Each pattern can reference named capture groups from its regex inside the
Russian template using {group_name} placeholders (e.g. {line}, {name}).

Public API:
    match_error(stderr: str) -> Optional[ErrorMatch]

`match_error` returns the FIRST matching pattern (patterns are ordered most
specific -> most general). If nothing matches, returns None and the caller
falls back to the AI (Tier 2).

All explanations are intentionally beginner-friendly ("first-grader" style):
short sentences, an everyday analogy where useful, and a concrete nudge toward
the fix WITHOUT writing the full corrected code.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional


@dataclass
class ErrorMatch:
    pattern_id: str
    title_ru: str
    explanation_ru: str


# Each entry: (id, title_ru, compiled-regex, template_ru)
# The regex is matched against the FULL stderr (re.search, multiline, IGNORECASE
# only where it helps). Use named groups (?P<name>...) for placeholders.
_RAW_PATTERNS: list[tuple[str, str, str, str]] = [
    # --- Special internal sentinels from compiler_service ---------------------
    (
        "no_compiler",
        "Компилятор не найден",
        r"^NO_COMPILER$",
        "На твоём компьютере не найден компилятор C++ (g++). Без него код "
        "невозможно запустить. Открой настройки и пройди установку компилятора — "
        "это как кухонная плита: без неё нельзя приготовить блюдо из рецепта.",
    ),
    (
        "compile_timeout",
        "Компиляция зависла",
        r"^COMPILE_TIMEOUT$",
        "Компиляция длилась слишком долго и была остановлена. Обычно это значит, "
        "что в коде есть что-то очень тяжёлое. Попробуй упростить программу и "
        "запустить снова.",
    ),
    # --- Missing semicolon ----------------------------------------------------
    (
        "missing_semicolon",
        "Забыта точка с запятой",
        r"(?P<file>[^\s:]+):(?P<line>\d+):\d+:\s*error:\s*expected ['`]?;['`]?",
        "Похоже, в строке {line} не хватает точки с запятой `;`. В C++ почти "
        "каждая команда должна заканчиваться `;` — это как точка в конце "
        "предложения. Посмотри на строку {line} и строку перед ней.",
    ),
    (
        "expected_token",
        "Пропущен символ",
        r"(?P<file>[^\s:]+):(?P<line>\d+):\d+:\s*error:\s*expected (?P<what>['`][^'`]+['`][^\n]*)",
        "В строке {line} компилятор ожидал увидеть {what}, но не нашёл. Часто это "
        "пропущенная скобка, точка с запятой или фигурная скобка. Проверь эту "
        "строку и соседние.",
    ),
    # --- Missing std:: (checked before generic 'not declared') ---------------
    (
        "missing_std_prefix",
        "Забыт префикс std::",
        r"['`](?:std::)?(?P<name>cout|cin|endl|string|vector|map|set|sort|to_string|getline)['`] (?:was not declared|undeclared|not declared)",
        "Имя `{name}` живёт в «коробке» с названием `std`. Нужно писать "
        "`std::{name}` (например, `std::cout`), либо добавить строку "
        "`using namespace std;` после `#include`. И не забудь подключить нужный "
        "заголовок, например `#include <iostream>` для ввода-вывода.",
    ),
    # --- Undeclared identifier ------------------------------------------------
    (
        "undeclared_identifier",
        "Имя не объявлено",
        r"(?P<file>[^\s:]+):(?P<line>\d+):\d+:\s*error:\s*['`](?P<name>[^'`]+)['`] was not declared",
        "В строке {line} ты используешь имя `{name}`, но компилятор о нём ничего "
        "не знает. Возможно, ты опечатался в названии, либо забыл объявить "
        "переменную раньше, либо не подключил нужный `#include`. Имя нужно сначала "
        "«представить», прежде чем им пользоваться.",
    ),
    (
        "undeclared_use",
        "Имя не объявлено в этой области",
        r"use of undeclared identifier ['`](?P<name>[^'`]+)['`]",
        "Имя `{name}` используется, но нигде не объявлено. Проверь, не опечатка ли "
        "это, и объявлена ли переменная до того места, где ты её применяешь.",
    ),
    # --- Missing include / iostream ------------------------------------------
    (
        "missing_iostream",
        "Не подключён iostream",
        r"['`](?:std::)?(?:cout|cin|endl)['`].*(?:not declared|undeclared|no member)",
        "Чтобы пользоваться вводом и выводом (`cout`, `cin`), в самом верху файла "
        "нужна строка `#include <iostream>`. Это как взять нужный инструмент с "
        "полки перед работой.",
    ),
    (
        "fatal_no_such_file",
        "Заголовок не найден",
        r"fatal error:\s*(?P<name>[^\s:]+):\s*No such file",
        "Компилятор не смог найти файл `{name}`, который ты подключаешь через "
        "`#include`. Проверь, правильно ли написано имя. Если это библиотека "
        "(например, SFML), её, возможно, нужно сначала установить.",
    ),
    # --- = vs == --------------------------------------------------------------
    (
        "assignment_in_condition",
        "Возможно, = вместо ==",
        r"warning:\s*suggest parentheses around assignment used as truth value|"
        r"using the result of an assignment as a condition",
        "Внутри условия (`if`, `while`) ты, возможно, написал один знак `=` вместо "
        "двух `==`. Один `=` — это «присвоить значение», а два `==` — это "
        "«сравнить». Для проверки равенства нужно `==`.",
    ),
    # --- Mismatched brackets / braces ----------------------------------------
    (
        "expected_closing_brace",
        "Не закрыта фигурная скобка",
        r"expected ['`]}['`]|expected declaration before ['`]}['`]| at end of input",
        "Где-то не хватает закрывающей фигурной скобки `}` (или их количество не "
        "совпадает). Каждой открытой `{` должна соответствовать своя `}`. Проверь, "
        "что все блоки (функции, циклы, условия) закрыты.",
    ),
    (
        "expected_closing_paren",
        "Не закрыта круглая скобка",
        r"expected ['`]\)['`]",
        "Похоже, не закрыта круглая скобка `)`. Посчитай открывающие `(` и "
        "закрывающие `)` — их должно быть поровну.",
    ),
    # --- Type mismatch --------------------------------------------------------
    (
        "invalid_conversion",
        "Несовместимые типы",
        r"(?P<file>[^\s:]+):(?P<line>\d+):\d+:\s*error:\s*(?:invalid conversion|cannot convert)",
        "В строке {line} ты пытаешься положить значение одного типа туда, где "
        "ожидается другой тип (например, текст в число). Это как наливать суп в "
        "коробку для карандашей. Проверь типы переменных в этой строке.",
    ),
    (
        "no_match_assignment",
        "Несовпадение типов при присваивании",
        r"no match for ['`]operator=['`]|no known conversion",
        "Типы слева и справа от `=` не совпадают, и компилятор не знает, как одно "
        "превратить в другое. Проверь, что ты присваиваешь значение подходящего "
        "типа.",
    ),
    # --- Function call argument count ----------------------------------------
    (
        "too_few_args",
        "Слишком мало аргументов",
        r"too few arguments to function",
        "Ты вызвал функцию, передав ей меньше значений (аргументов), чем она "
        "ожидает. Посмотри, как функция объявлена, и передай все нужные значения.",
    ),
    (
        "too_many_args",
        "Слишком много аргументов",
        r"too many arguments to function",
        "Ты передал функции больше значений, чем она принимает. Сверься с её "
        "объявлением и убери лишние аргументы.",
    ),
    (
        "no_matching_function",
        "Нет подходящей функции",
        r"no matching function for call to ['`](?P<name>[^'`(]+)",
        "Компилятор не нашёл функцию `{name}`, которая принимала бы такие "
        "аргументы. Проверь имя функции, количество и типы передаваемых значений.",
    ),
    # --- Return missing -------------------------------------------------------
    (
        "no_return_in_value_function",
        "Функция ничего не возвращает",
        r"warning:\s*(?:control reaches end of non-void function|no return statement)",
        "Функция обещает вернуть значение (например, число), но в каком-то пути "
        "выполнения ничего не возвращает через `return`. Убедись, что во всех "
        "случаях функция выполняет `return` с нужным значением.",
    ),
    # --- Linker: undefined reference -----------------------------------------
    (
        "undefined_reference_main",
        "Не найдена функция main",
        r"undefined reference to ['`]main['`]|undefined reference to `WinMain",
        "Не найдена точка входа программы — функция `main`. В каждой программе на "
        "C++ обязательно должна быть `int main() { ... }`. Проверь, что она есть и "
        "написана правильно.",
    ),
    (
        "undefined_reference",
        "Объявлено, но не реализовано",
        r"undefined reference to ['`](?P<name>[^'`]+)['`]",
        "Имя `{name}` объявлено, но его реализация (тело) нигде не написана, либо "
        "не подключена нужная библиотека при сборке. Если это твоя функция — "
        "напиши её тело. Если из библиотеки (например, SFML) — проверь флаги "
        "линковки.",
    ),
    (
        "linker_sfml",
        "Не подключена библиотека SFML",
        r"undefined reference to ['`]sf::|cannot find -lsfml",
        "Похоже, код использует SFML, но библиотека не подключена при сборке. "
        "Нужно добавить флаги линковки SFML. Проверь установку SFML в настройках "
        "приложения.",
    ),
    # --- Scope / class members -----------------------------------------------
    (
        "private_member",
        "Доступ к приватному полю",
        r"['`](?P<name>[^'`]+)['`] is private(?: within this context)?",
        "Поле или метод `{name}` объявлено как `private` — оно «спрятано» внутри "
        "класса и доступно только его собственным методам. Снаружи к нему так "
        "обращаться нельзя. Сделай его `public` или добавь метод-геттер.",
    ),
    (
        "no_member_named",
        "У объекта нет такого поля",
        r"(?:has no member named|no member named) ['`](?P<name>[^'`]+)['`]",
        "У этого объекта/структуры нет поля или метода с именем `{name}`. Возможно, "
        "опечатка, либо ты обращаешься не к тому объекту. Сверься с описанием "
        "класса.",
    ),
    (
        "class_has_no_member",
        "Имя не является членом",
        r"['`](?P<name>[^'`]+)['`] is not a member of",
        "`{name}` не является членом указанного класса или пространства имён. "
        "Проверь имя и то, откуда оно должно браться.",
    ),
    # --- Redeclaration / redefinition ----------------------------------------
    (
        "redeclaration",
        "Повторное объявление",
        r"redeclaration of ['`](?P<name>[^'`]+)['`]|redefinition of ['`](?P<name2>[^'`]+)['`]",
        "Имя объявлено дважды в одной области видимости. Нельзя объявить две "
        "переменные с одинаковым именем рядом. Переименуй одну из них или убери "
        "лишнее объявление.",
    ),
    (
        "conflicting_declaration",
        "Конфликт объявлений",
        r"conflicting declaration",
        "Одно и то же имя объявлено с разными типами. Реши, какой тип нужен, и "
        "оставь только одно объявление.",
    ),
    # --- Uninitialized / warnings --------------------------------------------
    (
        "uninitialized",
        "Переменная без начального значения",
        r"warning:\s*['`]?(?P<name>\w+)['`]? is used uninitialized",
        "Переменная `{name}` используется до того, как ей присвоили значение. Это "
        "как доставать из пустой коробки — внутри может оказаться что угодно. "
        "Сначала дай переменной значение.",
    ),
    (
        "comparison_signed_unsigned",
        "Сравнение разных типов чисел",
        r"warning:\s*comparison (?:of|between) (?:integer expressions of different signedness|signed and unsigned)",
        "Ты сравниваешь обычное целое число со «беззнаковым» (например, с "
        "`size()` у вектора). Обычно это не ошибка, но может привести к "
        "неожиданным результатам. Чаще всего достаточно использовать одинаковые "
        "типы в сравнении.",
    ),
    # --- Array / vector bounds (runtime via sanitizer) -----------------------
    (
        "asan_heap_overflow",
        "Выход за границы памяти",
        r"AddressSanitizer:\s*heap-buffer-overflow|heap-buffer-overflow",
        "Программа обратилась к памяти за границами выделенного массива/вектора. "
        "Частая причина — индекс выходит за пределы (например, цикл до `<= n` "
        "вместо `< n`). Проверь границы циклов и индексы.",
    ),
    (
        "asan_stack_overflow",
        "Выход за границы массива на стеке",
        r"stack-buffer-overflow",
        "Программа вышла за границы массива. Проверь, что индексы не превышают "
        "размер массива (индексы идут от 0 до размер−1).",
    ),
    (
        "asan_use_after_free",
        "Использование после освобождения",
        r"heap-use-after-free|use-after-free",
        "Ты используешь память, которую уже освободил через `delete`. Это как "
        "звонить по номеру телефона, который уже отключили. После `delete` "
        "указатель использовать нельзя.",
    ),
    (
        "asan_leak",
        "Утечка памяти",
        r"LeakSanitizer:|detected memory leaks",
        "Программа выделила память через `new`, но не освободила её через "
        "`delete`. Это утечка памяти. На каждый `new` должен быть свой `delete` "
        "(или используй умные указатели `unique_ptr`/`shared_ptr`).",
    ),
    (
        "segfault",
        "Падение программы (segmentation fault)",
        r"Segmentation fault|SIGSEGV",
        "Программа упала с ошибкой `Segmentation fault`. Обычно это значит "
        "обращение к памяти, которой нет: например, разыменование `nullptr` "
        "или указателя, который никуда не указывает. Проверь указатели и границы "
        "массивов.",
    ),
    # --- Division / runtime ---------------------------------------------------
    (
        "div_by_zero_warn",
        "Деление на ноль",
        r"warning:\s*division by zero|Floating point exception",
        "Где-то происходит деление на ноль. На ноль делить нельзя. Проверь "
        "делитель — он не должен быть равен 0.",
    ),
    # --- String / char issues -------------------------------------------------
    (
        "char_to_string",
        "Кавычки: ' вместо \"",
        r"invalid conversion from ['`]char['`]|ISO C\+\+ forbids comparison between pointer and integer",
        "Похоже, ты использовал одинарные кавычки `'...'` для текста. Одинарные "
        "кавычки — для одного символа (`'a'`), а для строки текста нужны двойные "
        "кавычки (`\"привет\"`).",
    ),
    (
        "missing_quote",
        "Незакрытая строка",
        r"missing terminating .* character|unterminated",
        "Где-то не закрыта кавычка у строки или символа. У каждой открывающей "
        "кавычки должна быть закрывающая.",
    ),
    # --- Increment/operators --------------------------------------------------
    (
        "lvalue_required",
        "Слева от = должна быть переменная",
        r"lvalue required|expression is not assignable",
        "Слева от знака `=` должно стоять то, чему можно присвоить значение "
        "(переменная). Нельзя присвоить значение, например, числу или результату "
        "выражения.",
    ),
    (
        "invalid_operands",
        "Операция не подходит для этих типов",
        r"invalid operands (?:to|of) binary|no match for ['`]operator",
        "Ты применяешь операцию (например, `+` или `<`) к типам, которые так "
        "складывать/сравнивать нельзя. Проверь типы операндов.",
    ),
    # --- const / assignment ---------------------------------------------------
    (
        "assignment_of_const",
        "Изменение константы",
        r"assignment of read-only|cannot assign to .*const",
        "Ты пытаешься изменить значение, объявленное как `const` (постоянное). "
        "Константы менять нельзя — на то они и константы. Убери `const`, если "
        "значение должно меняться.",
    ),
    # --- main signature -------------------------------------------------------
    (
        "main_must_return_int",
        "main должна возвращать int",
        r"['`]main['`] must return ['`]int['`]|cannot declare ['`]::main['`]",
        "Функция `main` должна быть объявлена как `int main()`. Проверь её "
        "заголовок.",
    ),
    # --- expected primary expression -----------------------------------------
    (
        "expected_primary_expression",
        "Ожидалось выражение",
        r"expected primary-expression before",
        "Компилятор ожидал увидеть значение или переменную, но встретил что-то "
        "другое (часто — лишний символ, оператор или запятую). Внимательно "
        "посмотри на указанную строку.",
    ),
    # --- stray token ----------------------------------------------------------
    (
        "stray_token",
        "Лишний/непонятный символ",
        r"stray ['`].['`] in program",
        "В коде есть лишний или «странный» символ (иногда это кавычки или буквы из "
        "другой раскладки, например русская «с» вместо латинской «c»). Перепиши "
        "проблемную строку латиницей.",
    ),
    # --- generic error fallback (keep LAST) ----------------------------------
    (
        "generic_error_with_line",
        "Ошибка компиляции",
        r"(?P<file>[^\s:]+):(?P<line>\d+):\d+:\s*error:\s*(?P<msg>.+)",
        "Компилятор сообщил об ошибке в строке {line}: «{msg}». Посмотри "
        "внимательно на эту строку. Если не понятно — нажми «Объяснить подробнее», "
        "и ИИ-помощник разберёт ошибку детальнее.",
    ),
]


@dataclass
class _Pattern:
    pattern_id: str
    title_ru: str
    regex: re.Pattern
    template_ru: str


_PATTERNS: list[_Pattern] = [
    _Pattern(pid, title, re.compile(rx, re.IGNORECASE | re.MULTILINE), tmpl)
    for (pid, title, rx, tmpl) in _RAW_PATTERNS
]


def _safe_format(template: str, groups: dict) -> str:
    clean = {k: (v if v is not None else "") for k, v in groups.items()}

    class _D(dict):
        def __missing__(self, key):  # any {unknown} -> empty
            return ""

    try:
        return template.format_map(_D(clean))
    except Exception:
        return template


def match_error(stderr: str) -> Optional[ErrorMatch]:
    """Return the first matching Tier-1 explanation, or None for AI fallback."""
    if not stderr:
        return None
    for p in _PATTERNS:
        m = p.regex.search(stderr)
        if m:
            groups = m.groupdict()
            explanation = _safe_format(p.template_ru, groups)
            return ErrorMatch(
                pattern_id=p.pattern_id,
                title_ru=p.title_ru,
                explanation_ru=explanation,
            )
    return None


def pattern_count() -> int:
    return len(_PATTERNS)


def pattern_title(pattern_id: str) -> Optional[str]:
    for p in _PATTERNS:
        if p.pattern_id == pattern_id:
            return p.title_ru
    return None


if __name__ == "__main__":
    print("patterns:", pattern_count())
    samples = [
        "main.cpp:5:10: error: expected ';' before 'return'",
        "main.cpp:3:5: error: 'x' was not declared in this scope",
        "/tmp/main.cpp:7:1: error: 'cout' was not declared in this scope",
        "undefined reference to `main'",
        "AddressSanitizer: heap-buffer-overflow on address 0x...",
    ]
    for s in samples:
        m = match_error(s)
        print("--", m.pattern_id if m else None, "->", (m.explanation_ru[:60] if m else "NO MATCH"))
