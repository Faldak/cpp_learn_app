"""
ui/code_editor_component.py
===========================
The VS-Code-like code editor.

EDITOR DECISION (documented per spec section 1):
  The spec's preferred option is a Monaco/CodeMirror embed inside a Flet WebView.
  We deliberately chose the documented FALLBACK instead: a Flet TextField styled
  to look like VS Code's dark editor, with a line-number gutter and a monospace
  font. Reasons:
    1. Offline-first is a hard requirement (spec section 10). Monaco/CodeMirror
       pulled from a CDN breaks offline; bundling them requires shipping a
       webview runtime, which is exactly the heavy Node/Chromium toolchain the
       user explicitly does NOT want.
    2. Flet's webview support varies by desktop platform and would add a fragile
       dependency for a non-programmer to install.
  Trade-off: no live token syntax-highlighting WHILE typing (Flet's editable
  TextField cannot render inline rich text). We compensate with: a true
  monospace font, a dark VS-Code palette, line numbers, and large comfortable
  sizing. This is reliable on every OS with zero extra setup.
"""

from __future__ import annotations

from typing import Callable, Optional

import flet as ft

from ui import theme as themelib


class CodeEditor:
    def __init__(self, theme: str = "dark", on_change: Optional[Callable] = None):
        self.pal = themelib.palette(theme)
        self._on_change_cb = on_change

        self.line_numbers = ft.Text(
            "1",
            font_family=themelib.MONO_FONT,
            size=14,
            color=self.pal.gutter_text,
            selectable=False,
            text_align=ft.TextAlign.RIGHT,
        )

        self.field = ft.TextField(
            value="",
            multiline=True,
            min_lines=18,
            max_lines=40,
            text_style=ft.TextStyle(font_family=themelib.MONO_FONT, size=14,
                                    color=self.pal.editor_text),
            bgcolor=self.pal.editor_bg,
            color=self.pal.editor_text,
            cursor_color=self.pal.accent_hover,
            border_color=self.pal.border,
            border_radius=6,
            filled=True,
            content_padding=ft.Padding(12, 10, 12, 10),
            on_change=self._handle_change,
            expand=True,
        )

        self.gutter = ft.Container(
            content=self.line_numbers,
            bgcolor=self.pal.gutter_bg,
            padding=ft.Padding(8, 12, 8, 12),
            width=46,
            alignment=ft.Alignment.TOP_RIGHT,
        )

        self.control = ft.Container(
            content=ft.Row(
                spacing=0,
                vertical_alignment=ft.CrossAxisAlignment.START,
                controls=[self.gutter, self.field],
                expand=True,
            ),
            border=ft.Border.all(1, self.pal.border),
            border_radius=8,
            bgcolor=self.pal.editor_bg,
            expand=True,
        )

    def _handle_change(self, e):
        self._refresh_line_numbers()
        if self._on_change_cb:
            self._on_change_cb(e)

    def _refresh_line_numbers(self):
        n = max(1, (self.field.value or "").count("\n") + 1)
        self.line_numbers.value = "\n".join(str(i) for i in range(1, n + 1))
        try:
            self.line_numbers.update()
        except Exception:
            pass

    # --- public API ----------------------------------------------------------
    def get_text(self) -> str:
        return self.field.value or ""

    def set_text(self, text: str):
        self.field.value = text or ""
        self._refresh_line_numbers()
        try:
            self.field.update()
        except Exception:
            pass

    def set_readonly(self, ro: bool):
        self.field.read_only = ro
        try:
            self.field.update()
        except Exception:
            pass
