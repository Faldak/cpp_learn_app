"""
ui/onboarding_view.py
=====================
First-run gate. Checks the C++ compiler (required), SFML (optional, for the
graphics block) and lets the user optionally add a Groq API key. The compiler
is the only hard requirement to start learning.
"""

from __future__ import annotations

import flet as ft

import ai_client
import compiler_service as cs
import progress_db
from ui import components as C
from ui import strings_ru as S


def build_onboarding(shell, on_done):
    pal = shell.pal

    comp_path = cs.detect_compiler()
    comp_ver = cs.compiler_version() if comp_path else None

    compiler_row = ft.Column(spacing=4)
    sfml_row = ft.Column(spacing=4)
    start_btn_holder = ft.Row()

    def render_status():
        cp = cs.detect_compiler()
        cv = cs.compiler_version() if cp else None
        if cp:
            compiler_row.controls = [
                ft.Text(S.ONB_COMPILER_OK.format(ver=cv or cp), color=pal.success, size=14),
            ]
        else:
            compiler_row.controls = [
                ft.Text(S.ONB_COMPILER_MISSING, color=pal.error, size=14),
                C.subtle(S.ONB_COMPILER_HELP, pal),
            ]
        sfml_ok = cs.detect_sfml(force=True)
        sfml_row.controls = [
            ft.Text((S.ONB_SFML_OK if sfml_ok else S.ONB_SFML_MISSING),
                    color=(pal.success if sfml_ok else pal.text_dim), size=14),
        ]
        if not sfml_ok:
            sfml_row.controls.append(C.subtle(S.ONB_SFML_HELP, pal))

        start_btn_holder.controls = [
            C.primary_button(S.ONB_BTN_START, _finish, pal, disabled=(cp is None)),
        ]
        try:
            compiler_row.update(); sfml_row.update(); start_btn_holder.update()
        except Exception:
            pass

    def recheck(e):
        render_status()

    def _finish(e):
        progress_db.set_onboarding_completed(True)
        on_done()

    # AI key (optional)
    key_field = ft.TextField(
        hint_text=S.ONB_AI_KEY_PLACEHOLDER, password=True, can_reveal_password=True,
        width=360, bgcolor=pal.bg_panel, color=pal.text, border_color=pal.border,
    )
    key_status = ft.Text("", size=13, color=pal.text_dim)

    def save_key(e):
        key = (key_field.value or "").strip()
        if not key:
            return
        # Save FIRST so the key persists on the first click even if the online
        # verification below can't confirm it (no internet, rate limit, etc.).
        saved = ai_client.set_api_key(key)
        if not saved:
            key_status.value = ("Не удалось сохранить ключ. Можно задать "
                                "переменную окружения GROQ_API_KEY.")
            key_status.color = pal.error
            key_status.update()
            return
        key_status.value = S.AI_THINKING
        key_status.color = pal.text_dim
        key_status.update()
        res = ai_client.test_key(key)
        if res.ok:
            key_status.value = "Ключ сохранён. " + res.text
            key_status.color = pal.success
        else:
            key_status.value = "Ключ сохранён, но проверка не прошла: " + res.text
            key_status.color = pal.warning
        key_status.update()

    render_status()

    col = ft.Column([
        ft.Row([ft.Icon(ft.Icons.SCHOOL, color=pal.accent, size=34),
                C.heading(S.ONB_TITLE, pal, 26)], spacing=10),
        C.body(S.ONB_INTRO, pal),
        ft.Container(height=8),
        C.card(ft.Column([C.heading(S.ONB_STEP_COMPILER, pal, 16), compiler_row,
                          C.secondary_button(S.ONB_BTN_RECHECK, recheck, pal, icon=ft.Icons.REFRESH)],
                         spacing=8), pal),
        C.card(ft.Column([C.heading(S.ONB_STEP_SFML, pal, 16), sfml_row], spacing=8), pal),
        C.card(ft.Column([C.heading(S.ONB_STEP_AI, pal, 16),
                          C.subtle(S.ONB_AI_INFO, pal),
                          ft.Row([key_field, C.secondary_button(S.ONB_BTN_CHECK_KEY, save_key, pal)],
                                 spacing=10),
                          key_status], spacing=8), pal),
        ft.Container(height=8),
        start_btn_holder,
        ft.Container(height=20),
    ], spacing=14, scroll=ft.ScrollMode.AUTO,
        horizontal_alignment=ft.CrossAxisAlignment.START)

    return ft.Container(content=ft.Container(content=col, width=720),
                        alignment=ft.Alignment.CENTER, padding=30, expand=True)
