"""
ui/settings_view.py
==================
Settings: theme, AI model + API key (stored in OS keychain via ai_client),
and a re-check of compiler/SFML availability.
"""

from __future__ import annotations

import flet as ft

import ai_client
import compiler_service as cs
import config
import progress_db
from ui import components as C
from ui import strings_ru as S


def build_settings(shell):
    pal = shell.pal
    page = shell.page

    # --- theme ---------------------------------------------------------------
    def on_theme(e):
        shell.set_theme("dark" if theme_switch.value else "light")

    theme_switch = ft.Switch(value=(shell.theme == "dark"), active_color=pal.accent,
                             on_change=on_theme)

    
    theme_card = C.card(ft.Row([
        ft.Column([C.heading(S.SET_THEME, pal, 16),
                   C.subtle("Тёмная / светлая", pal)], spacing=2, expand=True),
        ft.Row([C.subtle(S.SET_THEME_LIGHT, pal), theme_switch, C.subtle(S.SET_THEME_DARK, pal)],
               spacing=8),
    ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN), pal)

    # --- AI model ------------------------------------------------------------
    model_dd = ft.Dropdown(
        value=ai_client.get_model(),
        options=[ft.dropdown.Option(m) for m in config.GROQ_MODELS],
        width=360, bgcolor=pal.bg_panel, color=pal.text, border_color=pal.border,
    )

    def on_model(e):
        progress_db.set_setting("ai_model", model_dd.value)

    # Flet Dropdown fires `on_change` (not `on_select`); without this the chosen
    # model was never saved, which could make key-checks hit a wrong model.
    model_dd.on_change = on_model

    # --- AI key --------------------------------------------------------------
    key_field = ft.TextField(
        hint_text=S.ONB_AI_KEY_PLACEHOLDER, password=True, can_reveal_password=True,
        width=360, bgcolor=pal.bg_panel, color=pal.text, border_color=pal.border,
    )
    key_status = ft.Text("", size=13, color=pal.text_dim)
    configured_label = ft.Text("", size=13)
    delete_btn_holder = ft.Container()

    def render_configured():
        configured = ai_client.is_configured()
        configured_label.value = ("Ключ настроен ✅" if configured else "Ключ не настроен")
        configured_label.color = (pal.success if configured else pal.text_dim)
        # Delete button only makes sense when a key is stored in the keychain.
        if ai_client.key_in_keyring():
            delete_btn_holder.content = C.secondary_button(
                S.SET_AI_KEY_DELETE, on_delete_key, pal, icon=ft.Icons.DELETE_OUTLINE)
        else:
            delete_btn_holder.content = None
        try:
            configured_label.update()
            delete_btn_holder.update()
        except Exception:
            pass

    def on_save_key(e):
        key = (key_field.value or "").strip()
        if not key:
            key_status.value = "Введи ключ."
            key_status.color = pal.error
            key_status.update()
            return
        # Save FIRST so the key always persists on the first click, even if the
        # online verification below fails (no internet, rate limit, etc.).
        saved = ai_client.set_api_key(key)
        if not saved:
            key_status.value = ("Не удалось сохранить ключ в хранилище системы. "
                                "Можно задать переменную окружения GROQ_API_KEY.")
            key_status.color = pal.error
            key_status.update()
            return
        key_field.value = ""
        render_configured()
        key_status.value = S.AI_THINKING
        key_status.color = pal.text_dim
        key_status.update()
        res = ai_client.test_key(key, model_dd.value)
        if res.ok:
            key_status.value = "Ключ сохранён. " + res.text
            key_status.color = pal.success
        else:
            # Key is saved regardless; verification just couldn't confirm it now.
            key_status.value = "Ключ сохранён, но проверка не прошла: " + res.text
            key_status.color = pal.warning
        key_status.update()

    def on_delete_key(e):
        if ai_client.delete_api_key():
            key_field.value = ""
            key_status.value = "Ключ удалён."
            key_status.color = pal.text_dim
        else:
            key_status.value = "Не удалось удалить ключ."
            key_status.color = pal.error
        render_configured()
        try:
            key_field.update()
        except Exception:
            pass
        key_status.update()

    configured = ai_client.is_configured()
    configured_label.value = ("Ключ настроен ✅" if configured else "Ключ не настроен")
    configured_label.color = (pal.success if configured else pal.text_dim)
    if ai_client.key_in_keyring():
        delete_btn_holder.content = C.secondary_button(
            S.SET_AI_KEY_DELETE, on_delete_key, pal, icon=ft.Icons.DELETE_OUTLINE)

    ai_card = C.card(ft.Column([
        C.heading(S.SET_AI_KEY, pal, 16),
        C.subtle(S.ONB_AI_INFO, pal),
        configured_label,
        ft.Row([ft.Text(S.SET_AI_MODEL, color=pal.text, size=14), model_dd], spacing=10),
        ft.Row([key_field, C.primary_button(S.ONB_BTN_CHECK_KEY, on_save_key, pal)], spacing=10),
        delete_btn_holder,
        key_status,
    ], spacing=10), pal)

    # --- tools recheck -------------------------------------------------------
    tools_status = ft.Column(spacing=4)

    def refresh_tools(e=None):
        comp = cs.detect_compiler()
        ver = cs.compiler_version() if comp else None
        sfml = cs.detect_sfml(force=True)
        tools_status.controls = [
            ft.Text((S.ONB_COMPILER_OK.format(ver=ver or comp) if comp
                     else "Компилятор C++ не найден"),
                    color=(pal.success if comp else pal.error), size=14),
            ft.Text((S.ONB_SFML_OK if sfml else "SFML не найден (нужен для блока графики)"),
                    color=(pal.success if sfml else pal.text_dim), size=14),
        ]
        try:
            tools_status.update()
        except Exception:
            pass

    refresh_tools()
    tools_card = C.card(ft.Column([
        C.heading(S.SET_RECHECK_TOOLS, pal, 16),
        tools_status,
        C.secondary_button(S.ONB_BTN_RECHECK, refresh_tools, pal, icon=ft.Icons.REFRESH),
    ], spacing=10), pal)

    col = ft.Column([
        C.heading(S.SET_TITLE, pal, 24),
        ft.Container(height=6),
        theme_card, ai_card, tools_card,
        ft.Container(height=20),
    ], spacing=14, scroll=ft.ScrollMode.AUTO)
    return ft.Container(content=col, padding=24, expand=True)
