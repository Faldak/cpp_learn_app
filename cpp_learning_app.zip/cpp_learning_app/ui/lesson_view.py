"""
ui/lesson_view.py
=================
The Lessons screen: a left sidebar (blocks -> lessons) and a detail area with
two tabs (Теория / Задание). The Задание tab hosts the code editor, action
buttons (Запустить / Проверить / Сбросить / Подсказка / Помощь), output and the
result report.

All correctness is decided by task_checker (deterministic). AI is only invoked
on explicit user action (Помощь / Объяснить).
"""

from __future__ import annotations

import threading

import flet as ft

import ai_client
import compiler_service as cs
import content_loader
import error_dictionary
import progress_db
import task_checker
from ui import components as C
from ui import strings_ru as S
from ui.code_editor_component import CodeEditor
from ui.report_view import build_report


class LessonsScreen:
    def __init__(self, shell):
        self.shell = shell
        self.page = shell.page
        self.pal = shell.pal

        self.editor: CodeEditor | None = None
        self.current_task: dict | None = None
        self.current_lesson: dict | None = None
        self.output_box = ft.Container()
        self.report_box = ft.Container()
        self.status_text = ft.Text("", size=13, color=self.pal.text_dim)
        self._hint_index = 0

    # =====================================================================
    # Entry points
    # =====================================================================
    def build(self, lesson_id: str | None = None):
        if lesson_id is None:
            ids = content_loader.ordered_lesson_ids()
            lesson_id = ids[0] if ids else None
        return self._layout(lesson_id)

    def build_for_task(self, task_id: str):
        task = content_loader.get_task(task_id)
        lesson_id = task["lesson_id"] if task else None
        layout = self._layout(lesson_id, initial_task_id=task_id)
        return layout

    # =====================================================================
    # Layout
    # =====================================================================
    def _layout(self, lesson_id: str | None, initial_task_id: str | None = None):
        sidebar = self._build_sidebar(lesson_id)
        if lesson_id is None:
            detail = ft.Container(
                content=C.subtle(S.EMPTY_SELECT_LESSON, self.pal),
                padding=24, expand=True,
            )
        else:
            detail = self._build_detail(lesson_id, initial_task_id)
        return ft.Row(
            spacing=0, expand=True,
            controls=[
                ft.Container(content=sidebar, width=300, bgcolor=self.pal.bg_panel,
                             border=ft.Border.only(right=ft.BorderSide(1, self.pal.border))),
                ft.Container(content=detail, expand=True, padding=0),
            ],
        )

    def _build_sidebar(self, active_lesson_id: str | None):
        items = []
        items.append(ft.Container(
            content=ft.Row([ft.Icon(ft.Icons.SCHOOL, color=self.pal.accent),
                            C.heading(S.APP_TITLE, self.pal, size=18)], spacing=8),
            padding=ft.Padding(16, 16, 16, 8),
        ))
        for block in content_loader.blocks():
            lessons = content_loader.lessons_for_block(block["block_id"])
            done = sum(1 for l in lessons
                       if progress_db.get_lesson_status(l["lesson_id"]) == "completed")
            items.append(ft.Container(
                content=ft.Column([
                    ft.Text(block["title"], size=14, weight=ft.FontWeight.BOLD, color=self.pal.text),
                    ft.Text(f"{done}/{len(lessons)} уроков", size=11, color=self.pal.text_dim),
                ], spacing=2),
                padding=ft.Padding(16, 10, 16, 4),
            ))
            for l in lessons:
                items.append(self._sidebar_lesson_row(l, active_lesson_id))
        return ft.ListView(controls=items, expand=True, padding=ft.Padding(0, 0, 0, 16))

    def _sidebar_lesson_row(self, lesson: dict, active_lesson_id: str | None):
        lid = lesson["lesson_id"]
        status = progress_db.get_lesson_status(lid)
        if status == "completed":
            badge, bcol = S.COMPLETED_BADGE, self.pal.success
        elif status == "in_progress":
            badge, bcol = S.IN_PROGRESS_BADGE, self.pal.accent
        else:
            badge, bcol = "○", self.pal.text_dim
        active = lid == active_lesson_id
        return ft.Container(
            content=ft.Row([
                ft.Text(badge, color=bcol, size=14),
                ft.Text(lesson["title"], size=13,
                        color=self.pal.text if active else self.pal.text_dim,
                        weight=ft.FontWeight.BOLD if active else ft.FontWeight.NORMAL,
                        expand=True),
            ], spacing=8),
            padding=ft.Padding(24, 7, 12, 7),
            bgcolor=self.pal.bg_elevated if active else None,
            border=ft.Border.only(left=ft.BorderSide(3, self.pal.accent)) if active else None,
            on_click=lambda e, _lid=lid: self.shell.show_lessons(_lid),
            ink=True,
        )

    # =====================================================================
    # Detail (theory + task tabs)
    # =====================================================================
    def _build_detail(self, lesson_id: str, initial_task_id: str | None):
        lesson = content_loader.get_lesson(lesson_id)
        self.current_lesson = lesson
        if not lesson:
            return ft.Container(content=C.subtle("Урок не найден.", self.pal), padding=24)

        progress_db.open_lesson(lesson_id)

        theory_content = self._build_theory(lesson)
        task_content = self._build_task_area(lesson, initial_task_id)

        # Custom segmented toggle (Flet 0.85 Tabs API is heavyweight; this is
        # simpler and fully under our control).
        tab_body = ft.Container(
            content=task_content if initial_task_id else theory_content, expand=True)

        theory_btn = ft.TextButton(content=ft.Text(S.TAB_THEORY))
        task_btn = ft.TextButton(content=ft.Text(S.TAB_TASK))

        def select_tab(which):
            is_theory = which == "theory"
            tab_body.content = theory_content if is_theory else task_content
            theory_btn.style = ft.ButtonStyle(
                color=self.pal.text if is_theory else self.pal.text_dim)
            task_btn.style = ft.ButtonStyle(
                color=self.pal.text_dim if is_theory else self.pal.text)
            self.page.update()

        theory_btn.on_click = lambda e: select_tab("theory")
        task_btn.on_click = lambda e: select_tab("task")
        # initial styling
        _t_active = bool(initial_task_id)
        theory_btn.style = ft.ButtonStyle(color=self.pal.text_dim if _t_active else self.pal.text)
        task_btn.style = ft.ButtonStyle(color=self.pal.text if _t_active else self.pal.text_dim)

        tab_bar = ft.Container(
            content=ft.Row([theory_btn, task_btn], spacing=4),
            border=ft.Border.only(bottom=ft.BorderSide(1, self.pal.border)),
            padding=ft.Padding(12, 0, 12, 0),
        )

        return ft.Container(
            content=ft.Column([
                ft.Container(
                    content=ft.Column([
                        C.heading(lesson["title"], self.pal),
                        C.subtle(f"≈ {lesson.get('estimated_minutes', 15)} мин", self.pal),
                    ], spacing=2),
                    padding=ft.Padding(24, 18, 24, 6),
                ),
                tab_bar,
                ft.Container(content=tab_body, expand=True, padding=ft.Padding(12, 6, 12, 0)),
            ], spacing=0, expand=True),
            expand=True,
        )

    def _build_theory(self, lesson: dict):
        blocks = []
        for tb in lesson.get("theory_blocks", []):
            if tb["type"] == "text":
                blocks.append(C.body(tb["content"], self.pal))
            elif tb["type"] == "code_example":
                blocks.append(C.mono_box(tb["code"], self.pal))
                if tb.get("explanation"):
                    blocks.append(C.subtle(tb["explanation"], self.pal, size=14))
            blocks.append(ft.Container(height=6))

        takeaways = ft.Column(
            [ft.Text("• " + t, size=14, color=self.pal.text) for t in lesson.get("key_takeaways", [])],
            spacing=4)
        mistakes = ft.Column(
            [ft.Text("⚠ " + t, size=14, color=self.pal.warning) for t in lesson.get("common_mistakes", [])],
            spacing=4)

        col = ft.Column([
            *blocks,
            ft.Container(height=8),
            C.card(ft.Column([C.heading(S.THEORY_TAKEAWAYS, self.pal, 16), takeaways], spacing=8), self.pal),
            ft.Container(height=10),
            C.card(ft.Column([C.heading(S.THEORY_MISTAKES, self.pal, 16), mistakes], spacing=8), self.pal),
            ft.Container(height=20),
        ], spacing=8, scroll=ft.ScrollMode.AUTO)
        return ft.Container(content=col, padding=ft.Padding(12, 12, 12, 12), expand=True)

    def _build_task_area(self, lesson: dict, initial_task_id: str | None):
        tasks = content_loader.tasks_for_lesson(lesson["lesson_id"])
        if not tasks:
            return ft.Container(content=C.subtle("В этом уроке пока нет заданий.", self.pal), padding=24)

        # task selector dropdown (if more than one)
        task_by_id = {t["task_id"]: t for t in tasks}
        start_id = initial_task_id if initial_task_id in task_by_id else tasks[0]["task_id"]

        self.task_container = ft.Container(expand=True)

        options = []
        for i, t in enumerate(tasks, 1):
            st = progress_db.get_task_status(t["task_id"])["best_status"]
            mark = " ✓" if st == "passed" else ""
            options.append(ft.dropdown.Option(key=t["task_id"], text=f"{i}. {t['title']}{mark}"))

        self.task_dropdown = ft.Dropdown(
            value=start_id, options=options, on_select=self._on_task_change,
            width=420, bgcolor=self.pal.bg_panel, color=self.pal.text,
            border_color=self.pal.border,
        )

        self._render_task(start_id)

        return ft.Container(
            content=ft.Column([
                ft.Row([C.subtle("Задание:", self.pal), self.task_dropdown], spacing=10),
                ft.Container(content=self.task_container, expand=True),
            ], spacing=10, expand=True),
            padding=ft.Padding(12, 10, 12, 12), expand=True,
        )

    def _on_task_change(self, e):
        self._render_task(e.control.value)
        self.page.update()

    def _load_saved_code(self, task: dict) -> str:
        attempts = progress_db.get_attempts(task["task_id"])
        if attempts:
            last = attempts[-1].get("submitted_code")
            if last:
                return last
        return task.get("starter_code", "")

    def _render_task(self, task_id: str):
        task = content_loader.get_task(task_id)
        self.current_task = task
        self._hint_index = 0
        self.editor = CodeEditor(theme=self.shell.theme, on_change=None)
        self.editor.set_text(self._load_saved_code(task))

        self.output_box = C.mono_box(S.OUTPUT_EMPTY, self.pal)
        self.report_box = ft.Container()
        self.status_text = ft.Text("", size=13, color=self.pal.text_dim)

        is_sfml = task.get("type") == "sfml_rubric"

        buttons = ft.Row([
            C.primary_button(S.BTN_CHECK, self._on_check, self.pal, icon=ft.Icons.CHECK_CIRCLE),
            C.secondary_button(S.BTN_RUN, self._on_run, self.pal, icon=ft.Icons.PLAY_ARROW),
            C.secondary_button(S.BTN_RESET, self._on_reset, self.pal, icon=ft.Icons.REFRESH),
            C.secondary_button(S.BTN_HINT, self._on_hint, self.pal, icon=ft.Icons.LIGHTBULB),
            C.secondary_button(S.BTN_SHOW_SOLUTION, self._on_show_solution, self.pal, icon=ft.Icons.VISIBILITY),
        ], spacing=8, wrap=True)

        prompt_card = C.card(ft.Column([
            ft.Row([C.heading(task["title"], self.pal, 17),
                    C.chip(f"сложность {task.get('difficulty',1)}/3", self.pal)],
                   alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            C.body(task["prompt"], self.pal),
        ], spacing=8), self.pal)

        editor_col = ft.Column([
            C.subtle(S.EDITOR_TITLE, self.pal),
            ft.Container(content=self.editor.control, height=360),
            buttons,
            self.status_text,
        ], spacing=8, expand=True)

        output_col = ft.Column([
            C.subtle(S.OUTPUT_TITLE, self.pal),
            self.output_box,
            self.report_box,
        ], spacing=8, scroll=ft.ScrollMode.AUTO, expand=True)

        body = ft.Row([
            ft.Container(content=editor_col, expand=3),
            ft.Container(content=output_col, expand=2),
        ], spacing=16, vertical_alignment=ft.CrossAxisAlignment.START, expand=True)

        self.task_container.content = ft.Column([
            prompt_card,
            ft.Container(height=6),
            body,
        ], spacing=6, scroll=ft.ScrollMode.AUTO, expand=True)

    # =====================================================================
    # Actions
    # =====================================================================
    def _set_status(self, text: str):
        self.status_text.value = text
        try:
            self.status_text.update()
        except Exception:
            pass

    def _set_output(self, text: str, error: bool = False):
        self.output_box.content = ft.Text(
            text or "", font_family="Consolas, monospace", size=13,
            color=(self.pal.error if error else self.pal.editor_text), selectable=True)
        try:
            self.output_box.update()
        except Exception:
            pass

    def _on_run(self, e):
        task = self.current_task
        source = self.editor.get_text()
        self._set_status(S.RUNNING)
        self.report_box.content = None
        try:
            self.report_box.update()
        except Exception:
            pass
        use_sfml = task.get("type") == "sfml_rubric"
        compiled = cs.compile_source(source, use_sfml=use_sfml)
        if not compiled.ok:
            self._show_compile_error(source, compiled.compiler_stderr)
            self._set_status("")
            return
        if use_sfml:
            rr = cs.observe_windowed(compiled.executable_path)
            self._set_output("Программа запущена (графическое окно). "
                             f"{'Завершилась с ошибкой.' if rr.crashed else 'Окно открылось.'}")
        else:
            # default: run with the first test case's stdin if the task has one,
            # so "Запустить" shows meaningful output for input-driven tasks.
            tcs = task.get("test_cases") or []
            stdin = (tcs[0].get("stdin", "") if tcs else "")
            rr = cs.run_executable(compiled.executable_path, stdin=stdin)
            out = rr.stdout
            if stdin:
                out = f"[ввод] {stdin.strip()}\n{out}"
            if rr.stderr:
                out += ("\n[stderr]\n" + rr.stderr)
            if rr.timed_out:
                out = "Программа выполнялась слишком долго и была остановлена."
            self._set_output(out or "(пустой вывод)")
        self._set_status("")

    def _on_check(self, e):
        task = self.current_task
        source = self.editor.get_text()
        self._set_status(S.CHECKING)
        result = task_checker.check_task(source, task)

        # persist attempt
        progress_db.record_attempt(
            task_id=task["task_id"], lesson_id=task["lesson_id"],
            passed=result.passed, submitted_code=source,
            compiler_errors=result.compile_error or None,
            rubric_results=[
                {"id": r.id, "description_ru": r.description_ru, "passed": r.passed}
                for r in result.rubric_results
            ] if result.rubric_results else None,
        )

        # log error pattern for dashboard if compile failed
        if not result.compiled and result.compile_error:
            m = error_dictionary.match_error(result.compile_error)
            progress_db.log_error(
                task_id=task["task_id"],
                raw_error_text=result.compile_error,
                matched_tier1_pattern_id=(m.pattern_id if m else None),
                used_ai_fallback=False,
            )

        # if all tasks in lesson passed -> complete lesson
        self._maybe_complete_lesson(task["lesson_id"])

        cleanliness = task_checker.code_cleanliness(source, task.get("difficulty", 1))
        self.report_box.content = build_report(self.pal, task, result, cleanliness,
                                                on_explain=self._on_explain_result,
                                                on_explain_error=lambda ev: self._explain_error_ai(source, result.compile_error))
        try:
            self.report_box.update()
        except Exception:
            pass
        if not result.compiled:
            self._set_output(result.compile_error, error=True)
        self._set_status("")
        # refresh sidebar marks lazily on next navigation

    def _maybe_complete_lesson(self, lesson_id: str):
        task_ids = [t["task_id"] for t in content_loader.tasks_for_lesson(lesson_id)]
        if task_ids and all(
            progress_db.get_task_status(tid)["best_status"] == "passed" for tid in task_ids
        ):
            progress_db.complete_lesson(lesson_id)

    def _on_reset(self, e):
        self.editor.set_text(self.current_task.get("starter_code", ""))

    def _on_hint(self, e):
        hints = self.current_task.get("hints", [])
        if not hints:
            self._set_status(S.NO_MORE_HINTS)
            return
        if self._hint_index >= len(hints):
            self._set_status(S.NO_MORE_HINTS)
            return
        idx = self._hint_index
        self._hint_index += 1
        title = S.HINT_TITLE.format(n=idx + 1, total=len(hints))
        self._open_dialog(title, hints[idx])

    def _on_show_solution(self, e):
        def confirm(ev):
            self._close_dialog()
            sol = self.current_task.get("reference_solution", "")
            self.editor.set_text(sol)

        dlg = ft.AlertDialog(
            title=ft.Text(S.SOLUTION_WARN_TITLE, color=self.pal.text),
            content=ft.Text(S.SOLUTION_WARN_BODY, color=self.pal.text),
            bgcolor=self.pal.bg_panel,
            actions=[
                ft.TextButton(S.SOLUTION_CANCEL, on_click=lambda ev: self._close_dialog()),
                C.primary_button(S.SOLUTION_CONFIRM, confirm, self.pal),
            ],
        )
        self._show_dialog(dlg)

    # --- AI explanation (explicit only) --------------------------------------
    def _on_explain_result(self, e):
        if not ai_client.is_configured():
            self._open_dialog(S.SECTION_AI, ai_client.FALLBACK_NO_KEY)
            return
        task = self.current_task
        source = self.editor.get_text()
        result = task_checker.check_task(source, task)
        summary = self._result_summary(task, result)
        self._run_ai(lambda: ai_client.explain_task_result(
            summary=summary, lesson_context=self._lesson_context()))

    def _explain_error_ai(self, source: str, raw_error: str):
        if not ai_client.is_configured():
            self._open_dialog(S.SECTION_AI, ai_client.FALLBACK_NO_KEY)
            return
        self._run_ai(lambda: ai_client.explain_compiler_error(
            source=source, raw_error=raw_error, lesson_context=self._lesson_context()))

    def _run_ai(self, fn):
        self._open_dialog(S.SECTION_AI, S.AI_THINKING)
        res = fn()
        self._close_dialog()
        self._open_dialog(S.SECTION_AI, res.text)

    def _lesson_context(self) -> str:
        if not self.current_lesson:
            return ""
        parts = [self.current_lesson.get("title", "")]
        parts += self.current_lesson.get("key_takeaways", [])
        return "\n".join(parts)

    def _result_summary(self, task: dict, result) -> str:
        lines = [f"Задание: {task['title']}", f"Тип: {result.task_type}",
                 f"Скомпилировалось: {'да' if result.compiled else 'нет'}",
                 f"Итог: {'верно' if result.passed else 'неверно'}"]
        for tr in result.test_results:
            lines.append(f"Тест {tr.index+1}: {'OK' if tr.passed else 'не сходится'} "
                         f"(ожидалось {tr.expected!r}, получено {tr.actual!r})")
        return "\n".join(lines)

    def _show_compile_error(self, source: str, stderr: str):
        m = error_dictionary.match_error(stderr)
        if m:
            txt = f"{m.title_ru}\n\n{m.explanation_ru}"
        else:
            txt = "Код не скомпилировался."
        self._set_output(txt + "\n\n— текст ошибки —\n" + stderr, error=True)

    # --- dialog helpers ------------------------------------------------------
    def _open_dialog(self, title: str, text: str):
        dlg = ft.AlertDialog(
            title=ft.Text(title, color=self.pal.text),
            content=ft.Container(
                content=ft.Column([ft.Text(text, color=self.pal.text, selectable=True)],
                                  scroll=ft.ScrollMode.AUTO, tight=True),
                width=520,
            ),
            bgcolor=self.pal.bg_panel,
            actions=[ft.TextButton(S.CLOSE, on_click=lambda e: self._close_dialog())],
        )
        self._show_dialog(dlg)

    def _show_dialog(self, dlg):
        self._dialog = dlg
        self.page.show_dialog(dlg)

    def _close_dialog(self):
        try:
            # Flet 0.85: pop_dialog() closes the topmost open dialog.
            self.page.pop_dialog()
        except Exception:
            try:
                if getattr(self, "_dialog", None):
                    self._dialog.open = False
                self.page.update()
            except Exception:
                pass
