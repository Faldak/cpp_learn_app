"""
ui/app_shell.py
===============
The main application shell: a left NavigationRail (Уроки / Прогресс / Настройки)
plus a content area that swaps between views. Holds shared state (page, theme,
palette) and exposes navigation methods used by the views.
"""

from __future__ import annotations

import flet as ft

import content_loader
import progress_db
from ui import strings_ru as S
from ui import theme as themelib


class AppShell:
    def __init__(self, page: ft.Page):
        self.page = page
        self.theme = progress_db.get_setting("theme", "dark") or "dark"
        self.pal = themelib.palette(self.theme)

        self.content_area = ft.Container(expand=True, padding=0)

        self.rail = ft.NavigationRail(
            selected_index=0,
            label_type=ft.NavigationRailLabelType.ALL,
            min_width=88,
            bgcolor=self.pal.bg_panel,
            indicator_color=self.pal.accent,
            on_change=self._on_nav,
            destinations=[
                ft.NavigationRailDestination(icon=ft.Icons.MENU_BOOK, label=S.NAV_LESSONS),
                ft.NavigationRailDestination(icon=ft.Icons.INSIGHTS, label=S.NAV_DASHBOARD),
                ft.NavigationRailDestination(icon=ft.Icons.SETTINGS, label=S.NAV_SETTINGS),
            ],
        )

        self.root = ft.Row(
            spacing=0,
            expand=True,
            controls=[
                ft.Container(content=self.rail, bgcolor=self.pal.bg_panel,
                             border=ft.Border.only(right=ft.BorderSide(1, self.pal.border))),
                ft.Container(content=self.content_area, expand=True, bgcolor=self.pal.bg),
            ],
        )

    # --- navigation ----------------------------------------------------------
    def _on_nav(self, e):
        idx = e.control.selected_index
        if idx == 0:
            self.show_lessons()
        elif idx == 1:
            self.show_dashboard()
        else:
            self.show_settings()

    def _set_content(self, control):
        self.content_area.content = control
        self.page.update()

    def show_lessons(self, lesson_id: str | None = None):
        from ui.lesson_view import LessonsScreen
        screen = LessonsScreen(self)
        self._set_content(screen.build(lesson_id))

    def open_task(self, task_id: str):
        from ui.lesson_view import LessonsScreen
        screen = LessonsScreen(self)
        self._set_content(screen.build_for_task(task_id))

    def show_dashboard(self):
        from ui.dashboard_view import build_dashboard
        self._set_content(build_dashboard(self))

    def show_settings(self):
        from ui.settings_view import build_settings
        self._set_content(build_settings(self))

    # --- theme ---------------------------------------------------------------
    def set_theme(self, theme: str):
        self.theme = theme
        self.pal = themelib.palette(theme)
        progress_db.set_setting("theme", theme)
        self.page.theme_mode = ft.ThemeMode.DARK if theme == "dark" else ft.ThemeMode.LIGHT
        self.page.bgcolor = self.pal.bg
        # Rebuild whole shell to apply colors.
        self.page.controls.clear()
        new_shell = AppShell(self.page)
        self.page.add(new_shell.root)
        new_shell.show_settings()

    def mount(self):
        self.page.add(self.root)
        # Resume at last position if available.
        resume = progress_db.get_resume_point(content_loader.ordered_lesson_ids())
        self.show_lessons(resume)
