"""
ui/components.py
================
Small reusable styled building blocks shared across views. Keeps the look
consistent (VS-Code-like) and avoids repeating style code.
"""

from __future__ import annotations

from typing import Optional

import flet as ft

from ui import theme as themelib


def heading(text: str, pal: themelib.Palette, size: int = 22) -> ft.Text:
    return ft.Text(text, size=size, weight=ft.FontWeight.BOLD, color=pal.text)


def subtle(text: str, pal: themelib.Palette, size: int = 13) -> ft.Text:
    return ft.Text(text, size=size, color=pal.text_dim)


def body(text: str, pal: themelib.Palette, size: int = 15) -> ft.Text:
    return ft.Text(text, size=size, color=pal.text, selectable=True)


def card(content, pal: themelib.Palette, padding: int = 16) -> ft.Container:
    return ft.Container(
        content=content,
        bgcolor=pal.bg_panel,
        border=ft.Border.all(1, pal.border),
        border_radius=10,
        padding=padding,
    )


def primary_button(text: str, on_click, pal: themelib.Palette,
                   icon: Optional[str] = None, disabled: bool = False) -> ft.Button:
    return ft.Button(content=text, icon=icon, on_click=on_click,
                     bgcolor=pal.accent, color="#ffffff", disabled=disabled)


def secondary_button(text: str, on_click, pal: themelib.Palette,
                     icon: Optional[str] = None) -> ft.Button:
    return ft.Button(content=text, icon=icon, on_click=on_click,
                     bgcolor=pal.bg_elevated, color=pal.text)


def mono_box(text: str, pal: themelib.Palette, *, error: bool = False) -> ft.Container:
    return ft.Container(
        content=ft.Text(text or "", font_family=themelib.MONO_FONT, size=13,
                        color=(pal.error if error else pal.editor_text), selectable=True),
        bgcolor=pal.editor_bg,
        border=ft.Border.all(1, pal.border),
        border_radius=8,
        padding=12,
    )


def chip(text: str, pal: themelib.Palette, color: Optional[str] = None) -> ft.Container:
    return ft.Container(
        content=ft.Text(text, size=12, color="#ffffff"),
        bgcolor=color or pal.accent,
        border_radius=12,
        padding=ft.Padding(10, 4, 10, 4),
    )


def progress_bar(value: float, pal: themelib.Palette, width: Optional[int] = None) -> ft.ProgressBar:
    return ft.ProgressBar(value=max(0.0, min(1.0, value)), color=pal.accent,
                          bgcolor=pal.border, bar_height=8, width=width)
