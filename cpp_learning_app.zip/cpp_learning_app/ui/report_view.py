"""
ui/report_view.py
=================
Renders the result of a deterministic task check (task_checker.CheckResult)
into a friendly Russian report card. Pure presentation — never re-judges.
"""

from __future__ import annotations

import flet as ft

from ui import components as C
from ui import strings_ru as S


def build_report(pal, task: dict, result, cleanliness, *, on_explain, on_explain_error):
    rows = []

    # --- headline ------------------------------------------------------------
    if not result.compiled:
        headline = S.RESULT_COMPILE_FAIL
        hcolor = pal.error
    elif result.passed:
        headline = S.RESULT_PASS
        hcolor = pal.success
    else:
        headline = S.RESULT_FAIL
        hcolor = pal.warning
    rows.append(ft.Text(headline, size=16, weight=ft.FontWeight.BOLD, color=hcolor))

    # --- compile error -------------------------------------------------------
    if not result.compiled:
        import error_dictionary
        m = error_dictionary.match_error(result.compile_error)
        if m:
            rows.append(C.heading(m.title_ru, pal, 14))
            rows.append(C.body(m.explanation_ru, pal, 14))
        rows.append(C.subtle(S.RAW_ERROR_TITLE, pal))
        rows.append(C.mono_box(result.compile_error, pal, error=True))
        rows.append(ft.Button(content=S.BTN_EXPLAIN_MORE, icon=ft.Icons.AUTO_AWESOME,
                              on_click=on_explain_error, bgcolor=pal.bg_elevated, color=pal.text))
        return _wrap(rows, pal)

    # --- output_match tests --------------------------------------------------
    if result.task_type == "output_match" and result.test_results:
        rows.append(C.heading(S.SECTION_TESTS, pal, 14))
        for tr in result.test_results:
            mark = "✓" if tr.passed else "✗"
            mcol = pal.success if tr.passed else pal.error
            inner = [ft.Text(f"{mark} {S.TEST_CASE.format(n=tr.index+1)}",
                             color=mcol, weight=ft.FontWeight.BOLD, size=13)]
            if not tr.passed:
                if tr.stdin:
                    inner.append(_kv(S.TEST_INPUT, tr.stdin, pal))
                inner.append(_kv(S.TEST_EXPECTED, tr.expected, pal))
                inner.append(_kv(S.TEST_GOT, tr.actual, pal))
                if tr.note:
                    inner.append(C.subtle(tr.note, pal))
            rows.append(C.card(ft.Column(inner, spacing=4), pal, padding=10))

    # --- rubric --------------------------------------------------------------
    if result.task_type == "sfml_rubric" and result.rubric_results:
        rows.append(C.heading(S.SECTION_RUBRIC, pal, 14))
        for rr in result.rubric_results:
            mark = S.RUBRIC_PASS if rr.passed else S.RUBRIC_FAIL
            mcol = pal.success if rr.passed else pal.error
            rows.append(ft.Row([ft.Text(mark, color=mcol, size=14),
                                ft.Text(rr.description_ru, color=pal.text, size=13, expand=True)],
                               spacing=8))
        if result.runtime_note_ru:
            rows.append(C.subtle(result.runtime_note_ru, pal))

    # --- cleanliness ---------------------------------------------------------
    rows.append(ft.Container(height=4))
    rows.append(C.heading(S.SECTION_CLEANLINESS, pal, 14))
    stars = "★" * cleanliness.rating + "☆" * (5 - cleanliness.rating)
    rows.append(ft.Text(f"{stars}  ({S.CLEANLINESS_RATING.format(rating=cleanliness.rating)})",
                        color=pal.warning, size=14))
    for n in cleanliness.notes_ru:
        rows.append(C.subtle("• " + n, pal))
    for p in cleanliness.positives_ru:
        rows.append(ft.Text("• " + p, color=pal.success, size=13))

    # --- AI explain button ---------------------------------------------------
    rows.append(ft.Container(height=6))
    rows.append(ft.Button(content=S.BTN_EXPLAIN_RESULT, icon=ft.Icons.AUTO_AWESOME,
                          on_click=on_explain, bgcolor=pal.bg_elevated, color=pal.text))
    return _wrap(rows, pal)


def _kv(label: str, value: str, pal):
    return ft.Column([
        ft.Text(label + ":", size=11, color=pal.text_dim),
        C.mono_box(value if value != "" else "(пусто)", pal),
    ], spacing=2)


def _wrap(rows, pal):
    return C.card(ft.Column(rows, spacing=8), pal)
