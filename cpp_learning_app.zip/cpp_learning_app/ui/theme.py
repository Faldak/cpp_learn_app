"""
ui/theme.py
===========
VS-Code-like dark theme palette + light theme, plus a few shared style helpers.
Colors are plain hex strings (Flet accepts hex color strings everywhere).
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Palette:
    bg: str
    bg_panel: str
    bg_elevated: str
    border: str
    text: str
    text_dim: str
    accent: str
    accent_hover: str
    success: str
    error: str
    warning: str
    editor_bg: str
    editor_text: str
    gutter_bg: str
    gutter_text: str


DARK = Palette(
    bg="#1e1e1e",
    bg_panel="#252526",
    bg_elevated="#2d2d30",
    border="#3c3c3c",
    text="#e6e6e6",
    text_dim="#9d9d9d",
    accent="#0e639c",
    accent_hover="#1177bb",
    success="#4ec9b0",
    error="#f48771",
    warning="#dcdcaa",
    editor_bg="#1e1e1e",
    editor_text="#d4d4d4",
    gutter_bg="#1e1e1e",
    gutter_text="#858585",
)

LIGHT = Palette(
    bg="#f3f3f3",
    bg_panel="#ffffff",
    bg_elevated="#ffffff",
    border="#d4d4d4",
    text="#1e1e1e",
    text_dim="#616161",
    accent="#0e639c",
    accent_hover="#1177bb",
    success="#1a7f64",
    error="#c0392b",
    warning="#8a6d00",
    editor_bg="#ffffff",
    editor_text="#1e1e1e",
    gutter_bg="#f3f3f3",
    gutter_text="#858585",
)

MONO_FONT = "Consolas, 'Courier New', monospace"


def palette(theme: str) -> Palette:
    return LIGHT if theme == "light" else DARK
