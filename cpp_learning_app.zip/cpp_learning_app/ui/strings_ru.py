"""
ui/strings_ru.py
================
ALL user-facing UI strings live here (spec section 8). Never hardcode a
user-facing literal inside a component file — import from here instead. This
keeps the "strictly Russian" requirement auditable and maintainable.

Lesson/task CONTENT does not live here — it lives in content/*.json (also in
Russian). This module is only for the application chrome: buttons, labels,
menu items, static messages, headers, etc.
"""

# --- App ---------------------------------------------------------------------
APP_TITLE = "C++ с нуля"
APP_SUBTITLE = "Учим программирование с самого начала"

# --- Navigation --------------------------------------------------------------
NAV_LESSONS = "Уроки"
NAV_DASHBOARD = "Прогресс"
NAV_SETTINGS = "Настройки"
NAV_CONTINUE = "Продолжить с того места, где остановился"

# --- Lesson view -------------------------------------------------------------
TAB_THEORY = "Теория"
TAB_TASK = "Задание"
THEORY_TAKEAWAYS = "Главное из урока"
THEORY_MISTAKES = "Частые ошибки"
TASK_PROMPT_TITLE = "Что нужно сделать"
BTN_RUN = "Запустить"
BTN_CHECK = "Проверить задание"
BTN_RESET = "Сбросить код"
BTN_HINT = "Подсказка"
BTN_SHOW_SOLUTION = "Показать решение"
BTN_EXPLAIN_MORE = "Объяснить подробнее"
BTN_EXPLAIN_RESULT = "Объяснить результат"
BTN_HELP_TASK = "Помощь с заданием"
OUTPUT_TITLE = "Вывод программы"
OUTPUT_EMPTY = "Здесь появится результат, когда ты запустишь программу."
EDITOR_TITLE = "Твой код"
RUNNING = "Компилирую и запускаю…"
CHECKING = "Проверяю задание…"
AI_THINKING = "ИИ-помощник думает…"

# --- Hints / solution --------------------------------------------------------
HINT_TITLE = "Подсказка {n} из {total}"
NO_MORE_HINTS = "Это была последняя подсказка."
SOLUTION_WARN_TITLE = "Точно показать решение?"
SOLUTION_WARN_BODY = ("Если посмотреть готовый ответ, ты научишься меньше, чем если "
                      "попробуешь сам. Уверен, что хочешь увидеть решение?")
SOLUTION_CONFIRM = "Да, показать"
SOLUTION_CANCEL = "Нет, попробую ещё"

# --- Report ------------------------------------------------------------------
REPORT_TITLE = "Результат проверки"
RESULT_PASS = "Задание решено верно! 🎉"
RESULT_FAIL = "Пока не сходится — посмотри, что не так, и попробуй ещё раз."
RESULT_COMPILE_FAIL = "Код не скомпилировался. Сначала исправь ошибку компиляции."
SECTION_RESULT = "Результат"
SECTION_TESTS = "Проверки"
SECTION_RUBRIC = "Что проверено"
SECTION_CLEANLINESS = "Чистота кода"
SECTION_AI = "Объяснение от ИИ"
SECTION_STATS = "Время и попытки"
TEST_CASE = "Тест {n}"
TEST_INPUT = "Ввод"
TEST_EXPECTED = "Ожидалось"
TEST_GOT = "Получилось"
CLEANLINESS_RATING = "Оценка чистоты: {rating} из 5"
ATTEMPTS_LABEL = "Попыток по этому заданию: {n}"
RUBRIC_PASS = "✓"
RUBRIC_FAIL = "✗"

# --- Errors ------------------------------------------------------------------
ERROR_TITLE = "Ошибка компиляции"
RAW_ERROR_TITLE = "Текст ошибки от компилятора"

# --- Dashboard ---------------------------------------------------------------
DASH_TITLE = "Твой прогресс"
DASH_TODAY = "Отчёт за сегодня"
DASH_WEEK = "Прогресс за неделю"
DASH_OVERALL = "Общий прогресс по курсу"
DASH_STREAK = "Серия дней"
DASH_MISTAKES = "Типичные ошибки"
DASH_TODAY_TMPL = "Сегодня ты решил {passed} задач и провёл за обучением {minutes} минут. {tail}"
DASH_TODAY_GOOD = "Так держать! 💪"
DASH_TODAY_AVG = "Отличный темп — выше твоего обычного!"
DASH_TODAY_QUIET = "Каждый шаг важен — продолжай в своём темпе. 🙂"
DASH_WEEK_TOTAL = "Всего за неделю: {n} задач"
DASH_WEEK_BETTER = "На {n} задач больше, чем на прошлой неделе 🚀"
DASH_WEEK_SAME = "Примерно как на прошлой неделе."
DASH_WEEK_FEWER = "Чуть меньше, чем на прошлой неделе — ничего, наверстаем!"
DASH_STREAK_DAYS = "{n} дн. подряд"
DASH_STREAK_NONE = "Серия пока не начата — реши хотя бы одну задачу сегодня!"
DASH_STREAK_BROKEN = "Серия прервалась, но прогресс никуда не делся — начни новую сегодня!"
DASH_OVERALL_TMPL = "Пройдено {pct}% курса ({done} из {total} задач)"
DASH_NO_MISTAKES = "Пока нет накопленной статистики по ошибкам — это хорошо!"
DASH_MISTAKES_INTRO = "Вот на что стоит обратить внимание:"

# --- Onboarding --------------------------------------------------------------
ONB_TITLE = "Настройка приложения"
ONB_WELCOME = ("Привет! Давай за пару шагов всё настроим. Это нужно сделать один раз. "
               "Я буду объяснять простыми словами.")
ONB_STEP_COMPILER = "Шаг 1. Компилятор C++"
ONB_STEP_SFML = "Шаг 2. Графика (SFML) — можно позже"
ONB_STEP_AI = "Шаг 3. ИИ-помощник (необязательно)"
ONB_COMPILER_OK = "Компилятор найден: {ver} ✅"
ONB_COMPILER_MISSING = ("Компилятор C++ не найден. Без него код запускать нельзя. "
                        "Ниже — как его установить:")
ONB_BTN_RECHECK = "Проверить снова"
ONB_BTN_OPEN_DOWNLOAD = "Открыть страницу загрузки"
ONB_SFML_OK = "SFML найден и работает ✅"
ONB_SFML_MISSING = ("SFML пока не найден. Это нужно только начиная с блока про графику, "
                    "так что можно настроить позже.")
ONB_BTN_SKIP_LATER = "Настроить позже"
ONB_AI_INFO = ("ИИ нужен только чтобы помогать объяснять сложные ошибки — без него "
               "приложение тоже работает, просто без подсказок ИИ.")
ONB_AI_KEY_PLACEHOLDER = "Вставь сюда ключ Groq API"
ONB_BTN_CHECK_KEY = "Проверить ключ"
ONB_BTN_GET_KEY = "Где взять бесплатный ключ"
ONB_BTN_FINISH = "Готово, начать обучение"
ONB_BTN_SKIP_AI = "Пропустить (без ИИ)"

# --- Settings ----------------------------------------------------------------
SET_TITLE = "Настройки"
SET_THEME = "Тема оформления"
SET_THEME_DARK = "Тёмная"
SET_THEME_LIGHT = "Светлая"
SET_AI_MODEL = "Модель ИИ"
SET_AI_KEY = "Ключ Groq API"
SET_AI_KEY_DELETE = "Удалить ключ"
SET_SAVE = "Сохранить"
SET_SAVED = "Сохранено ✅"
SET_RECHECK_TOOLS = "Проверить компилятор и SFML"

# --- Generic -----------------------------------------------------------------
LOADING = "Загрузка…"
CLOSE = "Закрыть"
BACK = "Назад"
NEXT = "Дальше"
EMPTY_SELECT_LESSON = "Выбери урок слева, чтобы начать."
COMPLETED_BADGE = "✓"
IN_PROGRESS_BADGE = "•"

# --- Onboarding additions ---
ONB_INTRO = ("Это твой личный тренажёр по C++ с нуля. Давай за пару шагов всё настроим — "
             "это нужно сделать только один раз.")
ONB_BTN_START = "Начать обучение"
ONB_COMPILER_HELP = ("Установи g++ (MinGW-w64 на Windows, Xcode Command Line Tools на macOS, "
                     "пакет g++ на Linux), затем нажми «Проверить снова».")
ONB_SFML_HELP = ("SFML нужен только для блока про графику. Можно настроить позже в разделе "
                 "«Настройки».")
