"""
ui/dashboard_view.py
====================
Progress dashboard: today's report, weekly progress, streak, overall course
progress, and a "common mistakes" list. All numbers come from progress_db
(deterministic); the encouraging wording is chosen by simple rules here.
"""

from __future__ import annotations

import flet as ft

import content_loader
import progress_db
from ui import components as C
from ui import strings_ru as S


def build_dashboard(shell):
    pal = shell.pal

    today = progress_db.get_day()
    week = progress_db.get_last_n_days(7)
    streak = progress_db.current_streak()
    avg = progress_db.recent_daily_task_average(7)
    passed = progress_db.count_passed_tasks()
    total = content_loader.total_task_count()
    mistakes = progress_db.top_error_patterns(5)

    # --- today ---------------------------------------------------------------
    t_passed = today.get("tasks_passed", 0)
    t_minutes = round(today.get("seconds_spent", 0) / 60)
    if t_passed == 0:
        tail = S.DASH_TODAY_QUIET
    elif t_passed >= max(1, avg):
        tail = S.DASH_TODAY_AVG
    else:
        tail = S.DASH_TODAY_GOOD
    today_text = S.DASH_TODAY_TMPL.format(passed=t_passed, minutes=t_minutes, tail=tail)

    # --- week ----------------------------------------------------------------
    week_total = sum(d.get("tasks_passed", 0) for d in week)
    week_card = C.card(ft.Column([
        C.heading(S.DASH_WEEK, pal, 16),
        ft.Text(S.DASH_WEEK_TOTAL.format(n=week_total), color=pal.text, size=14),
        _week_bars(week, pal),
    ], spacing=8), pal)

    # --- overall -------------------------------------------------------------
    pct = round(100 * passed / total) if total else 0
    overall_card = C.card(ft.Column([
        C.heading(S.DASH_OVERALL, pal, 16),
        ft.Text(S.DASH_OVERALL_TMPL.format(pct=pct, done=passed, total=total),
                color=pal.text, size=14),
        C.progress_bar(passed / total if total else 0, pal),
        _blocks_progress(pal),
    ], spacing=10), pal)

    # --- streak --------------------------------------------------------------
    if streak <= 0:
        streak_text = S.DASH_STREAK_NONE
    else:
        streak_text = S.DASH_STREAK_DAYS.format(n=streak)
    streak_card = C.card(ft.Row([
        ft.Icon(ft.Icons.LOCAL_FIRE_DEPARTMENT, color=pal.warning, size=30),
        ft.Column([C.heading(S.DASH_STREAK, pal, 16),
                   ft.Text(streak_text, color=pal.text, size=14)], spacing=2),
    ], spacing=12), pal)

    today_card = C.card(ft.Column([
        C.heading(S.DASH_TODAY, pal, 16),
        ft.Text(today_text, color=pal.text, size=14),
    ], spacing=8), pal)

    # --- mistakes ------------------------------------------------------------
    if mistakes:
        mrows = [C.subtle(S.DASH_MISTAKES_INTRO, pal)]
        for m in mistakes:
            mrows.append(ft.Text(f"• {m['title_ru']} — {m['count']} раз",
                                 color=pal.text, size=13))
    else:
        mrows = [ft.Text(S.DASH_NO_MISTAKES, color=pal.success, size=14)]
    mistakes_card = C.card(ft.Column([C.heading(S.DASH_MISTAKES, pal, 16), *mrows], spacing=6), pal)

    grid = ft.Column([
        C.heading(S.DASH_TITLE, pal, 24),
        ft.Container(height=6),
        ft.Row([ft.Container(today_card, expand=1), ft.Container(streak_card, expand=1)],
               spacing=14, vertical_alignment=ft.CrossAxisAlignment.START),
        week_card,
        overall_card,
        mistakes_card,
        ft.Container(height=20),
    ], spacing=14, scroll=ft.ScrollMode.AUTO)

    return ft.Container(content=grid, padding=24, expand=True)


def _week_bars(week, pal):
    maxv = max((d.get("tasks_passed", 0) for d in week), default=0) or 1
    bars = []
    for d in week:
        v = d.get("tasks_passed", 0)
        h = 8 + int(60 * v / maxv)
        label = d.get("date", "")[5:]  # MM-DD
        bars.append(ft.Column([
            ft.Container(width=22, height=h, bgcolor=pal.accent, border_radius=4),
            ft.Text(str(v), size=10, color=pal.text_dim),
            ft.Text(label, size=9, color=pal.text_dim),
        ], spacing=2, horizontal_alignment=ft.CrossAxisAlignment.CENTER))
    return ft.Row(bars, spacing=10, vertical_alignment=ft.CrossAxisAlignment.END)


def _blocks_progress(pal):
    rows = []
    for b in content_loader.blocks():
        tids = content_loader.task_ids_for_block(b["block_id"])
        if not tids:
            continue
        done = sum(1 for t in tids
                   if progress_db.get_task_status(t)["best_status"] == "passed")
        rows.append(ft.Row([
            ft.Text(b["title"], size=12, color=pal.text_dim, width=240),
            C.progress_bar(done / len(tids), pal, width=180),
            ft.Text(f"{done}/{len(tids)}", size=12, color=pal.text_dim),
        ], spacing=10))
    return ft.Column(rows, spacing=6)
