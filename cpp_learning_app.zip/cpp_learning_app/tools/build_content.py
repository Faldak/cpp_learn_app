# -*- coding: utf-8 -*-
"""
tools/build_content.py
======================
Turns tools/curriculum.py into content/*.json AND verifies correctness:

  - For every output_match task: compile reference `solution`, run each `stdin`,
    and DERIVE expected_stdout from the known-correct solution. If the solution
    fails to compile or crashes, the build FAILS loudly (so we never ship a
    broken task).
  - For every sfml_rubric task: we don't run SFML at build time (no display),
    but we sanity-check that the rubric source-patterns all match the reference
    solution, so the shipped rubric is self-consistent.

Run:  python3 tools/build_content.py
Output:
  content/course_structure.json
  content/lessons/<lesson_id>.json
  content/tasks/<task_id>.json
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tools"))

import config  # noqa: E402
import compiler_service as cs  # noqa: E402
import curriculum as cur  # noqa: E402


def _verify_output_match(task: dict) -> list[dict]:
    """Compile solution, run each stdin, return test_cases with expected_stdout."""
    solution = task["solution"]
    compiled = cs.compile_source(solution, use_sanitizer=False)
    if not compiled.ok:
        raise SystemExit(
            f"[FAIL] Task {task['id']}: reference solution did not compile:\n"
            f"{compiled.compiler_stderr}"
        )
    test_cases = []
    for stdin in task.get("stdins", [""]):
        rr = cs.run_executable(compiled.executable_path, stdin=stdin)
        if not rr.ran or rr.timed_out or rr.crashed:
            raise SystemExit(
                f"[FAIL] Task {task['id']}: reference solution failed at runtime "
                f"(stdin={stdin!r}, ran={rr.ran}, timeout={rr.timed_out}, "
                f"crashed={rr.crashed}, exit={rr.exit_code})\nstderr={rr.stderr}"
            )
        expected = rr.stdout
        # Normalize trailing whitespace to match the checker's default mode.
        if task.get("comparison_mode", "trim_trailing_whitespace") == "trim_trailing_whitespace":
            expected = "\n".join(line.rstrip() for line in expected.splitlines()).rstrip("\n")
        test_cases.append({"stdin": stdin, "expected_stdout": expected})
    return test_cases


def _verify_sfml(task: dict) -> None:
    src = task["solution"]
    for check in task.get("rubric", []):
        if check.get("check_type") in ("regex_source", "count_regex"):
            if not re.search(check["pattern"], src):
                raise SystemExit(
                    f"[FAIL] Task {task['id']}: rubric pattern "
                    f"{check['pattern']!r} not found in reference solution."
                )


def build():
    config.ensure_dirs()
    config.LESSONS_DIR.mkdir(parents=True, exist_ok=True)
    config.TASKS_DIR.mkdir(parents=True, exist_ok=True)

    # course_structure.json
    structure = {"version": 1, "blocks": cur.BLOCKS}
    config.COURSE_STRUCTURE_FILE.write_text(
        json.dumps(structure, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    n_tasks = 0
    n_verified = 0
    for lesson in cur.ALL_LESSONS:
        block_id = cur.lesson_block_id(lesson["lesson_id"])
        task_ids = []
        for task in lesson["tasks"]:
            ttype = task.get("type", "output_match")
            task_json = {
                "task_id": task["id"],
                "lesson_id": lesson["lesson_id"],
                "block_id": block_id,
                "title": task["title"],
                "type": ttype,
                "difficulty": task.get("difficulty", 1),
                "prompt": task["prompt"],
                "starter_code": task["starter"],
                "comparison_mode": task.get("comparison_mode", "trim_trailing_whitespace"),
                "hints": task.get("hints", []),
                "reference_solution": task["solution"],
            }
            if ttype == "sfml_rubric":
                _verify_sfml(task)
                task_json["rubric_checks"] = task.get("rubric", [])
                task_json["use_sfml"] = True
            else:
                test_cases = _verify_output_match(task)
                task_json["test_cases"] = test_cases
                n_verified += 1

            (config.TASKS_DIR / f"{task['id']}.json").write_text(
                json.dumps(task_json, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            task_ids.append(task["id"])
            n_tasks += 1

        lesson_json = {
            "lesson_id": lesson["lesson_id"],
            "block_id": block_id,
            "order_in_block": lesson["order_in_block"],
            "title": lesson["title"],
            "estimated_minutes": lesson.get("estimated_minutes", 15),
            "theory_blocks": lesson["theory_blocks"],
            "key_takeaways": lesson["key_takeaways"],
            "common_mistakes": lesson["common_mistakes"],
            "task_ids": task_ids,
        }
        (config.LESSONS_DIR / f"{lesson['lesson_id']}.json").write_text(
            json.dumps(lesson_json, ensure_ascii=False, indent=2), encoding="utf-8"
        )

    print(f"[OK] Blocks: {len(cur.BLOCKS)}  Lessons: {len(cur.ALL_LESSONS)}  "
          f"Tasks: {n_tasks}  (output_match verified by compilation: {n_verified})")


if __name__ == "__main__":
    build()
