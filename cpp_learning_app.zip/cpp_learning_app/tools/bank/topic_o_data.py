# -*- coding: utf-8 -*-
"""Тема O — Обработка данных и потоков ввода."""
from ._helper import seq

H = ("#include <iostream>\n#include <vector>\n#include <string>\n#include <map>\n"
     "#include <algorithm>\nusing namespace std;\n")

TASKS = seq("o", [
    (5, "Сумма потока чисел", "Считывай целые числа до конца ввода и выведи их сумму.",
     H + 'int main(){ long s=0,x; while(cin>>x)s+=x; cout<<s; }', ["3 5 7 2\n","10\n"]),
    (5, "Количество чисел", "Считывай числа до конца ввода и выведи, сколько их было.",
     H + 'int main(){ int c=0; long x; while(cin>>x)c++; cout<<c; }', ["3 5 7 2\n","42\n"]),
    (5, "Максимум потока", "Считывай числа до конца ввода и выведи наибольшее.",
     H + 'int main(){ long x,m; cin>>m; while(cin>>x)if(x>m)m=x; cout<<m; }', ["3 9 2 7 1\n","5\n"]),
    (6, "Среднее потока", "Считывай числа до конца ввода и выведи их среднее арифметическое (вещественное).",
     H + 'int main(){ double s=0,x; int c=0; while(cin>>x){s+=x;c++;} cout<<s/c; }', ["2 4 6 8\n"]),
    (6, "Студент с лучшим баллом", "Считывай пары 'имя балл' до конца ввода. Выведи имя студента с наибольшим баллом.",
     H + 'int main(){ string name,best; int g,bg=-1; while(cin>>name>>g)if(g>bg){bg=g;best=name;} cout<<best; }', ["Anna 80\nBob 95\nCat 90\n"]),
    (6, "Гистограмма цифр потока", "Считай число. Выведи 10 строк: для каждой цифры от 0 до 9 её количество в записи числа.",
     H + 'int main(){ string s; cin>>s; int f[10]={0}; for(char c:s)if(isdigit(c))f[c-\'0\']++; for(int i=0;i<10;i++)cout<<i<<": "<<f[i]<<"\\n"; }', ["1122233\n"]),
    (6, "Сумма по категориям", "Считывай пары 'категория сумма' до конца ввода. Выведи каждую категорию и её суммарную сумму (в алфавитном порядке): 'категория сумма'.",
     H + 'int main(){ map<string,long> m; string c; long v; while(cin>>c>>v)m[c]+=v; for(auto&p:m)cout<<p.first<<" "<<p.second<<"\\n"; }', ["food 100\ntoys 50\nfood 30\n"]),
    (6, "Статистика чисел", "Считывай числа до конца ввода. Выведи через пробел минимум, максимум и сумму.",
     H + 'int main(){ long x,mn,mx,s=0; cin>>x; mn=mx=x; s=x; while(cin>>x){mn=min(mn,x);mx=max(mx,x);s+=x;} cout<<mn<<" "<<mx<<" "<<s; }', ["3 9 2 7 1\n"]),
    (6, "Сколько прошли порог", "Считай порог t, затем числа до конца ввода. Выведи, сколько из них больше или равны t.",
     H + 'int main(){ long t,x; cin>>t; int c=0; while(cin>>x)if(x>=t)c++; cout<<c; }', ["50\n10 60 50 49 80\n"]),
    (6, "Самое длинное слово", "Считывай слова до конца ввода и выведи самое длинное (при равенстве — первое встреченное).",
     H + 'int main(){ string w,best; while(cin>>w)if(w.size()>best.size())best=w; cout<<best; }', ["кот собака программа да\n"]),
    (6, "Подсчёт слов по частоте", "Считывай слова до конца ввода. Выведи слово, встречающееся чаще всего (при равенстве — лексикографически меньшее).",
     H + 'int main(){ map<string,int> m; string w; while(cin>>w)m[w]++; string best; int bc=0; for(auto&p:m)if(p.second>bc){bc=p.second;best=p.first;} cout<<best; }', ["a b a c a b\n"]),
    (7, "Медиана потока", "Считай n, затем n чисел. Выведи медиану (для чётного n — меньший из двух центральных).",
     H + 'int main(){ int n; cin>>n; vector<long> a(n); for(auto&x:a)cin>>x; sort(a.begin(),a.end()); cout<<a[(n-1)/2]; }', ["5\n5 3 1 4 2\n","4\n4 1 3 2\n"]),
    (6, "Текущий максимум", "Считай n чисел. После каждого выводи текущий максимум среди прочитанных, через пробел.",
     H + 'int main(){ int n; cin>>n; long x,m; for(int i=0;i<n;i++){cin>>x; if(i==0||x>m)m=x; cout<<m<<" ";} }', ["5\n3 1 9 2 9\n"]),
    (6, "Количество уникальных в потоке", "Считывай числа до конца ввода и выведи количество различных значений.",
     H + '#include <set>\nint main(){ set<long> s; long x; while(cin>>x)s.insert(x); cout<<s.size(); }', ["1 2 2 3 3 3\n"]),
    (7, "Топ-3 по баллу", "Считывай пары 'имя балл' до конца ввода. Выведи имена трёх лучших по убыванию балла через пробел.",
     H + 'int main(){ vector<pair<int,string>> v; string n; int g; while(cin>>n>>g)v.push_back({g,n}); sort(v.rbegin(),v.rend()); for(int i=0;i<3&&i<(int)v.size();i++)cout<<v[i].second<<" "; }', ["Anna 80\nBob 95\nCat 90\nDan 70\n"]),
    (6, "Среднее без минимума и максимума", "Считай n (n>=3) и n чисел. Выведи среднее арифметическое, исключив один минимальный и один максимальный элемент (вещественное).",
     H + 'int main(){ int n; cin>>n; vector<long> a(n); for(auto&x:a)cin>>x; sort(a.begin(),a.end()); double s=0; for(int i=1;i<n-1;i++)s+=a[i]; cout<<s/(n-2); }', ["5\n1 2 3 4 100\n"]),
], "O")
