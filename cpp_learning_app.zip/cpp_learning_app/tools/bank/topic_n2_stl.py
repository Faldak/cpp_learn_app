# -*- coding: utf-8 -*-
"""Тема N (вторая волна) — STL: контейнеры и алгоритмы."""
from ._helper import seq

H = ("#include <iostream>\n#include <vector>\n#include <algorithm>\n#include <set>\n"
     "#include <map>\n#include <numeric>\n#include <string>\nusing namespace std;\n")
RD = "int n; cin>>n; vector<int> a(n); for(int i=0;i<n;i++)cin>>a[i]; "

TASKS = seq("n2", [
    (5, "Отсортировать по убыванию", "Считай n и n чисел. Выведи их по убыванию через пробел.",
     H + 'int main(){ ' + RD + 'sort(a.rbegin(),a.rend()); for(int x:a)cout<<x<<" "; }', ["5\n3 1 4 1 5\n"]),
    (5, "Количество различных", "Считай n и n чисел. Выведи количество различных значений (через set).",
     H + 'int main(){ ' + RD + 'set<int> s(a.begin(),a.end()); cout<<s.size(); }', ["6\n1 2 2 3 3 3\n"]),
    (5, "Сумма через accumulate", "Считай n и n чисел. Выведи их сумму, используя accumulate.",
     H + 'int main(){ ' + RD + 'cout<<accumulate(a.begin(),a.end(),0L); }', ["5\n1 2 3 4 5\n"]),
    (5, "Мин и макс", "Считай n и n чисел. Выведи через пробел минимум и максимум (через minmax_element).",
     H + 'int main(){ ' + RD + 'auto p=minmax_element(a.begin(),a.end()); cout<<*p.first<<" "<<*p.second; }', ["5\n3 1 4 1 5\n"]),
    (5, "Индекс элемента", "Считай n, n чисел и значение x. Выведи индекс первого вхождения x или -1.",
     H + 'int main(){ ' + RD + 'int x; cin>>x; auto it=find(a.begin(),a.end(),x); cout<<(it==a.end()?-1:(int)(it-a.begin())); }', ["5\n1 2 3 4 5\n3\n","5\n1 2 3 4 5\n9\n"]),
    (6, "Самое частое число", "Считай n и n чисел. Выведи число, которое встречается чаще всего (при равенстве — наименьшее).",
     H + 'int main(){ ' + RD + 'map<int,int> f; for(int x:a)f[x]++; int best=a[0],bc=0; for(auto&kv:f)if(kv.second>bc){bc=kv.second;best=kv.first;} cout<<best; }', ["7\n1 2 2 3 3 3 1\n"]),
    (6, "Частота слов: максимум", "Считывай слова до конца ввода. Выведи слово с максимальной частотой (при равенстве — лексикографически наименьшее).",
     H + 'int main(){ string w; map<string,int> f; while(cin>>w)f[w]++; string best; int bc=-1; for(auto&kv:f)if(kv.second>bc){bc=kv.second;best=kv.first;} cout<<best; }', ["apple pear apple banana pear apple\n"]),
    (6, "Есть ли пара с суммой", "Считай n, n чисел и цель s. Выведи \"да\", если есть два различных элемента с суммой s, иначе \"нет\".",
     H + 'int main(){ ' + RD + 'long s; cin>>s; set<long> seen; bool ok=false; for(int x:a){ if(seen.count(s-x))ok=true; seen.insert(x);} cout<<(ok?"да":"нет"); }', ["5\n1 2 3 4 5\n9\n","4\n1 2 3 4\n100\n"]),
    (5, "Развернуть вектор", "Считай n и n чисел. Выведи их в обратном порядке (через reverse) через пробел.",
     H + 'int main(){ ' + RD + 'reverse(a.begin(),a.end()); for(int x:a)cout<<x<<" "; }', ["5\n1 2 3 4 5\n"]),
    (6, "Сортировка пар по второму", "Считай n и n пар (ключ значение). Отсортируй по значению по возрастанию и выведи ключи через пробел.",
     H + 'int main(){ int n; cin>>n; vector<pair<int,int>> v(n); for(auto&p:v)cin>>p.first>>p.second; sort(v.begin(),v.end(),[](auto&a,auto&b){return a.second<b.second;}); for(auto&p:v)cout<<p.first<<" "; }', ["3\n1 30 2 10 3 20\n"]),
    (6, "Медиана", "Считай n (нечётное) и n чисел. Выведи медиану (средний по величине элемент).",
     H + 'int main(){ ' + RD + 'sort(a.begin(),a.end()); cout<<a[n/2]; }', ["5\n5 3 1 4 2\n","3\n10 30 20\n"]),
    (7, "Скользящая сумма k", "Считай n, n чисел и k. Выведи максимальную сумму k подряд идущих элементов.",
     H + 'int main(){ ' + RD + 'int k; cin>>k; long s=0; for(int i=0;i<k;i++)s+=a[i]; long best=s; for(int i=k;i<n;i++){s+=a[i]-a[i-k]; if(s>best)best=s;} cout<<best; }', ["6\n1 2 3 4 5 6\n2\n"]),
], "N2")
