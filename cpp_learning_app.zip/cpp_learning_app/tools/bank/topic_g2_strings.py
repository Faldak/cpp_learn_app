# -*- coding: utf-8 -*-
"""Тема G (вторая волна) — Строки."""
from ._helper import seq

H = "#include <iostream>\n#include <string>\n#include <algorithm>\nusing namespace std;\n"

TASKS = seq("g2", [
    (4, "Сколько пробелов", "Считай строку целиком и выведи количество пробелов в ней.",
     H + 'int main(){ string s; getline(cin,s); int c=0; for(char ch:s)if(ch==\' \')c++; cout<<c; }', ["a b c d\n","нет\n"]),
    (4, "Строка пустая?", 'Считай строку целиком. Выведи "да", если она пустая, иначе "нет".',
     H + 'int main(){ string s; getline(cin,s); cout<<(s.empty()?"да":"нет"); }', ["\n","привет\n"]),
    (4, "Заменить пробелы", "Считай строку целиком и выведи её, заменив все пробелы на символ подчёркивания.",
     H + 'int main(){ string s; getline(cin,s); for(char&c:s)if(c==\' \')c=\'_\'; cout<<s; }', ["one two three\n","ab\n"]),
    (4, "Громко", "Считай слово из латинских букв. Выведи его заглавными буквами с восклицательным знаком в конце.",
     H + 'int main(){ string s; cin>>s; for(char&c:s)c=toupper(c); cout<<s<<"!"; }', ["hello\n","ok\n"]),
    (4, "Средний символ", "Считай слово нечётной длины из латинских букв и выведи его средний символ.",
     H + 'int main(){ string s; cin>>s; cout<<s[s.size()/2]; }', ["abcde\n","x\n"]),
    (4, "Все заглавные?", 'Считай слово из латинских букв. Выведи "да", если все буквы заглавные, иначе "нет".',
     H + 'int main(){ string s; cin>>s; bool ok=!s.empty(); for(char c:s)if(!isupper((unsigned char)c))ok=false; cout<<(ok?"да":"нет"); }', ["HELLO\n","Hello\n"]),
    (4, "Обрезать до k", "Считай слово и число k. Выведи первые k символов слова (если слово короче, выведи его целиком).",
     H + 'int main(){ string s; int k; cin>>s>>k; cout<<s.substr(0,k); }', ["programming 4\n","ab 5\n"]),
    (4, "Символ по индексу", "Считай слово из латинских букв и индекс i. Выведи символ, стоящий на позиции i (с нуля).",
     H + 'int main(){ string s; int i; cin>>s>>i; cout<<s[i]; }', ["hello 1\n","abc 0\n"]),
    (4, "Поменять края слова", "Считай слово из латинских букв (длиной >=2). Поменяй местами первый и последний символы и выведи результат.",
     H + 'int main(){ string s; cin>>s; swap(s[0],s.back()); cout<<s; }', ["hello\n","ab\n"]),
    (5, "Буквы и цифры", "Считай слово и выведи через пробел количество букв и количество цифр в нём.",
     H + 'int main(){ string s; cin>>s; int a=0,d=0; for(char c:s){if(isalpha((unsigned char)c))a++; else if(isdigit((unsigned char)c))d++;} cout<<a<<" "<<d; }', ["ab12c3\n","abc\n"]),
    (5, "Слов с заглавной", "Считай строку целиком. Выведи количество слов, начинающихся с заглавной латинской буквы.",
     H + 'int main(){ string s; getline(cin,s); int c=0; bool start=true; for(char ch:s){ if(ch==\' \'){start=true;} else { if(start&&ch>=\'A\'&&ch<=\'Z\')c++; start=false; } } cout<<c; }', ["Hello World foo Bar\n"]),
    (4, "Сколько раз символ (без регистра)", "Считай слово из латинских букв и символ. Выведи, сколько раз символ встречается без учёта регистра.",
     H + 'int main(){ string s; char k; cin>>s>>k; int c=0; char kl=tolower(k); for(char ch:s)if(tolower((unsigned char)ch)==kl)c++; cout<<c; }', ["BananA a\n","Cpp p\n"]),
    (5, "Заглавная каждое слово", "Считай строку целиком (латиница). Выведи её, сделав первую букву каждого слова заглавной.",
     H + 'int main(){ string s; getline(cin,s); bool start=true; for(char&c:s){ if(c==\' \')start=true; else { if(start)c=toupper(c); start=false; } } cout<<s; }', ["hello world\n","one two three\n"]),
    (4, "Последний символ — цифра?", 'Считай слово. Выведи "да", если его последний символ — цифра, иначе "нет".',
     H + 'int main(){ string s; cin>>s; cout<<(isdigit((unsigned char)s.back())?"да":"нет"); }', ["abc7\n","abc\n"]),
    (5, "Удвоить гласные", "Считай слово из латинских букв. Каждую гласную (a,e,i,o,u) выведи дважды, остальные символы — один раз.",
     H + 'int main(){ string s; cin>>s; string v="aeiou"; for(char c:s){cout<<c; if(v.find(c)!=string::npos)cout<<c;} }', ["cat\n","sky\n"]),
    (5, "Количество слов (поток)", "Считывай слова до конца ввода и выведи их количество.",
     H + 'int main(){ string w; int c=0; while(cin>>w)c++; cout<<c; }', ["раз два три четыре\n","one\n"]),
], "G2")
