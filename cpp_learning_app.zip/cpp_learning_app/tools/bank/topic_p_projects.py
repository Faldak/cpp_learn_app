# -*- coding: utf-8 -*-
"""Тема P — Мини-проекты уровня junior (комплексные задачи)."""
from ._helper import seq

H = ("#include <iostream>\n#include <vector>\n#include <string>\n#include <cmath>\n"
     "#include <algorithm>\nusing namespace std;\n")

TASKS = seq("p", [
    (6, "Калькулятор", "Считай выражение вида 'a op b', где op — один из + - * /. Выведи результат (для / — целочисленное деление, делитель не ноль).",
     H + 'int main(){ long a,b; char op; cin>>a>>op>>b; long r=0; if(op==\'+\')r=a+b; else if(op==\'-\')r=a-b; else if(op==\'*\')r=a*b; else r=a/b; cout<<r; }', ["6 + 4\n","8 / 2\n","3 * 7\n"]),
    (6, "Оценка по среднему", "Считай n оценок. Выведи среднее (вещественное) и через пробел буквенную оценку: A (>=90), B (>=75), C (>=60), F иначе.",
     H + 'int main(){ int n; cin>>n; double s=0; for(int i=0;i<n;i++){int x;cin>>x;s+=x;} double a=s/n; char g; if(a>=90)g=\'A\'; else if(a>=75)g=\'B\'; else if(a>=60)g=\'C\'; else g=\'F\'; cout<<a<<" "<<g; }', ["3\n90 95 100\n","2\n50 60\n"]),
    (7, "Крестики-нолики: победитель", "Считай поле 3×3 из символов X, O и . (точка — пусто). Выведи 'X', 'O' или 'нет' (если никто не выиграл по строке/столбцу/диагонали).",
     H + 'int main(){ char b[3][3]; for(int i=0;i<3;i++)for(int j=0;j<3;j++)cin>>b[i][j]; auto win=[&](char c){ for(int i=0;i<3;i++){if(b[i][0]==c&&b[i][1]==c&&b[i][2]==c)return true; if(b[0][i]==c&&b[1][i]==c&&b[2][i]==c)return true;} if(b[0][0]==c&&b[1][1]==c&&b[2][2]==c)return true; if(b[0][2]==c&&b[1][1]==c&&b[2][0]==c)return true; return false; }; if(win(\'X\'))cout<<"X"; else if(win(\'O\'))cout<<"O"; else cout<<"нет"; }', ["X X X\nO O .\n. . .\n","X O X\nO X O\nO X O\n"]),
    (7, "Римское число в десятичное", "Считай римское число (заглавные I V X L C D M) и выведи его десятичное значение.",
     H + 'int val(char c){ switch(c){case \'I\':return 1;case \'V\':return 5;case \'X\':return 10;case \'L\':return 50;case \'C\':return 100;case \'D\':return 500;case \'M\':return 1000;} return 0; }\nint main(){ string s; cin>>s; int r=0; for(int i=0;i<(int)s.size();i++){int v=val(s[i]); if(i+1<(int)s.size()&&val(s[i+1])>v)r-=v; else r+=v;} cout<<r; }', ["XIV\n","MCMXCIV\n","III\n"]),
    (7, "Десятичное в римское", "Считай число от 1 до 3999 и выведи его римскую запись.",
     H + 'int main(){ int n; cin>>n; int v[]={1000,900,500,400,100,90,50,40,10,9,5,4,1}; string s[]={"M","CM","D","CD","C","XC","L","XL","X","IX","V","IV","I"}; string r; for(int i=0;i<13;i++)while(n>=v[i]){r+=s[i];n-=v[i];} cout<<r; }', ["14\n","1994\n","3\n"]),
    (6, "Проверка пароля", "Считай слово-пароль. Выведи 'надёжный', если длина >=8 и есть хотя бы одна цифра и одна буква, иначе 'слабый'.",
     H + 'int main(){ string s; cin>>s; bool d=false,a=false; for(char c:s){if(isdigit(c))d=true; if(isalpha(c))a=true;} cout<<((s.size()>=8&&d&&a)?"надёжный":"слабый"); }', ["abc12345\n","short1\n"]),
    (6, "Индекс массы тела", "Считай вес (кг) и рост (м). Выведи ИМТ (вес/рост^2, вещественный) и через пробел категорию: 'недовес' (<18.5), 'норма' (<25), 'избыток' иначе.",
     H + 'int main(){ double w,h; cin>>w>>h; double b=w/(h*h); string c; if(b<18.5)c="недовес"; else if(b<25)c="норма"; else c="избыток"; cout<<b<<" "<<c; }', ["70 1.75\n","50 1.7\n"]),
    (6, "Сдача автомата", "Считай сумму к выдаче. Выведи количество купюр/монет номиналами 100, 50, 10, 5, 1 через пробел (жадно).",
     H + 'int main(){ int s; cin>>s; int d[]={100,50,10,5,1}; for(int x:d){cout<<s/x<<" "; s%=x;} }', ["186\n","5\n"]),
    (6, "Корни квадратного уравнения", "Считай a, b, c. Если есть два корня — выведи их по возрастанию через пробел; один — выведи его; нет — выведи 'нет'.",
     H + 'int main(){ double a,b,c; cin>>a>>b>>c; double d=b*b-4*a*c; if(d>0){double x1=(-b-sqrt(d))/(2*a),x2=(-b+sqrt(d))/(2*a); cout<<min(x1,x2)<<" "<<max(x1,x2);} else if(d==0)cout<<-b/(2*a); else cout<<"нет"; }', ["1 -3 2\n","1 2 1\n","1 0 1\n"]),
    (6, "Статистика текста", "Считай строку целиком. Выведи через пробел: количество символов (включая пробелы), количество слов, количество букв.",
     H + 'int main(){ string line; getline(cin,line); int chars=line.size(),letters=0,words=0; bool in=false; for(char c:line){if(isalpha((unsigned char)c))letters++; if(c==\' \'){in=false;} else {if(!in)words++; in=true;}} cout<<chars<<" "<<words<<" "<<letters; }', ["abc de f\n"]),
    (7, "Шифр Цезаря: кодирование", "Считай сдвиг k и слово из строчных латинских букв. Выведи зашифрованное слово (сдвиг по алфавиту на k).",
     H + 'int main(){ int k; string s; cin>>k>>s; for(char&c:s)c=\'a\'+((c-\'a\'+k)%26+26)%26; cout<<s; }', ["3 abc\n","1 xyz\n"]),
    (6, "Конвертер температуры", "Считай букву C или F и значение. Если C — переведи в Фаренгейты, если F — в Цельсии. Выведи результат (вещественный).",
     H + 'int main(){ char u; double v; cin>>u>>v; if(u==\'C\')cout<<v*9/5+32; else cout<<(v-32)*5/9; }', ["C 100\n","F 32\n"]),
    (6, "Корзина со скидкой", "Считай n цен. Посчитай сумму; если она больше 1000 — примени скидку 10%. Выведи итог (целочисленно).",
     H + 'int main(){ int n; cin>>n; long s=0; for(int i=0;i<n;i++){long x;cin>>x;s+=x;} if(s>1000)s-=s/10; cout<<s; }', ["3\n500 400 300\n","2\n100 200\n"]),
    (6, "Определитель 2×2", "Считай матрицу 2×2 (4 числа). Выведи её определитель (ad - bc).",
     H + 'int main(){ long a,b,c,d; cin>>a>>b>>c>>d; cout<<a*d-b*c; }', ["1 2 3 4\n","2 0 0 2\n"]),
    (7, "Простая инвентаризация", "Считывай пары 'товар количество' до конца ввода. Выведи общее количество всех товаров и через пробел число различных товаров.",
     H + '#include <set>\nint main(){ string t; long q,total=0; set<string> kinds; while(cin>>t>>q){total+=q;kinds.insert(t);} cout<<total<<" "<<kinds.size(); }', ["apple 3\nbanana 2\napple 5\n"]),
    (6, "Возраст по году", "Считай текущий год и год рождения. Выведи возраст и через пробел 'совершеннолетний' (>=18) или 'несовершеннолетний'.",
     H + 'int main(){ int cur,by; cin>>cur>>by; int age=cur-by; cout<<age<<" "<<(age>=18?"совершеннолетний":"несовершеннолетний"); }', ["2026 2000\n","2026 2015\n"]),
    (7, "Меню заказа", "Считай n позиций вида 'цена количество'. Выведи итоговую сумму заказа и через пробел среднюю стоимость позиции (вещественную).",
     H + 'int main(){ int n; cin>>n; long total=0; for(int i=0;i<n;i++){long p,q;cin>>p>>q;total+=p*q;} cout<<total<<" "<<(double)total/n; }', ["3\n100 2\n50 1\n30 3\n"]),
    (6, "Проверка скобок", "Считай строку из скобок ( и ). Выведи 'да', если они сбалансированы, иначе 'нет'.",
     H + 'int main(){ string s; cin>>s; int bal=0; bool ok=true; for(char c:s){if(c==\'(\')bal++; else{bal--; if(bal<0)ok=false;}} cout<<((ok&&bal==0)?"да":"нет"); }', ["(())\n","(()\n",")(\n"]),
], "P")
