# -*- coding: utf-8 -*-
"""Helpers for authoring the task bank compactly."""
from __future__ import annotations
import re

_DEFAULT_HINTS = [
    "Внимательно перечитай условие и определи, что подаётся на вход и что нужно вывести.",
    "Разбей решение на маленькие шаги и проверь каждый.",
    "Сверься с примером кода из теории этого урока.",
]


def _starter_from(solution: str, level: int) -> str:
    """Build a beginner-friendly skeleton: keep the includes, empty main."""
    includes = [ln for ln in solution.splitlines() if ln.strip().startswith("#include")]
    if not includes:
        includes = ["#include <iostream>"]
    head = "\n".join(includes)
    return f"{head}\nusing namespace std;\n\nint main() {{\n    // TODO: напиши решение\n    return 0;\n}}\n"


def mk(id, level, topic, title, prompt, solution,
       stdins=None, hints=None, starter=None):
    if stdins is None:
        stdins = [""]
    if hints is None:
        hints = _DEFAULT_HINTS
    if starter is None:
        starter = _starter_from(solution, level)
    return {
        "id": id, "level": level, "topic": topic, "title": title,
        "prompt": prompt, "solution": solution, "stdins": stdins,
        "hints": hints, "starter": starter,
    }


def seq(prefix, items, topic):
    """Build tasks from compact tuples.
    Each item: (level, title, prompt, solution[, stdins[, hints]]).
    Auto-numbers ids as prefix_1, prefix_2, ..."""
    out = []
    for i, it in enumerate(items, 1):
        level, title, prompt, solution = it[0], it[1], it[2], it[3]
        stdins = it[4] if len(it) > 4 else None
        hints = it[5] if len(it) > 5 else None
        out.append(mk(f"{prefix}_{i}", level, topic, title, prompt, solution,
                      stdins=stdins, hints=hints))
    return out
