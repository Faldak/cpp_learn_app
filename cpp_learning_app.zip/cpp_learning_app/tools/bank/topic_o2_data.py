# -*- coding: utf-8 -*-
"""Тема O (вторая волна) — Структуры данных (стек, очередь, множества)."""
from ._helper import seq

H = ("#include <iostream>\n#include <vector>\n#include <stack>\n#include <queue>\n"
     "#include <set>\n#include <string>\n#include <algorithm>\nusing namespace std;\n")

TASKS = seq("o2", [
    (6, "Скобки сбалансированы?", "Считай строку из скобок ()[]{}. Выведи \"да\", если скобки сбалансированы, иначе \"нет\".",
     H + 'int main(){ string s; getline(cin,s); stack<char> st; bool ok=true; for(char c:s){ if(c==\'(\'||c==\'[\'||c==\'{\')st.push(c); else if(c==\')\'||c==\']\'||c==\'}\'){ if(st.empty()){ok=false;break;} char t=st.top(); st.pop(); if((c==\')\'&&t!=\'(\')||(c==\']\'&&t!=\'[\')||(c==\'}\'&&t!=\'{\')){ok=false;break;} } } if(!st.empty())ok=false; cout<<(ok?"да":"нет"); }', ["([{}])\n","([)]\n","(()\n"]),
    (5, "Развернуть стеком", "Считай n и n чисел. С помощью стека выведи их в обратном порядке через пробел.",
     H + 'int main(){ int n; cin>>n; stack<int> st; for(int i=0;i<n;i++){int x; cin>>x; st.push(x);} while(!st.empty()){cout<<st.top()<<" "; st.pop();} }', ["5\n1 2 3 4 5\n"]),
    (6, "Очередь: средний", "Считай n и n чисел в очередь. Извлекай по одному и выведи через пробел те, что стоят на нечётных позициях извлечения (1-я, 3-я, ...).",
     H + 'int main(){ int n; cin>>n; queue<int> q; for(int i=0;i<n;i++){int x; cin>>x; q.push(x);} int pos=1; while(!q.empty()){ int v=q.front(); q.pop(); if(pos%2==1)cout<<v<<" "; pos++; } }', ["5\n10 20 30 40 50\n"]),
    (5, "Сколько различных слов", "Считывай слова до конца ввода и выведи количество различных слов (через set).",
     H + 'int main(){ string w; set<string> s; while(cin>>w)s.insert(w); cout<<s.size(); }', ["apple pear apple banana\n"]),
    (7, "Максимум в окне стеком", "Считай n и n чисел. Для каждого элемента выведи через пробел индекс ближайшего предыдущего строго большего элемента или -1 (монотонный стек).",
     H + 'int main(){ int n; cin>>n; vector<int> a(n); for(int i=0;i<n;i++)cin>>a[i]; stack<int> st; for(int i=0;i<n;i++){ while(!st.empty()&&a[st.top()]<=a[i])st.pop(); cout<<(st.empty()?-1:st.top())<<" "; st.push(i);} }', ["5\n2 1 3 2 5\n"]),
    (6, "k-й по величине", "Считай n, n чисел и k. Выведи k-й по величине элемент (1 — наибольший).",
     H + 'int main(){ int n; cin>>n; vector<int> a(n); for(int i=0;i<n;i++)cin>>a[i]; int k; cin>>k; sort(a.rbegin(),a.rend()); cout<<a[k-1]; }', ["5\n3 1 4 1 5\n2\n"]),
    (7, "Слияние двух очередей", "Считай два отсортированных по возрастанию массива (с длинами) и выведи слитый отсортированный массив через пробел.",
     H + 'int main(){ int n; cin>>n; vector<int> a(n); for(auto&x:a)cin>>x; int m; cin>>m; vector<int> b(m); for(auto&x:b)cin>>x; vector<int> r; merge(a.begin(),a.end(),b.begin(),b.end(),back_inserter(r)); for(int x:r)cout<<x<<" "; }', ["3\n1 3 5\n3\n2 4 6\n"]),
    (6, "Уникальные по порядку", "Считай n и n чисел. Выведи элементы в исходном порядке, пропуская повторные вхождения (каждое значение печатается один раз).",
     H + 'int main(){ int n; cin>>n; set<int> seen; for(int i=0;i<n;i++){int x; cin>>x; if(!seen.count(x)){cout<<x<<" "; seen.insert(x);}} }', ["6\n1 2 2 3 1 4\n"]),
], "O2")
