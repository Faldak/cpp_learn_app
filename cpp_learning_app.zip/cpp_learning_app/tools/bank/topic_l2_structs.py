# -*- coding: utf-8 -*-
"""Тема L (вторая волна) — Структуры."""
from ._helper import seq

H = "#include <iostream>\n#include <cmath>\n#include <string>\nusing namespace std;\n"

TASKS = seq("l2", [
    (5, "Расстояние между точками", "Опиши структуру Point{x,y}. Считай координаты двух точек и выведи расстояние между ними (вещественное).",
     H + 'struct Point{double x,y;}; int main(){ Point a,b; cin>>a.x>>a.y>>b.x>>b.y; cout<<sqrt((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y)); }', ["0 0 3 4\n","1 1 1 1\n"]),
    (5, "Площадь прямоугольника", "Опиши структуру Rect{w,h}. Считай ширину и высоту, выведи через пробел площадь и периметр.",
     H + 'struct Rect{long w,h;}; int main(){ Rect r; cin>>r.w>>r.h; cout<<r.w*r.h<<" "<<2*(r.w+r.h); }', ["3 4\n","5 5\n"]),
    (5, "Студент и оценка", "Опиши структуру Student{name, grade}. Считай имя и оценку, выведи их в формате: name - grade.",
     H + 'struct Student{string name; int grade;}; int main(){ Student s; cin>>s.name>>s.grade; cout<<s.name<<" - "<<s.grade; }', ["Anna 5\n","Bob 3\n"]),
    (6, "Сложить дроби", "Опиши структуру Fraction{num,den}. Считай две дроби и выведи их сумму как несокращённую дробь в формате a/b.",
     H + 'struct Fr{long n,d;}; int main(){ Fr a,b; cin>>a.n>>a.d>>b.n>>b.d; cout<<a.n*b.d+b.n*a.d<<"/"<<a.d*b.d; }', ["1 2 1 3\n","1 4 1 4\n"]),
    (5, "Скалярное произведение", "Опиши структуру Vec2{x,y}. Считай два вектора и выведи их скалярное произведение.",
     H + 'struct Vec2{long x,y;}; int main(){ Vec2 a,b; cin>>a.x>>a.y>>b.x>>b.y; cout<<a.x*b.x+a.y*b.y; }', ["1 2 3 4\n","0 0 5 5\n"]),
    (6, "Ближе к началу координат", "Опиши структуру Point{x,y}. Считай две точки и выведи координаты той, что ближе к началу координат (при равенстве — первую), в формате x y.",
     H + 'struct P{long x,y;}; long d2(P p){return p.x*p.x+p.y*p.y;} int main(){ P a,b; cin>>a.x>>a.y>>b.x>>b.y; P r=d2(a)<=d2(b)?a:b; cout<<r.x<<" "<<r.y; }', ["1 1 3 3\n","5 0 2 2\n"]),
    (6, "Какая дата раньше", "Опиши структуру Date{y,m,d}. Считай две даты (год месяц день) и выведи \"первая\" или \"вторая\" — какая раньше (при равенстве — \"равны\").",
     H + 'struct D{int y,m,d;}; long key(D x){return (long)x.y*10000+x.m*100+x.d;} int main(){ D a,b; cin>>a.y>>a.m>>a.d>>b.y>>b.m>>b.d; long ka=key(a),kb=key(b); cout<<(ka<kb?"первая":(ka>kb?"вторая":"равны")); }', ["2020 5 1 2021 1 1\n","2020 5 1 2020 5 1\n"]),
    (5, "Площадь круга", "Опиши структуру Circle{r}. Считай радиус и выведи площадь круга (3.14159*r*r).",
     H + 'struct Circle{double r;}; int main(){ Circle c; cin>>c.r; cout<<3.14159*c.r*c.r; }', ["2\n","1\n"]),
    (5, "Сумма денег", "Опиши структуру Money{rub,kop} (рубли и копейки 0..99). Считай две суммы и выведи их сумму в формате rub kop (с переносом 100 копеек в рубль).",
     H + 'struct M{long r,k;}; int main(){ M a,b; cin>>a.r>>a.k>>b.r>>b.k; long k=a.k+b.k; long r=a.r+b.r+k/100; k%=100; cout<<r<<" "<<k; }', ["10 50 5 60\n","1 0 2 0\n"]),
    (6, "Прибавить секунды ко времени", "Опиши структуру Time{h,m,s}. Считай время (часы минуты секунды) и количество секунд для прибавления. Выведи новое время в формате h m s (с переносом, по модулю 24 часов).",
     H + 'struct T{int h,m,s;}; int main(){ T t; long add; cin>>t.h>>t.m>>t.s>>add; long total=((long)t.h*3600+t.m*60+t.s+add)%86400; cout<<total/3600<<" "<<total%3600/60<<" "<<total%60; }', ["10 30 0 90\n","23 59 50 20\n"]),
], "L2")
