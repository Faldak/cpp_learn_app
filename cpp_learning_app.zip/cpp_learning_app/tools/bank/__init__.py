# -*- coding: utf-8 -*-
"""Aggregates every topic_*.py module's TASKS list into ALL_TASKS."""
from __future__ import annotations
import importlib
import pkgutil

ALL_TASKS = []
_seen_ids = set()

for _m in sorted(pkgutil.iter_modules(__path__)):
    name = _m.name
    if not name.startswith("topic_"):
        continue
    mod = importlib.import_module(f"{__name__}.{name}")
    for t in getattr(mod, "TASKS", []):
        if t["id"] in _seen_ids:
            raise ValueError(f"Duplicate task id: {t['id']} in {name}")
        _seen_ids.add(t["id"])
        ALL_TASKS.append(t)
