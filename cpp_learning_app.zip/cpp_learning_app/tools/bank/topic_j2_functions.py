# -*- coding: utf-8 -*-
"""Тема J (вторая волна) — Функции."""
from ._helper import seq

H = "#include <iostream>\n#include <string>\nusing namespace std;\n"

TASKS = seq("j2", [
    (5, "Функция: простое число", "Напиши функцию isPrime(n). Считай число и выведи \"да\", если оно простое, иначе \"нет\".",
     H + 'bool isPrime(int n){ if(n<2)return false; for(int i=2;(long)i*i<=n;i++)if(n%i==0)return false; return true; } int main(){ int n; cin>>n; cout<<(isPrime(n)?"да":"нет"); }', ["7\n","9\n","2\n"]),
    (5, "Функция: количество простых", "Используя функцию проверки простоты, выведи количество простых чисел от 1 до n.",
     H + 'bool pr(int n){ if(n<2)return false; for(int i=2;(long)i*i<=n;i++)if(n%i==0)return false; return true; } int main(){ int n; cin>>n; int c=0; for(int i=1;i<=n;i++)if(pr(i))c++; cout<<c; }', ["10\n","2\n"]),
    (4, "Функция: степень", "Напиши функцию power(base, exp) для неотрицательного exp. Считай base и exp, выведи результат.",
     H + 'long power(long b,int e){ long r=1; for(int i=0;i<e;i++)r*=b; return r; } int main(){ long b; int e; cin>>b>>e; cout<<power(b,e); }', ["2 10\n","5 0\n"]),
    (4, "Функция: сумма цифр", "Напиши функцию sumDigits(n). Считай число и выведи сумму его цифр.",
     H + 'int sumDigits(int n){ if(n<0)n=-n; int s=0; while(n>0){s+=n%10;n/=10;} return s; } int main(){ int n; cin>>n; cout<<sumDigits(n); }', ["1234\n","-56\n"]),
    (5, "Рекурсия: факториал", "Напиши рекурсивную функцию factorial(n). Считай n (0..20) и выведи n!.",
     H + 'long long f(int n){ return n<=1?1:n*f(n-1); } int main(){ int n; cin>>n; cout<<f(n); }', ["5\n","0\n"]),
    (5, "Рекурсия: Фибоначчи", "Напиши рекурсивную функцию fib(n). Считай n (1..30) и выведи n-е число Фибоначчи (1 1 2 3 5 ...).",
     H + 'long fib(int n){ return n<=2?1:fib(n-1)+fib(n-2); } int main(){ int n; cin>>n; cout<<fib(n); }', ["7\n","1\n"]),
    (4, "Функция: максимум из трёх", "Напиши функцию max3(a,b,c). Считай три числа и выведи наибольшее.",
     H + 'int max3(int a,int b,int c){ int m=a; if(b>m)m=b; if(c>m)m=c; return m; } int main(){ int a,b,c; cin>>a>>b>>c; cout<<max3(a,b,c); }', ["3 9 5\n","7 7 7\n"]),
    (5, "Функция: НОД", "Напиши функцию gcd(a,b) (алгоритм Евклида). Считай два числа и выведи их НОД.",
     H + 'int gcd(int a,int b){ while(b){int t=a%b;a=b;b=t;} return a; } int main(){ int a,b; cin>>a>>b; cout<<gcd(a,b); }', ["12 18\n","7 1\n"]),
    (5, "Функция: перевернуть число", "Напиши функцию reverseNum(n). Считай натуральное число и выведи его с перевёрнутыми цифрами.",
     H + 'long rev(long n){ long r=0; while(n>0){r=r*10+n%10;n/=10;} return r; } int main(){ long n; cin>>n; cout<<rev(n); }', ["1230\n","7\n"]),
    (5, "Функция: палиндром-число", "Напиши функцию, проверяющую, является ли число палиндромом. Выведи \"да\" или \"нет\".",
     H + 'long rev(long n){ long r=0; while(n>0){r=r*10+n%10;n/=10;} return r; } int main(){ long n; cin>>n; cout<<(rev(n)==n?"да":"нет"); }', ["121\n","123\n"]),
    (4, "Функция: количество цифр", "Напиши функцию countDigits(n). Считай натуральное число и выведи количество его цифр.",
     H + 'int cd(long n){ if(n==0)return 1; int c=0; while(n>0){c++;n/=10;} return c; } int main(){ long n; cin>>n; cout<<cd(n); }', ["12345\n","0\n"]),
    (5, "Функция: сумма диапазона", "Напиши функцию sumRange(a,b), возвращающую сумму целых от a до b. Считай a и b, выведи результат.",
     H + 'long sumRange(long a,long b){ long s=0; for(long i=a;i<=b;i++)s+=i; return s; } int main(){ long a,b; cin>>a>>b; cout<<sumRange(a,b); }', ["1 5\n","-3 3\n"]),
], "J2")
