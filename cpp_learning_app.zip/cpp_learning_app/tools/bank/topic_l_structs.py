# -*- coding: utf-8 -*-
"""Тема L — Структуры (struct)."""
from ._helper import seq

H = "#include <iostream>\n#include <string>\n#include <cmath>\n#include <vector>\nusing namespace std;\n"

TASKS = seq("l", [
    (4, "Точка: расстояние от начала", "Опиши структуру точки с полями x и y. Считай координаты и выведи расстояние от начала координат.",
     H + 'struct P{double x,y;};\nint main(){ P p; cin>>p.x>>p.y; cout<<sqrt(p.x*p.x+p.y*p.y); }', ["3 4\n","0 0\n"]),
    (4, "Прямоугольник: площадь", "Опиши структуру прямоугольника с полями ширина и высота. Считай их и выведи площадь.",
     H + 'struct R{int w,h;};\nint main(){ R r; cin>>r.w>>r.h; cout<<r.w*r.h; }', ["4 6\n","5 5\n"]),
    (4, "Время в секунды", "Опиши структуру времени (часы, минуты, секунды). Считай их и выведи общее число секунд.",
     H + 'struct T{int h,m,s;};\nint main(){ T t; cin>>t.h>>t.m>>t.s; cout<<t.h*3600+t.m*60+t.s; }', ["1 1 1\n","0 2 30\n"]),
    (5, "Точка: середина отрезка", "Опиши структуру точки. Считай две точки и выведи координаты середины отрезка через пробел.",
     H + 'struct P{double x,y;};\nint main(){ P a,b; cin>>a.x>>a.y>>b.x>>b.y; cout<<(a.x+b.x)/2<<" "<<(a.y+b.y)/2; }', ["0 0 4 6\n","1 1 3 3\n"]),
    (5, "Сравнить прямоугольники", 'Опиши структуру прямоугольника. Считай два и выведи "первый", "второй" или "равны" по площади.',
     H + 'struct R{int w,h; int area()const{return w*h;}};\nint main(){ R a,b; cin>>a.w>>a.h>>b.w>>b.h; int x=a.area(),y=b.area(); cout<<(x>y?"первый":(x<y?"второй":"равны")); }', ["4 6 5 5\n","2 2 1 4\n"]),
    (5, "Студент с лучшей оценкой", "Опиши структуру студента (имя, оценка). Считай n студентов и выведи имя студента с наибольшей оценкой.",
     H + 'struct S{string name; int g;};\nint main(){ int n; cin>>n; S best; best.g=-1; for(int i=0;i<n;i++){S s; cin>>s.name>>s.g; if(s.g>best.g)best=s;} cout<<best.name; }', ["3\nAnna 5\nBob 4\nCat 5\n"]),
    (5, "Сумма двух векторов", "Опиши структуру 2D-вектора (x, y). Считай два вектора и выведи их сумму через пробел.",
     H + 'struct V{int x,y;};\nint main(){ V a,b; cin>>a.x>>a.y>>b.x>>b.y; cout<<a.x+b.x<<" "<<a.y+b.y; }', ["1 2 3 4\n","5 5 5 5\n"]),
    (5, "Дробь: сократить", "Опиши структуру дроби (числитель, знаменатель). Считай дробь, сократи её и выведи как 'числитель/знаменатель'.",
     H + 'struct F{int n,d;};\nint g(int a,int b){return b?g(b,a%b):a;}\nint main(){ F f; cin>>f.n>>f.d; int x=g(f.n,f.d); cout<<f.n/x<<"/"<<f.d/x; }', ["4 8\n","3 9\n"]),
    (5, "Окружность: площадь", "Опиши структуру окружности (радиус). Считай радиус и выведи площадь (pi=3.14159).",
     H + 'struct C{double r;};\nint main(){ C c; cin>>c.r; cout<<3.14159*c.r*c.r; }', ["2\n","5\n"]),
    (6, "Средняя оценка студентов", "Опиши структуру студента (имя, оценка). Считай n студентов и выведи среднюю оценку (вещественную).",
     H + 'struct S{string n; int g;};\nint main(){ int n; cin>>n; double s=0; for(int i=0;i<n;i++){S st; cin>>st.n>>st.g; s+=st.g;} cout<<s/n; }', ["4\nA 5\nB 4\nC 3\nD 4\n"]),
    (5, "Сложить два времени", "Опиши структуру времени (минуты, секунды). Считай два момента, сложи и выведи как 'минуты секунды' с переносом секунд.",
     H + 'struct T{int m,s;};\nint main(){ T a,b; cin>>a.m>>a.s>>b.m>>b.s; int tot=(a.m*60+a.s)+(b.m*60+b.s); cout<<tot/60<<" "<<tot%60; }', ["1 30 2 40\n","0 10 0 20\n"]),
    (6, "Самая дальняя точка", "Опиши структуру точки. Считай n точек и выведи индекс (с нуля) самой удалённой от начала координат.",
     H + 'struct P{double x,y;};\nint main(){ int n; cin>>n; int best=0; double bd=-1; for(int i=0;i<n;i++){P p; cin>>p.x>>p.y; double d=p.x*p.x+p.y*p.y; if(d>bd){bd=d;best=i;}} cout<<best; }', ["3\n1 1\n3 4\n2 2\n"]),
    (5, "Товар: стоимость", "Опиши структуру товара (цена, количество). Считай n товаров и выведи общую стоимость корзины.",
     H + 'struct G{int price,qty;};\nint main(){ int n; cin>>n; long s=0; for(int i=0;i<n;i++){G g; cin>>g.price>>g.qty; s+=(long)g.price*g.qty;} cout<<s; }', ["3\n100 2\n50 3\n10 5\n"]),
    (6, "Сортировка студентов по оценке", "Опиши структуру студента (имя, оценка). Считай n студентов и выведи их имена по убыванию оценки через пробел.",
     H + '#include <algorithm>\nstruct S{string n; int g;};\nint main(){ int n; cin>>n; vector<S> v(n); for(auto&s:v)cin>>s.n>>s.g; stable_sort(v.begin(),v.end(),[](const S&a,const S&b){return a.g>b.g;}); for(auto&s:v)cout<<s.n<<" "; }', ["3\nAnna 4\nBob 5\nCat 3\n"]),
    (5, "Периметр прямоугольника (метод)", "Опиши структуру прямоугольника с методом периметра. Считай стороны и выведи периметр.",
     H + 'struct R{int w,h; int per(){return 2*(w+h);}};\nint main(){ R r; cin>>r.w>>r.h; cout<<r.per(); }', ["3 4\n","5 5\n"]),
    (6, "Книга и её возраст", "Опиши структуру книги (название, год издания). Считай текущий год и n книг, выведи название самой старой книги.",
     H + 'struct B{string t; int y;};\nint main(){ int cur,n; cin>>cur>>n; B old; old.y=99999; for(int i=0;i<n;i++){B b; cin>>b.t>>b.y; if(b.y<old.y)old=b;} cout<<old.t; }', ["2026\n3\nC 2010\nB 1999\nA 2020\n"]),
], "L")
