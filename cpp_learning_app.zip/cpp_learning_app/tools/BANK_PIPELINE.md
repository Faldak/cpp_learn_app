# Task-bank pipeline (how to add more verified tasks)

The course now has 600+ tasks. Most live in a **task bank** that is validated and
compiled before shipping. Never hand-edit `content/*.json` — it is generated.

## Flow
1. **Author** tasks in `tools/bank/topic_*.py` using `seq(prefix, items, topic)`.
   Each item: `(level, title, prompt, solution[, stdins[, hints]])`.
   - `level` is an int 1..7: 1 новичок, 2 очень лёгкие, 3 лёгкие, 4 средние,
     5 продвинутые, 6 сложные, 7 junior.
   - `topic` is a letter tag (A..P, plus "2" variants like "A2"); the base letter
     decides which course block the practice lessons land in (see TOPIC_META in
     gen_curriculum.py).
   - ids auto-number `prefix_1, prefix_2, ...`. `tools/bank/__init__.py` aggregates
     all modules into `ALL_TASKS` and errors on duplicate ids.
2. **Validate**: `python3 tools/validate_bank.py` (~5 min full).
   - Stage 1 (parallel): compiles, runs every stdin (no crash/timeout), checks
     determinism (runs twice), checks level 1..7, and a complexity floor (rejects
     trivial tasks labelled level >=5).
   - Stage 2: dedup by code-skeleton normalization + prompt word shingles.
3. **Generate lessons**: `python3 tools/gen_curriculum.py` — runs the validator,
   keeps only accepted tasks, groups by topic, orders by difficulty, splits into
   ~12-task practice lessons each with a short generated theory intro, and writes
   `tools/curriculum_bank.py` (imported by curriculum.py → ALL_LESSONS).
4. **Build + verify everything**: `python3 tools/build_content.py` — recompiles
   every reference solution and derives expected stdout. FAILS LOUDLY if any task
   doesn't compile/run, so broken tasks never ship.
5. **Test**: `python3 -m pytest tests/test_backend.py -q` (slow ~5 min: it compiles
   all reference solutions too). UI tests need `flet` installed.

## Gotchas
- **Cyrillic is multibyte UTF-8**: byte-level char ops (reverse, indexing, .front()/
  .back(), .size()-as-char-count, doubling chars) BREAK on Cyrillic. Use Latin/ASCII
  inputs for all char-level string tasks. Whole-word / word-count tasks may keep Cyrillic.
- Pure formula / straight-line tasks (no control flow) max out at level 4 — the
  complexity floor rejects them at level >=5.
- Dedup keeps string-literal content in the skeleton, so tasks that differ only by
  printed text are NOT flagged as duplicates.
- `%` in prompts: write a single `%` (no Python string formatting is applied).
- Env resets sometimes wipe `~/.local`; reinstall:
  `python3.12 -m pip install --user "flet>=0.85,<0.86" platformdirs keyring requests pytest`.

---

## Theory deepening pipeline (added 2026-06-20)

Goal: every lesson's theory must explain EVERYTHING its tasks require, deeply,
beginner-friendly ("мы пишем X, чтобы получить Y"), with a 🧠 memory hook.

Files:
- `tools/theory_content.py` — authored deep theory, ONE entry per concept
  (`CONCEPTS` dict, 42 concepts incl. specials `_smart_pointers`, `_sfml`).
  UI renders theory text as PLAIN text (no markdown) — do NOT use `**bold**`;
  backticks are a literal code convention only.
- `tools/extract_concepts.py` — deterministically scans each task's
  reference_solution+prompt → which C++ concepts each lesson actually uses.
  This IS "Check 1" ground truth. Output: `tools/_concepts.json`.
- `tools/build_theory.py` — assembles lesson theory: a concept gets the DEEP
  treatment in the FIRST lesson (course order) that uses it, a short RECAP in
  later lessons. Writes back `content/lessons/*.json`.
- `tools/verify_theory.py` — the 2-stage check Bruh asked for:
  C1 every concept used by a lesson's tasks is explained; C2 quality (🧠 hook +
  why-framing present, theory not trivially short, no verbatim task solution
  leaked). Exit 0 only if ALL lessons pass.

ORDER OF OPERATIONS (important):
  build_content.py reads theory from gen_curriculum (SHALLOW). So theory
  deepening MUST run LAST:
      python3 tools/build_content.py        # regenerates lessons (shallow theory)
      python3 tools/extract_concepts.py --json tools/_concepts.json
      python3 tools/build_theory.py         # overwrites with DEEP theory
      python3 tools/verify_theory.py        # must print ✅
  If you re-run build_content.py later, re-run build_theory.py + verify after it,
  or the deep theory gets wiped.

To add a new concept: add an entry to CONCEPTS (title/deep/recap/takeaway/mistake,
with a 🧠 hook and a "чтобы" framing word), a detector regex in extract_concepts
PATTERNS, and its slot in build_theory.ORDER. Then rerun build_theory+verify.
