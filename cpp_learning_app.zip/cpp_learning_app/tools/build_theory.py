# -*- coding: utf-8 -*-
"""
build_theory.py
===============
Rebuild each lesson's theory so that EVERYTHING its tasks require is explained,
deeply and for a beginner, with "why we write X to get Y" framing and memory
hooks. Uses the concept inventory from extract_concepts.py and the authored
theory in theory_content.py.

Rule: a concept gets the FULL ("deep") treatment in the first lesson (by course
order) that uses it; later lessons get a short recap so nothing is ever assumed.

Run: python3 tools/extract_concepts.py --json tools/_concepts.json
     python3 tools/build_theory.py
"""
from __future__ import annotations
import json, os, re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LESSONS = os.path.join(ROOT, "content/lessons")
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from theory_content import CONCEPTS, T  # noqa

# Pedagogical order: foundations first, advanced last.
ORDER = [
    "variables", "arithmetic", "output_basic", "multiple_output",
    "multi_line_output", "double_type", "modulo", "type_cast", "bool_type",
    "char_type", "const", "cin_input", "getline", "string_type",
    "string_methods", "if_else", "else_branch", "ternary", "switch",
    "for_loop", "while_loop", "do_while", "range_for", "auto", "array_c",
    "vector", "sort", "algorithm", "math_func", "minmax_func", "setprecision",
    "function_def", "recursion", "reference_param", "pointer",
    "_smart_pointers", "struct", "class", "map", "set", "pair", "_sfml",
]

# Concepts that detectors can't see — attach manually to their home lesson.
SPECIAL = {
    "block4_lesson2": ["_smart_pointers"],
    "block6_lesson1": ["_sfml"],
}

# Topic hook lines (psychological "why care"); keyed by practice letter / lesson.
TOPIC_HOOK = {
    "a": "Вывод — это голос программы: всё, что видит человек, программа сначала «сказала» через cout.",
    "b": "Переменные — это память программы. Без них она бы всё забывала сразу же, как золотая рыбка.",
    "c": "Ввод превращает программу из «говорящей» в «слушающую»: теперь она реагирует на тебя.",
    "d": "Условия дают программе характер: она перестаёт идти по одной колее и начинает выбирать.",
    "e": "Циклы — суперсила программиста: один раз написал — компьютер повторит хоть миллион раз.",
    "f": "Математика в C++ — это калькулятор на стероидах. Главное — знать его хитрости с делением.",
    "g": "Строки — это работа с текстом: имена, слова, шифры. Тут программа становится «грамотной».",
    "h": "Массивы и vector — это полки для множества значений под одним именем.",
    "i": "Матрицы — это таблицы (строки и столбцы): шахматная доска, экран, поле игры.",
    "j": "Функции — твои собственные команды. Научишь компьютер один раз — пользуешься всегда.",
    "k": "Указатели и ссылки — это работа с самой памятью. Звучит страшно, на деле — адреса и оригиналы.",
    "l": "Структуры склеивают связанные данные в одну карточку — порядок вместо хаоса переменных.",
    "m": "ООП — это мышление «объектами»: данные и их умения живут вместе, как в реальном мире.",
    "n": "STL — это чемодан готовых инструментов. Профи не пишут с нуля то, что уже придумано.",
    "o": "Структуры данных — это разные «контейнеры»: у каждого свой талант хранить и искать.",
    "p": "Мини-проекты — собираем всё изученное вместе. Здесь знания превращаются в настоящие программы.",
}
CURATED_HOOK = {
    "block1_lesson1": TOPIC_HOOK["a"],
    "block1_lesson2": TOPIC_HOOK["b"],
    "block1_lesson3": TOPIC_HOOK["f"],
    "block2_lesson1": TOPIC_HOOK["d"],
    "block2_lesson2": TOPIC_HOOK["e"],
    "block2_lesson3": "Строки и массивы — два способа хранить «много всего»: текст и список значений.",
    "block3_lesson1": TOPIC_HOOK["j"],
    "block3_lesson2": "Ссылки и рекурсия — два мощных приёма: работать с оригиналом и решать задачу через саму себя.",
    "block4_lesson1": TOPIC_HOOK["k"],
    "block4_lesson2": "Динамическая память — когда данные рождаются во время работы программы. Умные указатели убирают за нами сами.",
    "block5_lesson1": TOPIC_HOOK["m"],
    "block5_lesson2": "Наследование — когда один класс получает умения другого «по наследству», как сын черты отца.",
    "block6_lesson1": "Графика SFML — пора рисовать! Программа выходит из чёрного окна в мир фигур и цвета.",
    "block7_lesson1": "vector — самый частый контейнер C++: список, который сам растёт.",
    "block7_lesson2": "map — словарь программиста: по ключу мгновенно находишь значение.",
    "block8_lesson1": TOPIC_HOOK["p"],
}


def topic_key(lid: str) -> str:
    m = re.search(r"_practice_([a-p])_", lid)
    return m.group(1) if m else ""


def course_order_key(lesson: dict):
    bn = int(re.sub(r"\D", "", lesson["block_id"]) or 0)
    return (bn, lesson.get("order_in_block", 0))


def main():
    concepts = json.load(open(os.path.join(ROOT, "tools/_concepts.json"),
                               encoding="utf-8"))["lesson_concepts"]
    lessons = {}
    for fn in os.listdir(LESSONS):
        if fn.endswith(".json"):
            lessons[fn[:-5]] = json.load(open(os.path.join(LESSONS, fn), encoding="utf-8"))

    ordered = sorted(lessons.values(), key=course_order_key)

    # required concepts per lesson (detected + special), ordered
    req = {}
    for les in ordered:
        lid = les["lesson_id"]
        s = set(concepts.get(lid, [])) | set(SPECIAL.get(lid, []))
        s = {c for c in s if c in CONCEPTS}
        req[lid] = [c for c in ORDER if c in s]

    # first lesson (by order) that introduces each concept -> "deep" there
    first_intro = {}
    for les in ordered:
        lid = les["lesson_id"]
        for c in req[lid]:
            first_intro.setdefault(c, lid)

    for les in ordered:
        lid = les["lesson_id"]
        new = [c for c in req[lid] if first_intro[c] == lid]
        review = [c for c in req[lid] if first_intro[c] != lid]

        # --- intro hook ---
        hook = CURATED_HOOK.get(lid) or TOPIC_HOOK.get(topic_key(lid)) or \
            "Закрепляем тему на задачах."
        if new:
            names = ", ".join(CONCEPTS[c]["title"].split(":")[0].split("(")[0].strip().lower()
                              for c in new)
            intro = hook + f" Новое в этом уроке: {names}."
        else:
            intro = hook + " Все нужные приёмы уже знакомы — здесь мы их закрепляем на практике; " \
                           "если что-то забыл, краткие напоминания ниже."
        blocks = [T(intro)]

        # --- deep for new, recap for review ---
        for c in new:
            blocks.append(T("▸ " + CONCEPTS[c]["title"]))
            blocks.extend(CONCEPTS[c]["deep"])
        for c in review:
            blocks.append(T(CONCEPTS[c]["recap"]))

        # --- takeaways & mistakes ---
        tk = [CONCEPTS[c]["takeaway"] for c in new]
        if len(tk) < 3:
            # pad from the most advanced review concepts in THIS lesson first
            tk += [CONCEPTS[c]["takeaway"] for c in reversed(review)][: 3 - len(tk)]
        mis = [CONCEPTS[c]["mistake"] for c in new] or \
            [CONCEPTS[c]["mistake"] for c in req[lid][:3]]

        les["theory_blocks"] = blocks
        les["key_takeaways"] = tk[:7]
        les["common_mistakes"] = mis[:5]
        les["estimated_minutes"] = max(les.get("estimated_minutes", 12), 10 + 3 * len(new))

        json.dump(les, open(os.path.join(LESSONS, lid + ".json"), "w", encoding="utf-8"),
                  ensure_ascii=False, indent=2)

    print(f"Rebuilt theory for {len(ordered)} lessons.")
    # quick stats
    deep_counts = [sum(1 for c in req[l['lesson_id']] if first_intro[c] == l['lesson_id'])
                   for l in ordered]
    print("lessons with >=1 new concept:", sum(1 for x in deep_counts if x))
    print("total concept introductions:", sum(deep_counts))


if __name__ == "__main__":
    main()
