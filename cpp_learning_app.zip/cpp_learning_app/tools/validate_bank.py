# -*- coding: utf-8 -*-
"""
tools/validate_bank.py
======================
Two-stage validation for the task bank (tools/bank/*).

Stage 1 (per task, "сложность + тип"):
  - reference solution compiles with the real compiler;
  - runs on EVERY stdin without crash/timeout and DETERMINISTICALLY
    (run twice, outputs must match — no rand/time leakage);
  - level is in 1..7 and the solution's構造 is consistent with the level
    (graduated complexity heuristics: harder levels must actually use
    more advanced constructs, not a trivial one-liner).

Stage 2 (cross-task, "схожесть"):
  - normalize each solution into a structural skeleton (strip comments,
    string/char literals, numbers, rename identifiers, collapse space) and
    the prompt into a word bag; any task too similar to an EARLIER accepted
    task (skeleton Jaccard >= SKELETON_DUP or both skeleton & prompt high)
    is rejected as a duplicate.

A task is ACCEPTED only if it passes BOTH stages.

Usage:
  python3.12 tools/validate_bank.py            # validate, print report
  (imported)  validate(tasks) -> (accepted, rejected)
"""
from __future__ import annotations

import re
import sys
import concurrent.futures as cf
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tools"))

import compiler_service as cs  # noqa: E402

SKELETON_DUP = 0.86          # skeleton Jaccard above this => duplicate
SKELETON_SOFT = 0.72         # if skeleton >= SOFT and prompt >= PROMPT_SOFT => dup
PROMPT_SOFT = 0.78

LEVEL_NAMES = {
    1: "новичок", 2: "очень лёгкие", 3: "лёгкие", 4: "средние",
    5: "продвинутые", 6: "сложные", 7: "junior",
}

# Constructs that indicate complexity, keyed to the MINIMUM level at which a
# task is allowed to be "only this simple". Used as a soft floor so that, e.g.,
# a level-5 task isn't just a single cout.
_ADV_TOKENS = [
    "class ", "struct ", "template", "virtual", "operator", "->", "new ",
    "delete ", "std::vector", "std::map", "std::set", "std::sort",
    "std::unordered", "std::shared_ptr", "std::unique_ptr", "[](", "auto ",
    "recursion", "while", "for", "if", "switch", "<<", ">>",
]


# ---------------------------------------------------------------------------
# normalization helpers
# ---------------------------------------------------------------------------
_STR_RE = re.compile(r'"(?:\\.|[^"\\])*"')
_CHR_RE = re.compile(r"'(?:\\.|[^'\\])*'")
_CMT_RE = re.compile(r"//.*?$|/\*.*?\*/", re.S | re.M)
_NUM_RE = re.compile(r"\b\d+(?:\.\d+)?\b")
_WORD_RE = re.compile(r"[A-Za-z_]\w*")

_KEYWORDS = {
    "include", "int", "main", "return", "for", "while", "do", "if", "else",
    "switch", "case", "break", "continue", "void", "double", "float", "char",
    "bool", "true", "false", "const", "struct", "class", "public", "private",
    "protected", "virtual", "new", "delete", "this", "using", "namespace",
    "std", "cout", "cin", "endl", "string", "vector", "map", "set", "pair",
    "auto", "template", "typename", "sizeof", "static", "long", "short",
    "unsigned", "signed", "size_t", "nullptr", "operator", "friend", "enum",
    "try", "catch", "throw", "push_back", "begin", "end", "sort", "make_pair",
    "first", "second", "find", "insert", "erase", "at", "size", "length",
}


def _norm_str(m):
    # keep literal CONTENT (lowercased, spaces collapsed) so two print tasks
    # with different text are NOT treated as identical structure.
    return '"' + re.sub(r"\s+", " ", m.group(0).lower()) + '"'


def skeleton(src: str) -> str:
    """Structural skeleton: drop comments and numbers; keep normalized string/
    char literals (so different outputs differ); map non-keyword identifiers to
    a placeholder; collapse whitespace."""
    s = _CMT_RE.sub(" ", src)
    s = _STR_RE.sub(_norm_str, s)
    s = _CHR_RE.sub(lambda m: m.group(0).lower(), s)
    s = _NUM_RE.sub("N", s)

    def repl(m):
        w = m.group(0)
        return w if w in _KEYWORDS else "v"
    s = _WORD_RE.sub(repl, s)
    s = re.sub(r"\s+", " ", s)
    return s.strip()


def _shingles(text: str, k: int = 4) -> set:
    toks = text.split()
    if len(toks) < k:
        return {" ".join(toks)} if toks else set()
    return {" ".join(toks[i:i + k]) for i in range(len(toks) - k + 1)}


def _word_bag(text: str) -> set:
    return set(w.lower() for w in re.findall(r"\w+", text) if len(w) > 2)


def _jaccard(a: set, b: set) -> float:
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


# ---------------------------------------------------------------------------
# Stage 1
# ---------------------------------------------------------------------------
def _stage1_one(task: dict) -> dict:
    """Return {'ok':bool,'reason':str,'test_cases':[...]} for one task."""
    tid = task["id"]
    level = task.get("level", 1)
    if level not in LEVEL_NAMES:
        return {"ok": False, "reason": f"bad level {level}"}

    sol = task["solution"]
    compiled = cs.compile_source(sol, use_sanitizer=False)
    if not compiled.ok:
        return {"ok": False, "reason": "compile_error",
                "detail": compiled.compiler_stderr[:400]}

    test_cases = []
    for stdin in task.get("stdins", [""]):
        r1 = cs.run_executable(compiled.executable_path, stdin=stdin)
        if not r1.ran or r1.timed_out or r1.crashed:
            return {"ok": False,
                    "reason": f"runtime(stdin={stdin!r},timeout={r1.timed_out},crash={r1.crashed})"}
        r2 = cs.run_executable(compiled.executable_path, stdin=stdin)
        if r1.stdout != r2.stdout:
            return {"ok": False, "reason": "non_deterministic"}
        expected = "\n".join(line.rstrip() for line in r1.stdout.splitlines()).rstrip("\n")
        test_cases.append({"stdin": stdin, "expected_stdout": expected})

    # graduated-complexity floor: catch only GROSS level mismatches (e.g. a
    # level-5+ task that is a pure straight-line print). Precise leveling is
    # curated by the author; this only rejects egregiously-trivial high levels.
    body = sol
    has_logic = any(tok in body for tok in ("for", "while", "if", "switch", "?"))
    has_struct = any(tok in body for tok in ("class ", "struct ", "template", "operator", "virtual"))
    has_stl = any(tok in body for tok in ("vector", "map", "set", "sort",
                                          "unordered", "[](", "accumulate",
                                          "shared_ptr", "unique_ptr", "stack",
                                          "queue", "pair"))
    has_math = any(tok in body for tok in ("sqrt", "pow", "llround", "abs",
                                           "fabs", "ceil", "floor"))
    if level >= 5 and not (has_logic or has_struct or has_stl or has_math):
        return {"ok": False, "reason": f"too_trivial_for_level_{level}"}

    return {"ok": True, "reason": "ok", "test_cases": test_cases}


# ---------------------------------------------------------------------------
# public API
# ---------------------------------------------------------------------------
def validate(tasks: list[dict], workers: int = 8, verbose: bool = True):
    """Run both stages. Returns (accepted, rejected).
    Accepted tasks get an added 'test_cases' key."""
    # ---- Stage 1 (parallel compile/run) ----
    results: dict[str, dict] = {}
    with cf.ThreadPoolExecutor(max_workers=workers) as ex:
        fut = {ex.submit(_stage1_one, t): t for t in tasks}
        for f in cf.as_completed(fut):
            t = fut[f]
            try:
                results[t["id"]] = f.result()
            except Exception as e:  # pragma: no cover
                results[t["id"]] = {"ok": False, "reason": f"exception:{e}"}

    accepted: list[dict] = []
    rejected: list[dict] = []

    seen_skel: list[set] = []
    seen_prompt: list[set] = []

    # keep authored order for deterministic dedup (first wins)
    for t in tasks:
        r = results[t["id"]]
        if not r["ok"]:
            rejected.append({**t, "_reject": f"stage1:{r['reason']}",
                             "_detail": r.get("detail", "")})
            continue
        # ---- Stage 2: similarity ----
        sk = _shingles(skeleton(t["solution"]))
        pb = _word_bag(t.get("prompt", ""))
        dup = False
        for i, sks in enumerate(seen_skel):
            sj = _jaccard(sk, sks)
            pj = _jaccard(pb, seen_prompt[i])
            # "Явная схожесть": near-identical structure AND overlapping intent,
            # OR strongly overlapping structure AND prompt. Requiring prompt
            # overlap avoids nuking many distinct beginner print-tasks that
            # happen to share the trivial `cout << "..."` skeleton.
            if sj >= SKELETON_DUP and pj >= 0.50:
                dup = True
                break
            if sj >= SKELETON_SOFT and pj >= PROMPT_SOFT:
                dup = True
                break
        if dup:
            rejected.append({**t, "_reject": "stage2:duplicate"})
            continue
        seen_skel.append(sk)
        seen_prompt.append(pb)
        accepted.append({**t, "test_cases": r["test_cases"]})

    if verbose:
        n1 = sum(1 for x in rejected if x["_reject"].startswith("stage1"))
        n2 = sum(1 for x in rejected if x["_reject"].startswith("stage2"))
        print(f"[validate] total={len(tasks)} accepted={len(accepted)} "
              f"rejected_stage1={n1} rejected_stage2={n2}")
        for x in rejected[:25]:
            d = (" :: " + x.get("_detail", "")) if x.get("_detail") else ""
            print(f"  REJECT {x['id']} [{x['_reject']}]{d[:160]}")
    return accepted, rejected


if __name__ == "__main__":
    from bank import ALL_TASKS  # noqa
    acc, rej = validate(ALL_TASKS)
    by_level = {}
    for t in acc:
        by_level[t["level"]] = by_level.get(t["level"], 0) + 1
    print("[by level]", {LEVEL_NAMES[k]: by_level.get(k, 0) for k in sorted(LEVEL_NAMES)})
    print(f"[total accepted] {len(acc)}")
