# -*- coding: utf-8 -*-
"""
tools/gen_curriculum.py
=======================
Turns the VALIDATED task bank (tools/bank/*) into practice lessons and writes
them to tools/curriculum_bank.py as a static `PRACTICE_LESSONS` list, which
curriculum.py appends to ALL_LESSONS.

Pipeline:
  python3 tools/gen_curriculum.py     # validates bank, emits curriculum_bank.py
  python3 tools/build_content.py      # compiles+verifies EVERYTHING, emits JSON

Only tasks that pass the 2-stage validator (compile/determinism/level + dedup)
are included. Tasks are grouped by topic, ordered by difficulty (1..7), and
split into bite-size practice lessons, each with a short generated theory intro
so the number of theory lessons scales with the number of topics.
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tools"))

# topic letter -> (block_id, human title, theory paragraphs, takeaways, mistakes)
TOPIC_META = {
    "A": ("block1", "Вывод на экран",
          ["Вывод — это то, что программа показывает пользователю. В C++ за это отвечает `cout` из библиотеки <iostream>.",
           "Текст пишут в кавычках, числа — без. Спецсимволы: `\\n` — перевод строки, `\\t` — табуляция."],
          ["`cout << ...;` выводит данные на экран.", "`\\n` переносит вывод на новую строку.",
           "Несколько `<<` можно соединять в цепочку."],
          ["Забыть кавычки вокруг текста.", "Перепутать `\\n` и обычную букву n."]),
    "B": ("block1", "Переменные и арифметика",
          ["Переменная — это именованная ячейка памяти. Для целых чисел используют `int` и `long`, для дробных — `double`.",
           "Арифметика: `+ - * /` и остаток `%`. У целых деление отбрасывает дробную часть."],
          ["`int`/`long` — целые, `double` — дробные числа.", "`%` даёт остаток от деления.",
           "Целочисленное деление отбрасывает дробь."],
          ["Делить целые и ждать дробный результат.", "Переполнение `int` на больших числах — берите `long`."]),
    "C": ("block1", "Ввод данных",
          ["Ввод читают через `cin >> x;`. Можно читать несколько значений подряд: `cin >> a >> b;`.",
           "Строку целиком (с пробелами) читают через `getline(cin, s)`."],
          ["`cin >> x;` читает значение в переменную.", "`getline` читает строку целиком.",
           "Порядок чтения должен совпадать с порядком ввода."],
          ["Смешивать `cin >>` и `getline` без учёта остатка строки.", "Читать в переменную не того типа."]),
    "D": ("block2", "Условия",
          ["Условный оператор `if/else` выбирает, какой код выполнить, в зависимости от проверки.",
           "Сравнения: `== != < > <= >=`. Логика: `&&` (и), `||` (или), `!` (не). Тернарный `?:` — короткая форма."],
          ["`if (условие) { ... } else { ... }`.", "Сравнение на равенство — это `==`, а не `=`.",
           "`&&`, `||`, `!` комбинируют условия."],
          ["Использовать `=` вместо `==` в условии.", "Забыть охватить все случаи в цепочке if/else."]),
    "E": ("block2", "Циклы",
          ["Циклы повторяют код. `for` удобен, когда число повторений известно, `while` — пока выполняется условие.",
           "Типичные приёмы: накопление суммы, перебор цифр числа (`% 10`, `/ 10`), счётчики."],
          ["`for (int i=0;i<n;i++)` — цикл со счётчиком.", "`while (условие)` повторяет, пока условие истинно.",
           "`% 10` даёт последнюю цифру, `/ 10` убирает её."],
          ["Бесконечный цикл из-за неизменяемого условия.", "Ошибка на единицу в границах (`<` vs `<=`)."]),
    "F": ("block2", "Математика и числа",
          ["Здесь — делимость, простые числа, делители, НОД, работа с цифрами и формулы.",
           "Полезно: проверка делимости через `%`, перебор делителей до корня, алгоритм Евклида."],
          ["Число делится на k, если `n % k == 0`.", "Делители достаточно искать до корня из n.",
           "НОД считают алгоритмом Евклида."],
          ["Перебирать делители до n, когда хватает корня.", "Забыть про переполнение при произведениях."]),
    "G": ("block2", "Строки",
          ["Строка `string` — это последовательность символов. Длина — `s.size()`, символ по индексу — `s[i]`.",
           "Внимание: один кириллический символ занимает несколько байт, поэтому посимвольные операции делают на латинице."],
          ["`s.size()` — длина строки.", "`s[i]` — символ по индексу (с нуля).",
           "`substr`, `find` помогают работать с подстроками."],
          ["Посимвольно резать кириллицу (она многобайтовая).", "Выход за границы строки по индексу."]),
    "H": ("block2", "Массивы и vector",
          ["`vector<int> a(n)` — динамический массив из n элементов. Доступ — `a[i]`, перебор — циклом или `for (int x : a)`.",
           "Типовые задачи: сумма, поиск максимума/минимума, подсчёт по условию."],
          ["`vector<int> a(n);` создаёт массив из n элементов.", "Индексация с нуля: первый элемент `a[0]`.",
           "`for (int x : a)` перебирает все элементы."],
          ["Обращение к `a[n]` (за границей).", "Забыть инициализировать накопитель суммы нулём."]),
    "I": ("block2", "Матрицы",
          ["Матрица — это `vector<vector<...>>`, таблица из строк и столбцов. Элемент — `m[i][j]`.",
           "Обход — два вложенных цикла. Диагонали: главная `m[i][i]`, побочная `m[i][n-1-i]`."],
          ["`m[i][j]` — элемент в строке i, столбце j.", "Главная диагональ: `m[i][i]`.",
           "Побочная диагональ: `m[i][n-1-i]`."],
          ["Перепутать индексы строки и столбца.", "Считать строки/столбцы, перепутав границы."]),
    "J": ("block3", "Функции",
          ["Функция — это переиспользуемый блок кода со своим именем, параметрами и возвращаемым значением.",
           "Рекурсия — когда функция вызывает саму себя; важно описать базовый случай."],
          ["`тип имя(параметры){ ... return ...; }` — объявление функции.", "Параметры передают данные внутрь.",
           "У рекурсии обязателен базовый случай."],
          ["Забыть `return` в функции, которая должна вернуть значение.", "Рекурсия без условия выхода → бесконечность."]),
    "K": ("block4", "Указатели и ссылки",
          ["Ссылка `int&` — это другое имя для той же переменной. Указатель `int*` хранит адрес, `*p` — значение по адресу.",
           "Через ссылки и указатели функция может изменять переданные ей данные."],
          ["`&x` — адрес переменной, `*p` — значение по указателю.", "Ссылка `int&` — псевдоним переменной.",
           "Передача по ссылке позволяет менять аргумент."],
          ["Разыменовать нулевой/невалидный указатель.", "Передать по значению, ожидая изменения оригинала."]),
    "L": ("block4", "Структуры",
          ["Структура `struct` объединяет несколько полей в один тип. Доступ к полю — через точку: `p.x`.",
           "Структуры удобны для точек, дат, дробей и других составных данных."],
          ["`struct Имя { поля; };` объявляет новый тип.", "Доступ к полю — через точку: `obj.field`.",
           "Структуру можно передавать в функции."],
          ["Забыть точку с запятой после `}` структуры.", "Обращаться к полю до его инициализации."]),
    "M": ("block5", "ООП",
          ["Класс объединяет данные и методы. `public`-методы — интерфейс, `private`-поля скрыты.",
           "Конструктор инициализирует объект, методы описывают его поведение."],
          ["Класс = данные (поля) + поведение (методы).", "Конструктор задаёт начальное состояние.",
           "`private` скрывает поля, `public` открывает интерфейс."],
          ["Доступ к `private`-полям снаружи класса.", "Забыть инициализировать поля в конструкторе."]),
    "N": ("block7", "STL и алгоритмы",
          ["Стандартная библиотека даёт готовые контейнеры (`vector`, `set`, `map`) и алгоритмы (`sort`, `find`, `accumulate`).",
           "Это экономит код: вместо ручных циклов — вызов проверенной функции."],
          ["`sort`, `find`, `accumulate` — готовые алгоритмы.", "`set` хранит уникальные значения, `map` — пары ключ-значение.",
           "Алгоритмы работают с итераторами `begin()/end()`."],
          ["Забыть подключить нужный заголовок (<algorithm>, <map>).", "Использовать невалидный итератор после изменения контейнера."]),
    "O": ("block7", "Структуры данных",
          ["Стек (`stack`) — последним вошёл, первым вышел. Очередь (`queue`) — первым вошёл, первым вышел.",
           "Множества и словари помогают быстро проверять наличие и считать частоты."],
          ["Стек: `push/top/pop` (LIFO).", "Очередь: `push/front/pop` (FIFO).",
           "`set`/`map` дают быстрый поиск и подсчёт."],
          ["Вызвать `top()/front()` у пустого контейнера.", "Перепутать порядок LIFO и FIFO."]),
    "P": ("block8", "Мини-проекты",
          ["Здесь — небольшие законченные программы, собирающие вместе ввод, логику, циклы и вывод.",
           "Главное — разбить задачу на шаги и проверить каждый на примере."],
          ["Сложная задача = последовательность простых шагов.", "Проверяйте программу на нескольких примерах.",
           "Читаемый код легче отлаживать."],
          ["Браться за весь проект сразу, без разбиения.", "Не проверять граничные случаи ввода."]),
}

TASKS_PER_LESSON = 12


def base_letter(topic: str) -> str:
    return topic[0].upper()


def build_practice_lessons():
    from validate_bank import validate, LEVEL_NAMES  # noqa
    from bank import ALL_TASKS  # noqa

    accepted, _rej = validate(ALL_TASKS)
    # group by base topic letter
    by_topic: dict[str, list] = {}
    for t in accepted:
        by_topic.setdefault(base_letter(t["topic"]), []).append(t)

    lessons = []
    # keep blocks in canonical order
    order_counter: dict[str, int] = {}
    for letter in sorted(by_topic, key=lambda L: list(TOPIC_META).index(L)):
        block_id, title, theory, takeaways, mistakes = TOPIC_META[letter]
        tasks = sorted(by_topic[letter], key=lambda t: (t["level"], t["id"]))
        # split into bite-size lessons
        chunks = [tasks[i:i + TASKS_PER_LESSON] for i in range(0, len(tasks), TASKS_PER_LESSON)]
        for ci, chunk in enumerate(chunks, 1):
            order_counter[block_id] = order_counter.get(block_id, 100) + 1
            part = f" (часть {ci})" if len(chunks) > 1 else ""
            lesson_id = f"{block_id}_practice_{letter.lower()}_{ci}"
            lvl_lo = LEVEL_NAMES[min(t["level"] for t in chunk)]
            lvl_hi = LEVEL_NAMES[max(t["level"] for t in chunk)]
            intro = (f"Практика по теме «{title}». Реши задачи по нарастающей сложности "
                     f"(от уровня «{lvl_lo}» до «{lvl_hi}»). Каждая задача проверяется автоматически "
                     f"по эталонному решению.")
            theory_blocks = [{"type": "text", "content": intro}]
            theory_blocks += [{"type": "text", "content": p} for p in theory]
            ltasks = []
            for t in chunk:
                ltasks.append({
                    "id": t["id"], "title": t["title"], "difficulty": t["level"],
                    "prompt": t["prompt"], "starter": t["starter"], "stdins": t["stdins"],
                    "hints": t["hints"], "solution": t["solution"],
                    "comparison_mode": "trim_trailing_whitespace",
                })
            lessons.append({
                "lesson_id": lesson_id,
                "order_in_block": order_counter[block_id],
                "title": f"{title} — практика{part}",
                "estimated_minutes": 20,
                "theory_blocks": theory_blocks,
                "key_takeaways": takeaways,
                "common_mistakes": mistakes,
                "tasks": ltasks,
            })
    return lessons


def main():
    lessons = build_practice_lessons()
    out = ROOT / "tools" / "curriculum_bank.py"
    header = ("# -*- coding: utf-8 -*-\n"
              "# AUTO-GENERATED by tools/gen_curriculum.py — do not edit by hand.\n"
              "# Regenerate: python3 tools/gen_curriculum.py\n\n")
    out.write_text(header + "PRACTICE_LESSONS = " + repr(lessons) + "\n", encoding="utf-8")
    n_tasks = sum(len(l["tasks"]) for l in lessons)
    print(f"[gen] practice lessons: {len(lessons)}  tasks: {n_tasks}")
    print(f"[gen] wrote {out}")


if __name__ == "__main__":
    main()
