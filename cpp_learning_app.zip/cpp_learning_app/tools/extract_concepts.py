"""
extract_concepts.py
===================
Deterministically scan every task's reference solution + prompt and report
which C++ concepts each LESSON's tasks actually require. This is the ground
truth that the theory of each lesson must cover (Check 1 in the spec).

Run: python3 tools/extract_concepts.py            # prints per-lesson concepts
     python3 tools/extract_concepts.py --json out.json
"""
from __future__ import annotations
import json, glob, re, collections, sys, os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# concept_id -> compiled regex (searched against reference_solution; some also prompt)
PATTERNS = {
    "variables":      r"\b(int|double|float|string|char|bool|long)\s+\w+\s*(=|;|,)",
    "arithmetic":     r"[a-zA-Z0-9_)\]]\s*[+\-*/]\s*[a-zA-Z0-9_(]",
    "output_basic":   r"cout\s*<<",
    "multi_line_output": r"\\n|endl",
    "cin_input":      r"\bcin\s*>>",
    "getline":        r"getline",
    "if_else":        r"\bif\s*\(",
    "else_branch":    r"\belse\b",
    "ternary":        r"[^?]\?[^?]",
    "switch":         r"\bswitch\b",
    "for_loop":       r"\bfor\s*\(",
    "while_loop":     r"\bwhile\s*\(",
    "do_while":       r"\bdo\s*\{",
    "vector":         r"vector\s*<",
    "array_c":        r"\]\s*;|\]\s*=|\]\s*\{",
    "string_type":    r"\bstring\b",
    "string_methods": r"\.(size|length|substr|find|push_back|append|at|front|back|c_str|compare|empty|insert|erase|begin|end)\s*\(",
    "function_def":   None,   # computed
    "recursion":      None,   # computed
    "reference_param": r"&\s*\w+\s*[,)]",
    "pointer":        r"\bnew\b|\bdelete\b|->|\*\s*\w+\s*=",
    "struct":         r"\bstruct\b",
    "class":          r"\bclass\b",
    "map":            r"\bmap\s*<|unordered_map",
    "set":            r"\bset\s*<",
    "pair":           r"\bpair\s*<|make_pair",
    "sort":           r"\bsort\s*\(",
    "algorithm":      r"\b(max_element|min_element|accumulate|reverse|unique|fill|count)\s*\(",
    "math_func":      r"\b(sqrt|pow|abs|fabs|floor|ceil|round)\s*\(",
    "minmax_func":    r"\b(min|max)\s*\(",
    "modulo":         r"%[^d]",
    "bool_type":      r"\bbool\b",
    "char_type":      r"\bchar\b",
    "double_type":    r"\b(double|float)\b",
    "const":          r"\bconst\b",
    "setprecision":   r"setprecision|fixed",
    "type_cast":      r"static_cast|\(int\)|\(double\)",
    "auto":           r"\bauto\b",
    "range_for":      r"for\s*\(\s*(auto|int|char|double|string)[\w:<>& ]*\s+\w+\s*:",
}
COMPILED = {k: re.compile(v) for k, v in PATTERNS.items() if v}


def concepts_in(solution: str, prompt: str) -> set[str]:
    found = set()
    sol = solution
    for cid, rx in COMPILED.items():
        if rx.search(sol):
            found.add(cid)
    # multiple cout statements -> chaining / multiple prints
    if sol.count("cout") >= 2:
        found.add("multiple_output")
    # function definition (a return-type name '(' ... ')' '{') besides main
    for m in re.finditer(r"\b([a-zA-Z_][\w:<>&]*)\s+([a-zA-Z_]\w*)\s*\([^;{]*\)\s*\{", sol):
        if m.group(2) != "main":
            found.add("function_def")
            fname = m.group(2)
            # recursion: function body mentions its own name as a call
            if re.search(r"\b" + re.escape(fname) + r"\s*\(", sol[m.end():]):
                found.add("recursion")
            break
    return found


def main():
    lesson_concepts = collections.defaultdict(set)
    lesson_tasks = collections.defaultdict(list)
    for f in glob.glob(os.path.join(ROOT, "content/tasks/*.json")):
        d = json.load(open(f, encoding="utf-8"))
        lid = d["lesson_id"]
        lesson_tasks[lid].append(d["task_id"])
        cs = concepts_in(d.get("reference_solution", ""), d.get("prompt", ""))
        lesson_concepts[lid] |= cs

    out = {lid: sorted(cs) for lid, cs in lesson_concepts.items()}
    if "--json" in sys.argv:
        path = sys.argv[sys.argv.index("--json") + 1]
        json.dump({"lesson_concepts": out,
                   "lesson_tasks": {k: sorted(v) for k, v in lesson_tasks.items()}},
                  open(path, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
        print("wrote", path)
        return

    freq = collections.Counter()
    for cs in out.values():
        for c in cs:
            freq[c] += 1
    print("=== Concept frequency (in how many lessons) ===")
    for c, n in freq.most_common():
        print(f"  {c:20} {n}")
    print("\n=== Per-lesson concepts ===")
    for lid in sorted(out):
        print(f"{lid:32} {len(lesson_tasks[lid]):>3}t  {', '.join(out[lid])}")


if __name__ == "__main__":
    main()
