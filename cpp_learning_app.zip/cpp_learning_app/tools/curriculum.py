# -*- coding: utf-8 -*-
"""
tools/curriculum.py
===================
The course content as Python data (authored in Russian). The builder
(tools/build_content.py) turns this into content/*.json and VERIFIES every
output_match task by compiling its reference_solution and running the test
inputs, deriving the expected output from the known-correct solution.

Schema per task in this file:
  {
    "id": "block1_task1",
    "title": "...",
    "difficulty": 1,
    "prompt": "...",
    "starter": "...C++ skeleton...",
    "stdins": ["", "5\n"],          # one entry per test case
    "comparison_mode": "trim_trailing_whitespace",
    "hints": ["..","..",".."],
    "solution": "...correct C++...",
  }
For sfml_rubric tasks add "type": "sfml_rubric" and "rubric": [...].
"""

# Helper to keep solutions readable
def _io_header():
    return "#include <iostream>\n"


BLOCKS = [
    {"block_id": "block1", "title": "Основы",
     "description": "Переменные, типы данных, ввод и вывод, арифметика."},
    {"block_id": "block2", "title": "Управление потоком",
     "description": "Условия, циклы, массивы, работа со строками."},
    {"block_id": "block3", "title": "Функции",
     "description": "Свои функции, параметры, рекурсия, ссылки и указатели."},
    {"block_id": "block4", "title": "Память и указатели",
     "description": "Указатели, динамическая память, умные указатели."},
    {"block_id": "block5", "title": "ООП",
     "description": "Классы, объекты, наследование, полиморфизм."},
    {"block_id": "block6", "title": "Графика и визуальные задачи (SFML)",
     "description": "Окно, фигуры, анимация и управление с клавиатуры."},
    {"block_id": "block7", "title": "STL и продвинутые темы",
     "description": "vector, map, set, алгоритмы, исключения, файлы."},
    {"block_id": "block8", "title": "Джуниор-проекты",
     "description": "Маленькие законченные программы из изученного."},
]


# ===========================================================================
# BLOCK 1 — Основы
# ===========================================================================
BLOCK1_LESSONS = [
    {
        "lesson_id": "block1_lesson1",
        "order_in_block": 1,
        "title": "Первая программа и вывод на экран",
        "estimated_minutes": 12,
        "theory_blocks": [
            {"type": "text",
             "content": "Представь, что компьютер — это очень исполнительный, но совсем неопытный помощник. Он делает ровно то, что ты напишешь, шаг за шагом. Программа — это список таких команд."},
            {"type": "text",
             "content": "Любая программа на C++ начинается с функции `main`. Это как главная дверь в дом: компьютер всегда входит именно через неё. Всё, что внутри фигурных скобок `{ }` функции `main`, выполняется по порядку, сверху вниз."},
            {"type": "code_example",
             "code": "#include <iostream>\n\nint main() {\n    std::cout << \"Привет, мир!\";\n    return 0;\n}",
             "explanation": "Строка `#include <iostream>` — берём с полки инструмент для вывода на экран. `std::cout` — это «печатающее устройство», а `<<` направляет в него текст. `return 0;` сообщает, что программа завершилась успешно."},
        ],
        "key_takeaways": [
            "Программа на C++ начинается с функции `int main()`.",
            "`std::cout << ...;` выводит текст на экран.",
            "Каждая команда заканчивается точкой с запятой `;`.",
        ],
        "common_mistakes": [
            "Забыть точку с запятой `;` в конце строки.",
            "Забыть `#include <iostream>` перед использованием `std::cout`.",
        ],
        "tasks": [
            {"id": "block1_task1", "title": "Поздоровайся с миром", "difficulty": 1,
             "prompt": "Выведи на экран ровно текст: Привет, мир!\nБез кавычек, на одной строке.",
             "starter": "#include <iostream>\n\nint main() {\n    // TODO: выведи нужный текст\n    return 0;\n}",
             "stdins": [""], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["Используй std::cout << ...;",
                       "Текст нужно взять в двойные кавычки: \"Привет, мир!\".",
                       "Строка целиком: std::cout << \"Привет, мир!\";"],
             "solution": "#include <iostream>\nint main(){ std::cout << \"Привет, мир!\"; return 0; }"},
            {"id": "block1_task2", "title": "Две строки", "difficulty": 1,
             "prompt": "Выведи на двух отдельных строках:\nПервая строка\nВторая строка",
             "starter": "#include <iostream>\n\nint main() {\n    // TODO\n    return 0;\n}",
             "stdins": [""], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["Перевод строки — это std::endl или \"\\n\".",
                       "Можно вывести два раза подряд.",
                       "std::cout << \"Первая строка\\n\" << \"Вторая строка\";"],
             "solution": "#include <iostream>\nint main(){ std::cout << \"Первая строка\\n\" << \"Вторая строка\"; }"},
            {"id": "block1_task3", "title": "Числа и текст вместе", "difficulty": 1,
             "prompt": "Выведи ровно: Мне 7 лет",
             "starter": "#include <iostream>\n\nint main() {\n    // TODO\n    return 0;\n}",
             "stdins": [""], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["Можно соединять текст и числа через <<.",
                       "std::cout << \"Мне \" << 7 << \" лет\";",
                       "Следи за пробелами внутри кавычек."],
             "solution": "#include <iostream>\nint main(){ std::cout << \"Мне \" << 7 << \" лет\"; }"},
        ],
    },
    {
        "lesson_id": "block1_lesson2",
        "order_in_block": 2,
        "title": "Переменные и типы данных",
        "estimated_minutes": 15,
        "theory_blocks": [
            {"type": "text",
             "content": "Переменная — это как коробка с наклейкой. На наклейке написано имя, а внутрь можно положить значение. Позже можно заглянуть в коробку по имени и узнать, что там лежит, или положить туда новое значение."},
            {"type": "text",
             "content": "У каждой коробки есть тип — какие именно вещи в неё можно класть. `int` — целые числа (например, 5, -3, 100). `double` — числа с дробной частью (например, 3.14). `char` — один символ (например, 'A'). `bool` — да/нет (`true`/`false`). `std::string` — строка текста."},
            {"type": "code_example",
             "code": "int age = 10;\ndouble price = 2.5;\nchar grade = 'A';\nstd::cout << age << \" \" << price << \" \" << grade;",
             "explanation": "Сначала пишем тип, потом имя, потом `=` и значение. `age` хранит число 10, `price` — 2.5, `grade` — символ 'A'."},
        ],
        "key_takeaways": [
            "Переменная — это именованная коробка для значения.",
            "Тип определяет, что можно хранить: int, double, char, bool, string.",
            "Сначала тип, потом имя: `int x = 5;`.",
        ],
        "common_mistakes": [
            "Использовать переменную, не объявив её сначала.",
            "Класть дробное число в `int` (дробная часть отбросится).",
        ],
        "tasks": [
            {"id": "block1_task4", "title": "Сумма двух чисел", "difficulty": 1,
             "prompt": "Считай с клавиатуры два целых числа (каждое на своей строке) и выведи их сумму.",
             "starter": "#include <iostream>\nint main(){\n    int a, b;\n    // TODO: считай a и b, выведи сумму\n    return 0;\n}",
             "stdins": ["2\n3\n", "10\n-4\n", "0\n0\n"], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["Считать число: std::cin >> a;",
                       "Можно считать сразу два: std::cin >> a >> b;",
                       "std::cout << a + b;"],
             "solution": "#include <iostream>\nint main(){ int a,b; std::cin>>a>>b; std::cout<<a+b; }"},
            {"id": "block1_task5", "title": "Площадь прямоугольника", "difficulty": 1,
             "prompt": "Считай ширину и высоту (два целых числа) и выведи площадь прямоугольника.",
             "starter": "#include <iostream>\nint main(){\n    int w, h;\n    // TODO\n    return 0;\n}",
             "stdins": ["3\n4\n", "5\n5\n", "7\n2\n"], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["Площадь = ширина * высота.", "Умножение — это знак *.",
                       "std::cout << w * h;"],
             "solution": "#include <iostream>\nint main(){ int w,h; std::cin>>w>>h; std::cout<<w*h; }"},
            {"id": "block1_task6", "title": "Имя и приветствие", "difficulty": 1,
             "prompt": "Считай одно слово (имя) и выведи: Привет, <имя>!\nНапример, для ввода Аня выведи: Привет, Аня!",
             "starter": "#include <iostream>\n#include <string>\nint main(){\n    std::string name;\n    // TODO\n    return 0;\n}",
             "stdins": ["Аня\n", "Иван\n"], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["Строку из одного слова читают так же: std::cin >> name;",
                       "Не забудь #include <string>.",
                       "std::cout << \"Привет, \" << name << \"!\";"],
             "solution": "#include <iostream>\n#include <string>\nint main(){ std::string n; std::cin>>n; std::cout<<\"Привет, \"<<n<<\"!\"; }"},
        ],
    },
    {
        "lesson_id": "block1_lesson3",
        "order_in_block": 3,
        "title": "Арифметика и деление",
        "estimated_minutes": 15,
        "theory_blocks": [
            {"type": "text",
             "content": "С числами можно делать привычные действия: сложение `+`, вычитание `-`, умножение `*`, деление `/`. Есть ещё особый знак `%` — это остаток от деления (например, 7 % 3 = 1, потому что 7 = 3+3+1)."},
            {"type": "text",
             "content": "Важная ловушка: если делить два целых числа (`int`), результат тоже будет целым, дробная часть просто отбрасывается. Например, 7 / 2 даст 3, а не 3.5. Чтобы получить дробный результат, хотя бы одно число должно быть дробным (`double`)."},
            {"type": "code_example",
             "code": "std::cout << 7 / 2 << \" \" << 7 % 2 << \" \" << 7.0 / 2;",
             "explanation": "`7 / 2` = 3 (целое деление). `7 % 2` = 1 (остаток). `7.0 / 2` = 3.5, потому что 7.0 — дробное число."},
        ],
        "key_takeaways": [
            "Операции: + - * / и остаток %.",
            "Целое / целое = целое (дробь отбрасывается).",
            "Чтобы делить «по-настоящему», используй double.",
        ],
        "common_mistakes": [
            "Ожидать 3.5 от 7/2 (получится 3).",
            "Делить на ноль.",
        ],
        "tasks": [
            {"id": "block1_task7", "title": "Частное и остаток", "difficulty": 2,
             "prompt": "Считай два целых числа a и b. Выведи в одной строке через пробел частное (целое деление) и остаток: сначала a/b, потом a%b.",
             "starter": "#include <iostream>\nint main(){\n    int a, b;\n    // TODO\n    return 0;\n}",
             "stdins": ["7\n2\n", "10\n3\n", "9\n3\n"], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["Целое деление — это a / b.", "Остаток — это a % b.",
                       "std::cout << a / b << \" \" << a % b;"],
             "solution": "#include <iostream>\nint main(){ int a,b; std::cin>>a>>b; std::cout<<a/b<<\" \"<<a%b; }"},
            {"id": "block1_task8", "title": "Среднее двух чисел", "difficulty": 2,
             "prompt": "Считай два целых числа и выведи их среднее арифметическое как дробное число. Например, для 3 и 4 среднее = 3.5.",
             "starter": "#include <iostream>\nint main(){\n    int a, b;\n    // TODO\n    return 0;\n}",
             "stdins": ["3\n4\n", "10\n20\n", "1\n2\n"], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["Сумму надо разделить на 2.0, а не на 2.",
                       "(a + b) / 2.0 даст дробный результат.",
                       "std::cout << (a + b) / 2.0;"],
             "solution": "#include <iostream>\nint main(){ int a,b; std::cin>>a>>b; std::cout<<(a+b)/2.0; }"},
            {"id": "block1_task9", "title": "Секунды в минуты", "difficulty": 2,
             "prompt": "Считай целое число секунд. Выведи, сколько это полных минут и сколько секунд осталось, в формате: <минуты> мин <секунды> сек. Например, для 130 выведи: 2 мин 10 сек",
             "starter": "#include <iostream>\nint main(){\n    int total;\n    // TODO\n    return 0;\n}",
             "stdins": ["130\n", "59\n", "600\n"], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["Полные минуты — это total / 60.", "Оставшиеся секунды — total % 60.",
                       "std::cout << total/60 << \" мин \" << total%60 << \" сек\";"],
             "solution": "#include <iostream>\nint main(){ int t; std::cin>>t; std::cout<<t/60<<\" мин \"<<t%60<<\" сек\"; }"},
        ],
    },
]


# ===========================================================================
# BLOCK 2 — Управление потоком
# ===========================================================================
BLOCK2_LESSONS = [
    {
        "lesson_id": "block2_lesson1",
        "order_in_block": 1,
        "title": "Условия: if и else",
        "estimated_minutes": 15,
        "theory_blocks": [
            {"type": "text",
             "content": "Иногда программа должна выбирать, что делать, в зависимости от ситуации. Это как развилка на дороге: если выполнено условие — идём налево, иначе — направо. В C++ для этого есть `if` (если) и `else` (иначе)."},
            {"type": "text",
             "content": "Условие — это проверка, которая бывает либо истинной, либо ложной. Сравнения: `==` (равно), `!=` (не равно), `<`, `>`, `<=`, `>=`. Обрати внимание: для проверки равенства нужны ДВА знака `==`, один знак `=` — это присваивание."},
            {"type": "code_example",
             "code": "int n = 5;\nif (n > 0) {\n    std::cout << \"положительное\";\n} else {\n    std::cout << \"не положительное\";\n}",
             "explanation": "Если `n` больше нуля — выводим «положительное», иначе — «не положительное». Код внутри `{ }` после if выполняется только когда условие истинно."},
        ],
        "key_takeaways": [
            "`if (условие) { ... } else { ... }` выбирает путь.",
            "Сравнение равенства — это `==`, а не `=`.",
            "Условие — истина или ложь.",
        ],
        "common_mistakes": [
            "Написать `=` вместо `==` в условии.",
            "Поставить `;` сразу после `if (...)`.",
        ],
        "tasks": [
            {"id": "block2_task1", "title": "Чётное или нечётное", "difficulty": 1,
             "prompt": "Считай целое число. Выведи слово «четное», если оно чётное, иначе «нечетное».",
             "starter": "#include <iostream>\nint main(){\n    int n;\n    std::cin >> n;\n    // TODO\n    return 0;\n}",
             "stdins": ["4\n", "7\n", "0\n"], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["Чётное число делится на 2 без остатка.", "Проверь n % 2 == 0.",
                       "if (n % 2 == 0) ... else ..."],
             "solution": "#include <iostream>\nint main(){ int n; std::cin>>n; if(n%2==0) std::cout<<\"четное\"; else std::cout<<\"нечетное\"; }"},
            {"id": "block2_task2", "title": "Знак числа", "difficulty": 2,
             "prompt": "Считай целое число и выведи: «положительное», «отрицательное» или «ноль».",
             "starter": "#include <iostream>\nint main(){\n    int n;\n    std::cin >> n;\n    // TODO\n    return 0;\n}",
             "stdins": ["5\n", "-3\n", "0\n"], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["Здесь три случая — пригодится else if.",
                       "Сначала проверь > 0, потом < 0, иначе ноль.",
                       "if(n>0)... else if(n<0)... else ..."],
             "solution": "#include <iostream>\nint main(){ int n; std::cin>>n; if(n>0) std::cout<<\"положительное\"; else if(n<0) std::cout<<\"отрицательное\"; else std::cout<<\"ноль\"; }"},
            {"id": "block2_task3", "title": "Максимум из двух", "difficulty": 2,
             "prompt": "Считай два целых числа и выведи большее из них. Если они равны — выведи любое (оно же).",
             "starter": "#include <iostream>\nint main(){\n    int a, b;\n    std::cin >> a >> b;\n    // TODO\n    return 0;\n}",
             "stdins": ["3\n8\n", "10\n2\n", "5\n5\n"], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["Сравни a и b.", "if (a > b) выведи a, иначе b.",
                       "if(a>b) std::cout<<a; else std::cout<<b;"],
             "solution": "#include <iostream>\nint main(){ int a,b; std::cin>>a>>b; if(a>b) std::cout<<a; else std::cout<<b; }"},
        ],
    },
    {
        "lesson_id": "block2_lesson2",
        "order_in_block": 2,
        "title": "Циклы: while и for",
        "estimated_minutes": 18,
        "theory_blocks": [
            {"type": "text",
             "content": "Цикл — это способ повторить действие много раз, не переписывая его. Представь, что ты хлопаешь в ладоши 10 раз: вместо того чтобы писать «хлопни» 10 раз, ты говоришь «повтори хлопок 10 раз»."},
            {"type": "text",
             "content": "Цикл `for` удобен, когда заранее известно, сколько раз повторять. У него три части: начало (`int i = 1`), условие продолжения (`i <= 5`) и шаг (`i++`, увеличить на 1)."},
            {"type": "code_example",
             "code": "for (int i = 1; i <= 5; i++) {\n    std::cout << i << \" \";\n}",
             "explanation": "Выведет: 1 2 3 4 5. `i` начинается с 1, цикл идёт пока `i <= 5`, и после каждого повтора `i` увеличивается на 1."},
        ],
        "key_takeaways": [
            "Цикл повторяет действия.",
            "`for (старт; условие; шаг)` — когда число повторов известно.",
            "`i++` означает «увеличить i на 1».",
        ],
        "common_mistakes": [
            "Бесконечный цикл из-за неверного условия или забытого шага.",
            "Ошибка на единицу: `<=` против `<`.",
        ],
        "tasks": [
            {"id": "block2_task4", "title": "Числа от 1 до N", "difficulty": 1,
             "prompt": "Считай целое число N и выведи числа от 1 до N через пробел в одной строке. Например, для N=4: 1 2 3 4",
             "starter": "#include <iostream>\nint main(){\n    int n;\n    std::cin >> n;\n    // TODO\n    return 0;\n}",
             "stdins": ["4\n", "1\n", "6\n"], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["Используй for от 1 до n.", "Выводи i и пробел в цикле.",
                       "for(int i=1;i<=n;i++) std::cout<<i<<\" \";"],
             "solution": "#include <iostream>\nint main(){ int n; std::cin>>n; for(int i=1;i<=n;i++) std::cout<<i<<\" \"; }"},
            {"id": "block2_task5", "title": "Сумма от 1 до N", "difficulty": 2,
             "prompt": "Считай число N и выведи сумму всех целых чисел от 1 до N. Например, для N=5: 15.",
             "starter": "#include <iostream>\nint main(){\n    int n;\n    std::cin >> n;\n    // TODO\n    return 0;\n}",
             "stdins": ["5\n", "1\n", "10\n"], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["Заведи переменную sum = 0.", "В цикле прибавляй i к sum.",
                       "int sum=0; for(...) sum+=i; std::cout<<sum;"],
             "solution": "#include <iostream>\nint main(){ int n; std::cin>>n; int s=0; for(int i=1;i<=n;i++) s+=i; std::cout<<s; }"},
            {"id": "block2_task6", "title": "Таблица умножения на число", "difficulty": 2,
             "prompt": "Считай число k. Выведи 10 строк вида: k x i = результат, для i от 1 до 10. Например, первая строка для k=3: 3 x 1 = 3",
             "starter": "#include <iostream>\nint main(){\n    int k;\n    std::cin >> k;\n    // TODO\n    return 0;\n}",
             "stdins": ["3\n", "5\n"], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["Цикл по i от 1 до 10.",
                       "В каждой строке выводи k, \" x \", i, \" = \", k*i и перевод строки.",
                       "std::cout<<k<<\" x \"<<i<<\" = \"<<k*i<<\"\\n\";"],
             "solution": "#include <iostream>\nint main(){ int k; std::cin>>k; for(int i=1;i<=10;i++) std::cout<<k<<\" x \"<<i<<\" = \"<<k*i<<\"\\n\"; }"},
        ],
    },
    {
        "lesson_id": "block2_lesson3",
        "order_in_block": 3,
        "title": "Массивы и строки",
        "estimated_minutes": 18,
        "theory_blocks": [
            {"type": "text",
             "content": "Массив — это ряд одинаковых коробок, стоящих в линию и пронумерованных. Нумерация начинается с НУЛЯ: первая коробка имеет номер 0, вторая — 1 и так далее. Номер называют индексом."},
            {"type": "text",
             "content": "Строка (`std::string`) во многом похожа на массив символов. У строки можно узнать длину через `.size()` или `.length()`, а к каждому символу обратиться по индексу: `s[0]` — первый символ."},
            {"type": "code_example",
             "code": "int a[3] = {10, 20, 30};\nstd::cout << a[0] << \" \" << a[2];",
             "explanation": "Массив `a` из трёх чисел. `a[0]` — первый элемент (10), `a[2]` — третий (30). Выход за границы (например, `a[3]`) — частая ошибка."},
        ],
        "key_takeaways": [
            "Массив — пронумерованный ряд элементов, индексы с 0.",
            "Длина строки — `s.size()`.",
            "Выход за границы массива — опасная ошибка.",
        ],
        "common_mistakes": [
            "Обращение к `a[n]` при размере n (выход за границу).",
            "Думать, что нумерация начинается с 1.",
        ],
        "tasks": [
            {"id": "block2_task7", "title": "Длина строки", "difficulty": 1,
             "prompt": "Считай одно слово и выведи количество символов в нём.",
             "starter": "#include <iostream>\n#include <string>\nint main(){\n    std::string s;\n    std::cin >> s;\n    // TODO\n    return 0;\n}",
             "stdins": ["привет\n", "C++\n"], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["У строки есть .size().", "Выведи s.size().",
                       "std::cout << s.size();"],
             "solution": "#include <iostream>\n#include <string>\nint main(){ std::string s; std::cin>>s; std::cout<<s.size(); }"},
            {"id": "block2_task8", "title": "Сумма массива", "difficulty": 2,
             "prompt": "Считай число N, затем N целых чисел. Выведи их сумму.",
             "starter": "#include <iostream>\nint main(){\n    int n;\n    std::cin >> n;\n    // TODO\n    return 0;\n}",
             "stdins": ["3\n1 2 3\n", "5\n10 20 30 40 50\n", "1\n7\n"], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["Можно не хранить массив — сразу прибавлять к сумме.",
                       "Цикл N раз: считай число, прибавь к sum.",
                       "for(i...){ std::cin>>x; sum+=x; }"],
             "solution": "#include <iostream>\nint main(){ int n; std::cin>>n; long s=0,x; for(int i=0;i<n;i++){std::cin>>x; s+=x;} std::cout<<s; }"},
            {"id": "block2_task9", "title": "Максимум в массиве", "difficulty": 2,
             "prompt": "Считай N, затем N целых чисел. Выведи наибольшее из них.",
             "starter": "#include <iostream>\nint main(){\n    int n;\n    std::cin >> n;\n    // TODO\n    return 0;\n}",
             "stdins": ["4\n3 9 2 7\n", "3\n-5 -1 -9\n", "1\n42\n"], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["Запомни первое число как текущий максимум.",
                       "Сравнивай каждое следующее с максимумом.",
                       "if(x>maxv) maxv=x;"],
             "solution": "#include <iostream>\nint main(){ int n; std::cin>>n; int x,m; std::cin>>x; m=x; for(int i=1;i<n;i++){std::cin>>x; if(x>m)m=x;} std::cout<<m; }"},
        ],
    },
]


# ===========================================================================
# BLOCK 3 — Функции
# ===========================================================================
BLOCK3_LESSONS = [
    {
        "lesson_id": "block3_lesson1",
        "order_in_block": 1,
        "title": "Свои функции",
        "estimated_minutes": 16,
        "theory_blocks": [
            {"type": "text",
             "content": "Функция — это команда, которую ты придумал сам и дал ей имя. Это как рецепт: один раз записал, как готовить блюдо, а потом просто говоришь «приготовь его», сколько угодно раз."},
            {"type": "text",
             "content": "У функции есть тип возвращаемого значения (что она отдаёт обратно), имя и параметры (что ей нужно дать на вход). Слово `return` отдаёт результат обратно тому, кто вызвал функцию."},
            {"type": "code_example",
             "code": "int square(int x) {\n    return x * x;\n}\nint main(){ std::cout << square(5); }",
             "explanation": "Функция `square` принимает число `x` и возвращает его квадрат. В `main` мы вызываем `square(5)` и получаем 25."},
        ],
        "key_takeaways": [
            "Функция — именованный кусочек кода, который можно вызывать.",
            "`return` отдаёт результат обратно.",
            "Параметры — это вход функции.",
        ],
        "common_mistakes": [
            "Забыть `return` в функции, которая должна вернуть значение.",
            "Перепутать порядок аргументов при вызове.",
        ],
        "tasks": [
            {"id": "block3_task1", "title": "Функция куба", "difficulty": 2,
             "prompt": "Напиши функцию cube(x), возвращающую куб числа (x*x*x). В main считай целое число и выведи его куб.",
             "starter": "#include <iostream>\n\n// TODO: функция cube\n\nint main(){\n    int n;\n    std::cin >> n;\n    // TODO: вызови cube и выведи результат\n    return 0;\n}",
             "stdins": ["2\n", "3\n", "5\n"], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["Куб — это x*x*x.", "int cube(int x){ return x*x*x; }",
                       "В main: std::cout << cube(n);"],
             "solution": "#include <iostream>\nint cube(int x){return x*x*x;}\nint main(){ int n; std::cin>>n; std::cout<<cube(n); }"},
            {"id": "block3_task2", "title": "Максимум двух (функция)", "difficulty": 2,
             "prompt": "Напиши функцию maxOf(a, b), возвращающую большее из двух чисел. Считай два числа и выведи результат функции.",
             "starter": "#include <iostream>\n\n// TODO: функция maxOf\n\nint main(){\n    int a, b;\n    std::cin >> a >> b;\n    // TODO\n    return 0;\n}",
             "stdins": ["3\n8\n", "10\n2\n", "5\n5\n"], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["Внутри функции сравни a и b.",
                       "return (a > b) ? a : b; или через if.",
                       "int maxOf(int a,int b){ if(a>b) return a; return b; }"],
             "solution": "#include <iostream>\nint maxOf(int a,int b){ if(a>b) return a; return b; }\nint main(){ int a,b; std::cin>>a>>b; std::cout<<maxOf(a,b); }"},
            {"id": "block3_task3", "title": "Факториал", "difficulty": 3,
             "prompt": "Напиши функцию factorial(n), возвращающую n! (произведение чисел от 1 до n). Считай n и выведи factorial(n). Считай, что factorial(0) = 1.",
             "starter": "#include <iostream>\n\n// TODO: функция factorial\n\nint main(){\n    int n;\n    std::cin >> n;\n    // TODO\n    return 0;\n}",
             "stdins": ["5\n", "0\n", "6\n"], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["Заведи результат = 1 и умножай на каждое i.",
                       "Цикл от 1 до n.",
                       "long long f=1; for(int i=1;i<=n;i++) f*=i; return f;"],
             "solution": "#include <iostream>\nlong long factorial(int n){ long long f=1; for(int i=1;i<=n;i++) f*=i; return f; }\nint main(){ int n; std::cin>>n; std::cout<<factorial(n); }"},
        ],
    },
    {
        "lesson_id": "block3_lesson2",
        "order_in_block": 2,
        "title": "Ссылки и рекурсия",
        "estimated_minutes": 18,
        "theory_blocks": [
            {"type": "text",
             "content": "Обычно функция получает КОПИЮ значения. Если изменить параметр внутри функции, снаружи ничего не поменяется. Но иногда нужно, чтобы функция меняла саму переменную — тогда используют ссылку (`&`). Ссылка — это как второе имя той же самой коробки."},
            {"type": "text",
             "content": "Рекурсия — это когда функция вызывает саму себя. Это как матрёшка: внутри каждой куклы спрятана кукла поменьше, пока не дойдём до самой маленькой. У рекурсии обязательно должно быть условие остановки, иначе она будет бесконечной."},
            {"type": "code_example",
             "code": "void increment(int& x) { x++; }\nint main(){ int a = 5; increment(a); std::cout << a; }",
             "explanation": "Параметр `int& x` — это ссылка. Функция меняет саму переменную `a`, поэтому выведется 6, а не 5."},
        ],
        "key_takeaways": [
            "`&` в параметре — передача по ссылке (функция меняет оригинал).",
            "Рекурсия — функция вызывает сама себя.",
            "У рекурсии нужно условие остановки.",
        ],
        "common_mistakes": [
            "Рекурсия без условия остановки (бесконечность).",
            "Ожидать изменения переменной без ссылки.",
        ],
        "tasks": [
            {"id": "block3_task4", "title": "Удвоить через ссылку", "difficulty": 2,
             "prompt": "Напиши функцию doubleIt(int& x), которая удваивает переданную переменную. В main считай число, вызови функцию и выведи изменённое значение.",
             "starter": "#include <iostream>\n\n// TODO: функция doubleIt\n\nint main(){\n    int n;\n    std::cin >> n;\n    // TODO\n    return 0;\n}",
             "stdins": ["5\n", "0\n", "-3\n"], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["Параметр должен быть ссылкой: int& x.",
                       "Внутри: x = x * 2; или x *= 2;",
                       "void doubleIt(int& x){ x*=2; }"],
             "solution": "#include <iostream>\nvoid doubleIt(int& x){ x*=2; }\nint main(){ int n; std::cin>>n; doubleIt(n); std::cout<<n; }"},
            {"id": "block3_task5", "title": "Сумма цифр (рекурсия)", "difficulty": 3,
             "prompt": "Напиши рекурсивную функцию digitSum(n), возвращающую сумму цифр неотрицательного числа. Например, digitSum(123) = 6. Считай число и выведи результат.",
             "starter": "#include <iostream>\n\n// TODO: рекурсивная функция digitSum\n\nint main(){\n    int n;\n    std::cin >> n;\n    // TODO\n    return 0;\n}",
             "stdins": ["123\n", "0\n", "9999\n"], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["Последняя цифра — это n % 10.", "Остальное число — n / 10.",
                       "if(n==0) return 0; return n%10 + digitSum(n/10);"],
             "solution": "#include <iostream>\nint digitSum(int n){ if(n==0) return 0; return n%10 + digitSum(n/10); }\nint main(){ int n; std::cin>>n; std::cout<<digitSum(n); }"},
        ],
    },
]


# ===========================================================================
# BLOCK 4 — Память и указатели
# ===========================================================================
BLOCK4_LESSONS = [
    {
        "lesson_id": "block4_lesson1",
        "order_in_block": 1,
        "title": "Указатели простыми словами",
        "estimated_minutes": 18,
        "theory_blocks": [
            {"type": "text",
             "content": "Указатель — это переменная, которая хранит не само значение, а АДРЕС другой переменной. Представь дом: внутри лежит вещь (значение), а у дома есть адрес. Указатель — это бумажка с адресом дома, а не сам дом."},
            {"type": "text",
             "content": "Знак `&` перед переменной означает «дай её адрес». Знак `*` перед указателем означает «загляни по этому адресу и возьми значение» (это называют разыменованием)."},
            {"type": "code_example",
             "code": "int x = 42;\nint* p = &x;\nstd::cout << *p;",
             "explanation": "`p` хранит адрес `x`. `*p` означает «значение по адресу p», то есть 42. Если написать `*p = 10;`, то изменится сам `x`."},
        ],
        "key_takeaways": [
            "Указатель хранит адрес переменной.",
            "`&x` — адрес, `*p` — значение по адресу.",
            "Через указатель можно менять оригинал.",
        ],
        "common_mistakes": [
            "Разыменование указателя, который ни на что не указывает (nullptr).",
            "Путать `*` при объявлении и при разыменовании.",
        ],
        "tasks": [
            {"id": "block4_task1", "title": "Значение по указателю", "difficulty": 2,
             "prompt": "Считай целое число в переменную x. Заведи указатель на x и выведи значение через указатель (через *p).",
             "starter": "#include <iostream>\nint main(){\n    int x;\n    std::cin >> x;\n    // TODO: указатель на x и вывод *p\n    return 0;\n}",
             "stdins": ["42\n", "-7\n"], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["int* p = &x;", "Выведи *p.", "std::cout << *p;"],
             "solution": "#include <iostream>\nint main(){ int x; std::cin>>x; int* p=&x; std::cout<<*p; }"},
            {"id": "block4_task2", "title": "Изменение через указатель", "difficulty": 3,
             "prompt": "Считай число x. Через указатель прибавь к x число 100 (используя *p). Выведи получившееся x.",
             "starter": "#include <iostream>\nint main(){\n    int x;\n    std::cin >> x;\n    // TODO\n    return 0;\n}",
             "stdins": ["1\n", "0\n", "-50\n"], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["int* p = &x;", "*p = *p + 100; меняет сам x.",
                       "Выведи x (не p)."],
             "solution": "#include <iostream>\nint main(){ int x; std::cin>>x; int* p=&x; *p=*p+100; std::cout<<x; }"},
        ],
    },
    {
        "lesson_id": "block4_lesson2",
        "order_in_block": 2,
        "title": "Динамическая память и умные указатели",
        "estimated_minutes": 18,
        "theory_blocks": [
            {"type": "text",
             "content": "Иногда нужно создать данные «на ходу», когда программа уже работает. Для этого есть `new` — он выделяет память и возвращает указатель. Но за каждым `new` обязан следовать `delete`, иначе память «теряется» (утечка). Это как взять книгу в библиотеке — её нужно вернуть."},
            {"type": "text",
             "content": "Чтобы не забывать про `delete`, придумали умные указатели. `std::unique_ptr` сам освобождает память, когда она больше не нужна. Это как библиотека, которая сама забирает книгу обратно."},
            {"type": "code_example",
             "code": "#include <memory>\nauto p = std::make_unique<int>(7);\nstd::cout << *p;",
             "explanation": "`make_unique<int>(7)` создаёт число 7 в динамической памяти и даёт умный указатель. `*p` — это 7. Память освободится автоматически."},
        ],
        "key_takeaways": [
            "`new` выделяет память, `delete` освобождает.",
            "На каждый `new` нужен свой `delete`.",
            "`unique_ptr` освобождает память сам.",
        ],
        "common_mistakes": [
            "Забыть `delete` (утечка памяти).",
            "Использовать память после `delete`.",
        ],
        "tasks": [
            {"id": "block4_task3", "title": "Умный указатель", "difficulty": 3,
             "prompt": "Считай число n. Создай его в динамической памяти через std::make_unique<int>(n) и выведи значение через умный указатель.",
             "starter": "#include <iostream>\n#include <memory>\nint main(){\n    int n;\n    std::cin >> n;\n    // TODO\n    return 0;\n}",
             "stdins": ["15\n", "0\n"], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["auto p = std::make_unique<int>(n);",
                       "Выведи *p.", "std::cout << *p;"],
             "solution": "#include <iostream>\n#include <memory>\nint main(){ int n; std::cin>>n; auto p=std::make_unique<int>(n); std::cout<<*p; }"},
        ],
    },
]


# ===========================================================================
# BLOCK 5 — ООП
# ===========================================================================
BLOCK5_LESSONS = [
    {
        "lesson_id": "block5_lesson1",
        "order_in_block": 1,
        "title": "Классы и объекты",
        "estimated_minutes": 20,
        "theory_blocks": [
            {"type": "text",
             "content": "Класс — это чертёж, а объект — вещь, сделанная по этому чертёжу. Например, класс «Машина» описывает, что у любой машины есть цвет и скорость. А конкретная красная машина — это объект."},
            {"type": "text",
             "content": "Внутри класса есть поля (данные, как переменные) и методы (действия, как функции). Слово `public:` означает, что к этим полям и методам можно обращаться снаружи. Конструктор — особый метод, который создаёт объект и задаёт начальные значения."},
            {"type": "code_example",
             "code": "class Dog {\npublic:\n    std::string name;\n    void bark() { std::cout << name << \" гав!\"; }\n};\nint main(){ Dog d; d.name = \"Рекс\"; d.bark(); }",
             "explanation": "Класс `Dog` имеет поле `name` и метод `bark`. В main создаём объект `d`, задаём имя и зовём метод. Выведет: Рекс гав!"},
        ],
        "key_takeaways": [
            "Класс — чертёж, объект — конкретная вещь.",
            "Поля — данные, методы — действия.",
            "К объекту обращаемся через точку: `d.name`.",
        ],
        "common_mistakes": [
            "Забыть точку с запятой `;` после закрывающей скобки класса.",
            "Обращаться к private-полям снаружи класса.",
        ],
        "tasks": [
            {"id": "block5_task1", "title": "Класс Rectangle", "difficulty": 3,
             "prompt": "Опиши класс Rectangle с полями width и height (целые) и методом area(), возвращающим площадь. В main считай ширину и высоту, создай объект и выведи площадь.",
             "starter": "#include <iostream>\n\n// TODO: класс Rectangle\n\nint main(){\n    int w, h;\n    std::cin >> w >> h;\n    // TODO\n    return 0;\n}",
             "stdins": ["3\n4\n", "5\n5\n", "10\n2\n"], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["В классе поля width, height и метод int area().",
                       "area возвращает width*height.",
                       "Не забудь ; после } класса. Задай поля объекту перед вызовом area()."],
             "solution": "#include <iostream>\nclass Rectangle{ public: int width,height; int area(){ return width*height; } };\nint main(){ int w,h; std::cin>>w>>h; Rectangle r; r.width=w; r.height=h; std::cout<<r.area(); }"},
            {"id": "block5_task2", "title": "Конструктор счётчика", "difficulty": 3,
             "prompt": "Опиши класс Counter с полем value и конструктором, принимающим начальное значение. Добавь метод inc(), увеличивающий value на 1, и метод get(). В main считай стартовое число, создай счётчик, вызови inc() три раза и выведи get().",
             "starter": "#include <iostream>\n\n// TODO: класс Counter\n\nint main(){\n    int start;\n    std::cin >> start;\n    // TODO\n    return 0;\n}",
             "stdins": ["0\n", "10\n", "-3\n"], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["Конструктор: Counter(int v){ value=v; }",
                       "inc(): value++; get(): return value;",
                       "После трёх inc() значение = start+3."],
             "solution": "#include <iostream>\nclass Counter{ public: int value; Counter(int v){value=v;} void inc(){value++;} int get(){return value;} };\nint main(){ int s; std::cin>>s; Counter c(s); c.inc(); c.inc(); c.inc(); std::cout<<c.get(); }"},
        ],
    },
    {
        "lesson_id": "block5_lesson2",
        "order_in_block": 2,
        "title": "Наследование",
        "estimated_minutes": 18,
        "theory_blocks": [
            {"type": "text",
             "content": "Наследование позволяет одному классу взять всё от другого и добавить своё. Например, класс «Кошка» и «Собака» — оба «Животные». Вместо того чтобы повторять общее, мы выносим его в класс «Животное», а остальные его наследуют."},
            {"type": "code_example",
             "code": "class Animal { public: void eat(){ std::cout<<\"ест \"; } };\nclass Cat : public Animal { public: void meow(){ std::cout<<\"мяу\"; } };\nint main(){ Cat c; c.eat(); c.meow(); }",
             "explanation": "`Cat` наследует от `Animal` (запись `: public Animal`), поэтому у кошки есть и `eat` (от родителя), и свой `meow`. Выведет: ест мяу."},
        ],
        "key_takeaways": [
            "Наследование переиспользует код родителя.",
            "Запись `class B : public A`.",
            "Наследник получает поля и методы родителя.",
        ],
        "common_mistakes": [
            "Забыть `public` при наследовании (станет private).",
            "Обращаться к private-полям родителя напрямую.",
        ],
        "tasks": [
            {"id": "block5_task3", "title": "Животное и собака", "difficulty": 3,
             "prompt": "Опиши класс Animal с методом breathe(), который выводит «дышит». Класс Dog наследует Animal и добавляет метод bark(), выводящий «гав». В main создай Dog, вызови breathe(), затем bark() — на выходе должно получиться: дышит гав",
             "starter": "#include <iostream>\n\n// TODO: классы Animal и Dog\n\nint main(){\n    // TODO\n    return 0;\n}",
             "stdins": [""], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["class Dog : public Animal { ... };",
                       "breathe выводит \"дышит \" (с пробелом), bark — \"гав\".",
                       "Dog d; d.breathe(); d.bark();"],
             "solution": "#include <iostream>\nclass Animal{ public: void breathe(){ std::cout<<\"дышит \"; } };\nclass Dog : public Animal{ public: void bark(){ std::cout<<\"гав\"; } };\nint main(){ Dog d; d.breathe(); d.bark(); }"},
        ],
    },
]


# ===========================================================================
# BLOCK 6 — Графика (SFML). Tasks are type=sfml_rubric (source + run checks).
# ===========================================================================
BLOCK6_LESSONS = [
    {
        "lesson_id": "block6_lesson1",
        "order_in_block": 1,
        "title": "Первое окно SFML",
        "estimated_minutes": 20,
        "theory_blocks": [
            {"type": "text",
             "content": "До этого программы печатали текст. SFML — это библиотека, которая умеет рисовать окно, фигуры и картинки. Сначала нужно создать окно, а затем в цикле его перерисовывать, пока пользователь не закроет."},
            {"type": "text",
             "content": "Главная часть любой графической программы — игровой цикл (`while (window.isOpen())`). Внутри него: обработка событий (например, закрытие окна), очистка экрана, рисование и показ (`display`)."},
            {"type": "code_example",
             "code": "#include <SFML/Graphics.hpp>\nint main(){\n    sf::RenderWindow window(sf::VideoMode({400u, 300u}), \"Окно\");\n    while (window.isOpen()) {\n        while (const std::optional event = window.pollEvent())\n            if (event->is<sf::Event::Closed>()) window.close();\n        window.clear();\n        window.display();\n    }\n}",
             "explanation": "Создаём окно 400x300, крутим игровой цикл, обрабатываем закрытие, очищаем и показываем кадр. Пока — пустое окно."},
        ],
        "key_takeaways": [
            "SFML рисует окно и фигуры.",
            "Игровой цикл: события → clear → рисование → display.",
            "Нужен #include <SFML/Graphics.hpp>.",
        ],
        "common_mistakes": [
            "Забыть обрабатывать событие закрытия (окно «не закрывается»).",
            "Забыть window.display() (ничего не видно).",
        ],
        "tasks": [
            {"id": "block6_task1", "title": "Окно с заголовком", "difficulty": 2,
             "type": "sfml_rubric",
             "prompt": "Создай окно SFML размером 400x300 с заголовком и корректным игровым циклом: обработка закрытия, clear() и display(). Запусти и убедись, что окно открывается и закрывается по крестику.",
             "starter": "#include <SFML/Graphics.hpp>\nint main(){\n    // TODO: создай окно и игровой цикл\n    return 0;\n}",
             "stdins": [""], "comparison_mode": "exact",
             "rubric": [
                 {"id": "has_window", "description_ru": "Создаётся окно (RenderWindow)", "check_type": "regex_source", "pattern": "RenderWindow"},
                 {"id": "has_loop", "description_ru": "Есть игровой цикл isOpen()", "check_type": "regex_source", "pattern": "isOpen\\s*\\("},
                 {"id": "handles_close", "description_ru": "Обрабатывается закрытие окна", "check_type": "regex_source", "pattern": "Closed"},
                 {"id": "has_display", "description_ru": "Кадр показывается через display()", "check_type": "regex_source", "pattern": "display\\s*\\("},
                 {"id": "runs", "description_ru": "Программа запускается и не падает", "check_type": "runtime"},
             ],
             "hints": ["Скопируй структуру из примера в теории.",
                       "Не забудь pollEvent и проверку sf::Event::Closed.",
                       "В конце цикла window.clear(); window.display();"],
             "solution": "#include <SFML/Graphics.hpp>\nint main(){ sf::RenderWindow w(sf::VideoMode({400u,300u}),\"SFML\"); while(w.isOpen()){ while(const std::optional e = w.pollEvent()) if(e->is<sf::Event::Closed>()) w.close(); w.clear(); w.display(); } }"},
            {"id": "block6_task2", "title": "Нарисуй круг", "difficulty": 3,
             "type": "sfml_rubric",
             "prompt": "В окне SFML нарисуй круг (CircleShape) и покажи его. Запусти и проверь глазами, что круг виден.",
             "starter": "#include <SFML/Graphics.hpp>\nint main(){\n    sf::RenderWindow w(sf::VideoMode({400u, 300u}),\"Круг\");\n    // TODO: создай круг и рисуй его в цикле\n    return 0;\n}",
             "stdins": [""], "comparison_mode": "exact",
             "rubric": [
                 {"id": "has_circle", "description_ru": "Создаётся круг (CircleShape)", "check_type": "regex_source", "pattern": "CircleShape"},
                 {"id": "draws", "description_ru": "Круг рисуется через draw()", "check_type": "regex_source", "pattern": "draw\\s*\\("},
                 {"id": "has_display", "description_ru": "Есть display()", "check_type": "regex_source", "pattern": "display\\s*\\("},
                 {"id": "runs", "description_ru": "Программа запускается и не падает", "check_type": "runtime"},
             ],
             "hints": ["sf::CircleShape circle(50); задаёт радиус 50.",
                       "В цикле: w.clear(); w.draw(circle); w.display();",
                       "Можно задать цвет: circle.setFillColor(sf::Color::Green);"],
             "solution": "#include <SFML/Graphics.hpp>\nint main(){ sf::RenderWindow w(sf::VideoMode({400u,300u}),\"Круг\"); sf::CircleShape c(50.f); c.setFillColor(sf::Color::Green); while(w.isOpen()){ while(const std::optional e = w.pollEvent()) if(e->is<sf::Event::Closed>()) w.close(); w.clear(); w.draw(c); w.display(); } }"},
        ],
    },
]


# ===========================================================================
# BLOCK 7 — STL и продвинутые темы
# ===========================================================================
BLOCK7_LESSONS = [
    {
        "lesson_id": "block7_lesson1",
        "order_in_block": 1,
        "title": "vector — растущий массив",
        "estimated_minutes": 18,
        "theory_blocks": [
            {"type": "text",
             "content": "Обычный массив имеет фиксированный размер. `std::vector` — это «умный» массив, который умеет расти. В него можно добавлять элементы через `push_back`, узнавать размер через `.size()` и обращаться по индексу, как к обычному массиву."},
            {"type": "code_example",
             "code": "#include <vector>\nstd::vector<int> v;\nv.push_back(10);\nv.push_back(20);\nstd::cout << v.size() << \" \" << v[0];",
             "explanation": "Создаём пустой вектор, добавляем два числа. `v.size()` = 2, `v[0]` = 10. Вектор сам управляет памятью."},
        ],
        "key_takeaways": [
            "`std::vector` — массив, который умеет расти.",
            "`push_back` добавляет элемент в конец.",
            "`.size()` — текущее количество элементов.",
        ],
        "common_mistakes": [
            "Обращение к v[i] за границами (i >= size()).",
            "Забыть #include <vector>.",
        ],
        "tasks": [
            {"id": "block7_task1", "title": "Разворот последовательности", "difficulty": 3,
             "prompt": "Считай N, затем N целых чисел. Выведи их в обратном порядке через пробел.",
             "starter": "#include <iostream>\n#include <vector>\nint main(){\n    int n;\n    std::cin >> n;\n    // TODO\n    return 0;\n}",
             "stdins": ["3\n1 2 3\n", "5\n10 20 30 40 50\n", "1\n7\n"], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["Считай все числа в vector через push_back.",
                       "Иди циклом с конца к началу.",
                       "for(int i=v.size()-1;i>=0;i--) std::cout<<v[i]<<\" \";"],
             "solution": "#include <iostream>\n#include <vector>\nint main(){ int n; std::cin>>n; std::vector<int> v; for(int i=0;i<n;i++){int x; std::cin>>x; v.push_back(x);} for(int i=(int)v.size()-1;i>=0;i--) std::cout<<v[i]<<\" \"; }"},
            {"id": "block7_task2", "title": "Сортировка чисел", "difficulty": 3,
             "prompt": "Считай N, затем N целых чисел. Выведи их по возрастанию через пробел. Используй std::sort.",
             "starter": "#include <iostream>\n#include <vector>\n#include <algorithm>\nint main(){\n    int n;\n    std::cin >> n;\n    // TODO\n    return 0;\n}",
             "stdins": ["4\n3 1 4 2\n", "3\n9 9 1\n", "1\n5\n"], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["Собери числа в vector.",
                       "std::sort(v.begin(), v.end());",
                       "Потом выведи все элементы через пробел."],
             "solution": "#include <iostream>\n#include <vector>\n#include <algorithm>\nint main(){ int n; std::cin>>n; std::vector<int> v(n); for(auto& x:v) std::cin>>x; std::sort(v.begin(),v.end()); for(int x:v) std::cout<<x<<\" \"; }"},
        ],
    },
    {
        "lesson_id": "block7_lesson2",
        "order_in_block": 2,
        "title": "map — словарь",
        "estimated_minutes": 18,
        "theory_blocks": [
            {"type": "text",
             "content": "`std::map` — это словарь: пары «ключ → значение». Например, имя → возраст. По ключу можно быстро найти его значение. Это удобно для подсчётов: ключ — слово, значение — сколько раз встретилось."},
            {"type": "code_example",
             "code": "#include <map>\nstd::map<std::string,int> ages;\nages[\"Аня\"] = 10;\nstd::cout << ages[\"Аня\"];",
             "explanation": "Создаём словарь имя→возраст, записываем возраст Ани и читаем его. Если обратиться к несуществующему ключу, он создастся со значением по умолчанию (0 для int)."},
        ],
        "key_takeaways": [
            "`std::map<K,V>` хранит пары ключ→значение.",
            "Доступ по ключу: `m[key]`.",
            "Удобно для подсчёта частот.",
        ],
        "common_mistakes": [
            "Думать, что обращение к ключу не создаёт его (создаёт!).",
            "Забыть #include <map>.",
        ],
        "tasks": [
            {"id": "block7_task3", "title": "Подсчёт частот чисел", "difficulty": 3,
             "prompt": "Считай N, затем N целых чисел (0..9). Для каждого числа от 0 до 9, которое встречалось хотя бы раз, выведи на отдельной строке: <число>: <сколько раз>. Числа выводи по возрастанию.",
             "starter": "#include <iostream>\n#include <map>\nint main(){\n    int n;\n    std::cin >> n;\n    // TODO\n    return 0;\n}",
             "stdins": ["5\n1 1 2 3 3\n", "3\n5 5 5\n"], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["map<int,int> cnt; cnt[x]++ для каждого числа.",
                       "map хранит ключи по возрастанию автоматически.",
                       "for(auto& p: cnt) std::cout<<p.first<<\": \"<<p.second<<\"\\n\";"],
             "solution": "#include <iostream>\n#include <map>\nint main(){ int n; std::cin>>n; std::map<int,int> c; for(int i=0;i<n;i++){int x; std::cin>>x; c[x]++;} for(auto& p:c) std::cout<<p.first<<\": \"<<p.second<<\"\\n\"; }"},
        ],
    },
]


# ===========================================================================
# BLOCK 8 — Джуниор-проекты (капстоны)
# ===========================================================================
BLOCK8_LESSONS = [
    {
        "lesson_id": "block8_lesson1",
        "order_in_block": 1,
        "title": "Мини-проекты",
        "estimated_minutes": 30,
        "theory_blocks": [
            {"type": "text",
             "content": "Ты прошёл большой путь! Теперь соберём знания вместе в маленькие законченные программы. Не спеши: разбей задачу на шаги, реши каждый по отдельности, а потом соедини. Именно так работают настоящие программисты."},
            {"type": "text",
             "content": "Главный навык здесь — декомпозиция: большую задачу разбивают на маленькие понятные кусочки. Сначала прочитай данные, потом обработай, потом выведи результат."},
        ],
        "key_takeaways": [
            "Большую задачу дели на маленькие шаги.",
            "Сначала ввод, потом обработка, потом вывод.",
            "Проверяй на простых примерах.",
        ],
        "common_mistakes": [
            "Пытаться написать всё сразу, не разбив на части.",
            "Не проверить программу на крайних случаях.",
        ],
        "tasks": [
            {"id": "block8_task1", "title": "Проект: калькулятор", "difficulty": 3,
             "prompt": "Считай выражение из трёх частей: число, знак операции (+ - * /) и второе число (каждое на своей строке или через пробел). Выведи результат. Для деления гарантируется, что делитель не ноль, и числа делятся нацело — используй целые числа.",
             "starter": "#include <iostream>\nint main(){\n    int a, b;\n    char op;\n    std::cin >> a >> op >> b;\n    // TODO\n    return 0;\n}",
             "stdins": ["4 + 5\n", "10 - 3\n", "6 * 7\n", "20 / 4\n"], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["Считай число, символ операции, число.",
                       "Разбери op через if/else или switch.",
                       "Для '+' выведи a+b, и так далее."],
             "solution": "#include <iostream>\nint main(){ int a,b; char op; std::cin>>a>>op>>b; if(op=='+') std::cout<<a+b; else if(op=='-') std::cout<<a-b; else if(op=='*') std::cout<<a*b; else std::cout<<a/b; }"},
            {"id": "block8_task2", "title": "Проект: проверка палиндрома", "difficulty": 3,
             "prompt": "Считай одно слово. Выведи «да», если оно читается одинаково слева направо и справа налево (палиндром), иначе «нет».",
             "starter": "#include <iostream>\n#include <string>\nint main(){\n    std::string s;\n    std::cin >> s;\n    // TODO\n    return 0;\n}",
             "stdins": ["abba\n", "hello\n", "a\n"], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["Сравнивай первый символ с последним, второй с предпоследним.",
                       "Можно сравнить строку с её разворотом.",
                       "std::string r(s.rbegin(),s.rend()); if(s==r) ..."],
             "solution": "#include <iostream>\n#include <string>\nint main(){ std::string s; std::cin>>s; std::string r(s.rbegin(),s.rend()); std::cout<<(s==r?\"да\":\"нет\"); }"},
            {"id": "block8_task3", "title": "Проект: числа Фибоначчи", "difficulty": 3,
             "prompt": "Считай N. Выведи первые N чисел Фибоначчи через пробел. Последовательность начинается с 1 1, дальше каждое число — сумма двух предыдущих. Например, N=6: 1 1 2 3 5 8",
             "starter": "#include <iostream>\nint main(){\n    int n;\n    std::cin >> n;\n    // TODO\n    return 0;\n}",
             "stdins": ["6\n", "1\n", "10\n"], "comparison_mode": "trim_trailing_whitespace",
             "hints": ["Держи два предыдущих числа a=1, b=1.",
                       "Выводи a, затем сдвигай: следующее = a+b.",
                       "Аккуратно с первыми двумя выводами."],
             "solution": "#include <iostream>\nint main(){ int n; std::cin>>n; long long a=1,b=1; for(int i=0;i<n;i++){ std::cout<<a<<\" \"; long long t=a+b; a=b; b=t; } }"},
        ],
    },
]


# ===========================================================================
# Assembly
# ===========================================================================
ALL_LESSONS = (
    BLOCK1_LESSONS + BLOCK2_LESSONS + BLOCK3_LESSONS + BLOCK4_LESSONS
    + BLOCK5_LESSONS + BLOCK6_LESSONS + BLOCK7_LESSONS + BLOCK8_LESSONS
)

# Practice lessons generated from the validated task bank (tools/gen_curriculum.py).
# These add hundreds of compile-verified practice tasks grouped by topic and
# ordered by difficulty. If the generated file is missing, run:
#   python3 tools/gen_curriculum.py
try:
    from curriculum_bank import PRACTICE_LESSONS as _PRACTICE_LESSONS  # noqa: E402
    ALL_LESSONS = ALL_LESSONS + _PRACTICE_LESSONS
except ImportError:
    pass


def lesson_block_id(lesson_id: str) -> str:
    return lesson_id.split("_")[0]
