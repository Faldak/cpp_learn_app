# -*- coding: utf-8 -*-
"""
verify_theory.py
================
The 2-stage check Bruh asked for, run on EVERY lesson:

  CHECK 1 (coverage): is everything that appears in this lesson's tasks
          actually explained in its theory? For each concept detected in the
          lesson's tasks, the theory must contain that concept's section
          (deep title) OR its recap line. Missing -> FAIL.

  CHECK 2 (quality): did we just restate "write it like this" (bad), or did we
          give a real explanation — a memory hook (🧠), a "why/чтобы" framing,
          enough depth — and NOT leak a ready solution to a task (good)?
          A lesson FAILS if:
            - it introduces a concept but that concept's deep block lacks a
              🧠 memory hook or a "чтобы/почему" framing word, OR
            - the theory contains a verbatim ready solution to one of its tasks,
            - or the theory is too short to be meaningful.

Exit code 0 only if all lessons pass both checks.
Run: python3 tools/verify_theory.py
"""
from __future__ import annotations
import json, os, re, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LESSONS = os.path.join(ROOT, "content/lessons")
TASKS = os.path.join(ROOT, "content/tasks")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from theory_content import CONCEPTS  # noqa

FRAMING = ("чтобы", "почему", "представь", "напомним")
MIN_THEORY_CHARS = 200


def lesson_text(les: dict) -> str:
    parts = []
    for b in les.get("theory_blocks", []):
        parts.append(b.get("content", ""))
        parts.append(b.get("code", ""))
        parts.append(b.get("explanation", ""))
    parts += les.get("key_takeaways", [])
    parts += les.get("common_mistakes", [])
    return "\n".join(parts)


def norm_code(s: str) -> str:
    return re.sub(r"\s+", "", s)


def main():
    concepts = json.load(open(os.path.join(ROOT, "tools/_concepts.json"),
                               encoding="utf-8"))["lesson_concepts"]
    tasks_by_lesson = {}
    for fn in os.listdir(TASKS):
        d = json.load(open(os.path.join(TASKS, fn), encoding="utf-8"))
        tasks_by_lesson.setdefault(d["lesson_id"], []).append(d)

    fails = []
    for fn in sorted(os.listdir(LESSONS)):
        if not fn.endswith(".json"):
            continue
        les = json.load(open(os.path.join(LESSONS, fn), encoding="utf-8"))
        lid = les["lesson_id"]
        text = lesson_text(les)
        ntext = norm_code(text)

        # ---- CHECK 1: coverage ----
        for c in concepts.get(lid, []):
            if c not in CONCEPTS:
                continue
            title = CONCEPTS[c]["title"]
            recap = CONCEPTS[c]["recap"]
            if title not in text and recap not in text:
                fails.append((lid, "C1-coverage", f"concept '{c}' not explained"))

        # ---- CHECK 2: quality ----
        if len(text) < MIN_THEORY_CHARS:
            fails.append((lid, "C2-depth", f"theory too short ({len(text)} chars)"))

        # introduced (deep) concepts must carry a memory hook + framing
        for c, meta in CONCEPTS.items():
            if meta["title"] in text:  # deep section present in this lesson
                deep_txt = "\n".join(b.get("content", "") + b.get("explanation", "")
                                     for b in meta["deep"])
                if "🧠" not in deep_txt:
                    fails.append((lid, "C2-hook", f"'{c}' deep block has no 🧠 hook"))
                if not any(w in deep_txt.lower() for w in FRAMING):
                    fails.append((lid, "C2-framing", f"'{c}' deep block lacks why-framing"))

        # no ready solution to this lesson's tasks leaked verbatim
        for t in tasks_by_lesson.get(lid, []):
            sol = norm_code(t.get("reference_solution", ""))
            # ignore trivial/very short solutions to avoid false positives
            core = sol.replace("#include<iostream>", "").replace("usingnamespacestd;", "")
            core = core.replace("intmain(){", "").replace("return0;}", "").rstrip("}")
            if len(core) >= 25 and core in ntext:
                fails.append((lid, "C2-leak", f"ready solution of task {t['task_id']} in theory"))

        if intro_ok := les.get("theory_blocks"):
            pass
        else:
            fails.append((lid, "C2-intro", "no theory blocks"))

    if not fails:
        print("✅ ALL LESSONS PASS both checks (coverage + quality).")
        return 0
    print(f"❌ {len(fails)} issue(s):")
    for lid, kind, msg in fails:
        print(f"  [{kind}] {lid}: {msg}")
    return 1


if __name__ == "__main__":
    sys.exit(main())
