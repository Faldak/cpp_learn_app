"""
Backend tests: compiler_service, task_checker, error_dictionary, progress_db,
plus a guard that all user-facing UI strings are Russian (no English leakage).
These exercise the deterministic core that decides task correctness.
"""

from __future__ import annotations

import re
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import config  # noqa: E402

config.DB_PATH = Path(tempfile.mktemp(suffix=".db"))  # type: ignore

import compiler_service as cs  # noqa: E402
import error_dictionary as ed  # noqa: E402
import progress_db  # noqa: E402
import task_checker as tc  # noqa: E402
import content_loader  # noqa: E402

HELLO = '#include <iostream>\nint main(){ std::cout << "hi"; }'


# --- compiler_service --------------------------------------------------------
def test_compiler_available():
    assert cs.detect_compiler(), "C++ compiler must be available for tests"


def test_compile_and_run_ok():
    res = cs.compile_source(HELLO)
    assert res.ok, res.compiler_stderr
    rr = cs.run_executable(res.executable_path)
    assert rr.ran and rr.stdout == "hi"


def test_compile_error_detected():
    bad = "int main(){ cout << 1; }"  # missing include/std::
    res = cs.compile_source(bad)
    assert not res.ok
    assert res.compiler_stderr


def test_stdin_passed():
    src = ('#include <iostream>\nint main(){ int a,b; std::cin>>a>>b; '
           'std::cout<<a+b; }')
    res = cs.compile_source(src)
    assert res.ok
    rr = cs.run_executable(res.executable_path, stdin="2 3\n")
    assert rr.stdout.strip() == "5"


# --- task_checker ------------------------------------------------------------
def test_checker_passes_reference_solutions():
    # Every output_match task's reference solution must pass its own check.
    for tid in content_loader.all_task_ids():
        task = content_loader.get_task(tid)
        if task["type"] != "output_match":
            continue
        res = tc.check_task(task["reference_solution"], task)
        assert res.passed, f"reference solution failed for {tid}: {res.compile_error}"


def test_checker_fails_wrong_output():
    task = content_loader.get_task("block1_task1")
    wrong = '#include <iostream>\nint main(){ std::cout << "wrong"; }'
    res = tc.check_task(wrong, task)
    assert not res.passed


def test_compare_modes():
    assert tc.compare_output("ok\n", "ok", "trim_trailing_whitespace")
    assert not tc.compare_output("ok ", "ok", "exact")


# --- error_dictionary --------------------------------------------------------
def test_error_dictionary_matches_common():
    stderr = "error: 'cout' was not declared in this scope; did you mean 'std::cout'?"
    m = ed.match_error(stderr)
    assert m is not None
    assert m.title_ru and ed.looks_russian_ok(m.title_ru) if hasattr(ed, "looks_russian_ok") else m.title_ru


def test_error_dictionary_has_patterns():
    assert ed.pattern_count() >= 20


# --- progress_db -------------------------------------------------------------
def test_progress_roundtrip():
    progress_db.init_db()
    progress_db.open_lesson("block1_lesson1")
    n = progress_db.record_attempt(task_id="block1_task1", lesson_id="block1_lesson1",
                                   passed=True, submitted_code="int main(){}")
    assert n >= 1
    assert progress_db.get_task_status("block1_task1")["best_status"] == "passed"
    assert progress_db.count_passed_tasks() >= 1


# --- no-English UI strings ---------------------------------------------------
def test_ui_strings_are_russian():
    from ui import strings_ru as S
    cyr = re.compile(r"[А-Яа-яЁё]")
    offenders = []
    for name in dir(S):
        if name.startswith("_") or not name.isupper():
            continue
        val = getattr(S, name)
        if not isinstance(val, str) or not val.strip():
            continue
        # strip placeholders/punctuation; require at least some Cyrillic
        letters = re.sub(r"[^A-Za-zА-Яа-яЁё]", "", val)
        if letters and not cyr.search(val):
            offenders.append((name, val))
    assert not offenders, f"Non-Russian UI strings: {offenders}"
