"""
Headless UI instantiation test.

We cannot open a real desktop window in CI/sandbox, but Flet controls are plain
objects that can be constructed without a display. This test builds every major
view's control tree against a temp DB to catch API/attribute errors before
shipping. It does NOT call .update() (that needs a live page) — our views guard
those calls behind try/except, and build paths don't trigger them.
"""

from __future__ import annotations

import sys
import tempfile
import types
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import config  # noqa: E402

# Point DB at a temp file BEFORE importing progress-dependent modules use it.
config.DB_PATH = Path(tempfile.mktemp(suffix=".db"))  # type: ignore

import progress_db  # noqa: E402
import content_loader  # noqa: E402
from ui import theme as themelib  # noqa: E402


class StubShell:
    """Minimal stand-in for AppShell for build-only testing."""
    def __init__(self):
        self.theme = "dark"
        self.pal = themelib.palette("dark")
        self.page = types.SimpleNamespace(
            update=lambda *a, **k: None,
            show_dialog=lambda *a, **k: None,
            controls=[],
            add=lambda *a, **k: None,
        )

    def show_lessons(self, *a, **k): pass
    def open_task(self, *a, **k): pass
    def show_dashboard(self, *a, **k): pass
    def show_settings(self, *a, **k): pass
    def set_theme(self, *a, **k): pass


def test_content_present():
    progress_db.init_db()
    assert len(content_loader.blocks()) == 8
    assert content_loader.total_task_count() >= 30
    assert content_loader.ordered_lesson_ids()


def test_build_lessons_screen():
    from ui.lesson_view import LessonsScreen
    shell = StubShell()
    first = content_loader.ordered_lesson_ids()[0]
    screen = LessonsScreen(shell)
    tree = screen.build(first)
    assert tree is not None


def test_build_lessons_for_task():
    from ui.lesson_view import LessonsScreen
    shell = StubShell()
    tid = content_loader.all_task_ids()[0]
    screen = LessonsScreen(shell)
    assert screen.build_for_task(tid) is not None


def test_build_dashboard():
    from ui.dashboard_view import build_dashboard
    assert build_dashboard(StubShell()) is not None


def test_build_settings():
    from ui.settings_view import build_settings
    assert build_settings(StubShell()) is not None


def test_build_onboarding():
    from ui.onboarding_view import build_onboarding
    assert build_onboarding(StubShell(), on_done=lambda: None) is not None


def test_report_view_render():
    import task_checker
    from ui.report_view import build_report
    shell = StubShell()
    task = content_loader.get_task("block1_task1")
    # A correct solution should pass.
    res = task_checker.check_task(task["reference_solution"], task)
    clean = task_checker.code_cleanliness(task["reference_solution"], 1)
    rep = build_report(shell.pal, task, res, clean,
                       on_explain=lambda e: None, on_explain_error=lambda e: None)
    assert rep is not None
    assert res.passed is True


if __name__ == "__main__":
    test_content_present()
    test_build_lessons_screen()
    test_build_lessons_for_task()
    test_build_dashboard()
    test_build_settings()
    test_build_onboarding()
    test_report_view_render()
    print("[OK] all headless UI build tests passed")
