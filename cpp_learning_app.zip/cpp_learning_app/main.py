"""
main.py
=======
Flet desktop application entrypoint for "C++ с нуля".

Flow:
  1. ensure data dirs + initialize the SQLite progress DB
  2. open a native desktop window (NOT web mode)
  3. if onboarding not completed -> show the onboarding gate
     else -> mount the main AppShell (lessons / dashboard / settings)

Run with:  python main.py
Package with:  flet pack main.py  (see README.md)
"""

from __future__ import annotations

import flet as ft

import config
import progress_db
from ui import theme as themelib
from ui.app_shell import AppShell
from ui.onboarding_view import build_onboarding


def main(page: ft.Page) -> None:
    page.title = config.APP_DISPLAY_NAME
    page.window.width = 1280
    page.window.height = 820
    page.window.min_width = 980
    page.window.min_height = 640
    page.padding = 0

    theme = progress_db.get_setting("theme", config.DEFAULT_THEME) or config.DEFAULT_THEME
    pal = themelib.palette(theme)
    page.theme_mode = ft.ThemeMode.DARK if theme == "dark" else ft.ThemeMode.LIGHT
    page.bgcolor = pal.bg

    def launch_app():
        page.controls.clear()
        shell = AppShell(page)
        shell.mount()

    def show_gate():
        page.controls.clear()
        # A lightweight shell just to carry palette/theme into onboarding.
        gate_shell = AppShell(page)
        page.add(build_onboarding(gate_shell, on_done=launch_app))
        page.update()

    if progress_db.is_onboarding_completed():
        launch_app()
    else:
        show_gate()


if __name__ == "__main__":
    config.ensure_dirs()
    progress_db.init_db()
    ft.run(main)
