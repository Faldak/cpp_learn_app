"""
task_checker.py
===============
Deterministic correctness checking. NO AI here — this module is the single
source of truth for "did the task pass" (spec section 2).

Two task types:
  - output_match : compile, run against each test case, compare stdout.
  - sfml_rubric  : compile (+ optional run/observe), then run a generic rubric
                   engine over the SOURCE and runtime behaviour.

Also provides `code_cleanliness(...)`: a small set of deterministic static
checks producing an informative 1-5 rating (never blocks pass/fail).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Optional

import compiler_service as cs


# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------
@dataclass
class TestCaseResult:
    index: int
    stdin: str
    expected: str
    actual: str
    passed: bool
    note: str = ""


@dataclass
class RubricItemResult:
    id: str
    description_ru: str
    passed: bool
    detail_ru: str = ""


@dataclass
class CheckResult:
    passed: bool
    task_type: str
    compiled: bool
    compile_error: str = ""              # raw stderr (or sentinel) for Tier-1/2
    test_results: list[TestCaseResult] = field(default_factory=list)
    rubric_results: list[RubricItemResult] = field(default_factory=list)
    runtime_note_ru: str = ""
    duration_seconds: float = 0.0

    def rubric_as_dicts(self) -> list[dict]:
        return [
            {"id": r.id, "description_ru": r.description_ru,
             "passed": r.passed, "detail_ru": r.detail_ru}
            for r in self.rubric_results
        ]


# ---------------------------------------------------------------------------
# Output comparison
# ---------------------------------------------------------------------------
def _normalize(text: str, mode: str) -> str:
    if mode == "exact":
        return text
    if mode == "trim_trailing_whitespace":
        return "\n".join(line.rstrip() for line in text.splitlines()).rstrip("\n")
    if mode == "normalize_whitespace":
        return re.sub(r"\s+", " ", text).strip()
    return text


def compare_output(actual: str, expected: str, mode: str = "trim_trailing_whitespace") -> bool:
    return _normalize(actual, mode) == _normalize(expected, mode)


# ---------------------------------------------------------------------------
# output_match checking
# ---------------------------------------------------------------------------
def check_output_match(source: str, task: dict) -> CheckResult:
    mode = task.get("comparison_mode", "trim_trailing_whitespace")
    use_sanitizer = bool(task.get("use_sanitizer", False))

    compiled = cs.compile_source(source, use_sanitizer=use_sanitizer)
    if not compiled.ok:
        return CheckResult(
            passed=False, task_type="output_match", compiled=False,
            compile_error=compiled.compiler_stderr,
        )

    results: list[TestCaseResult] = []
    all_pass = True
    total_time = 0.0
    test_cases = task.get("test_cases") or [{"stdin": "", "expected_stdout": ""}]
    for i, tc in enumerate(test_cases):
        stdin = tc.get("stdin", "")
        expected = tc.get("expected_stdout", "")
        rr = cs.run_executable(compiled.executable_path, stdin=stdin)
        total_time += rr.duration_seconds
        if rr.timed_out:
            results.append(TestCaseResult(i, stdin, expected, rr.stdout, False,
                                          "Программа выполнялась слишком долго (возможно, бесконечный цикл)."))
            all_pass = False
            continue
        if not rr.ran:
            results.append(TestCaseResult(i, stdin, expected, "", False, "Не удалось запустить программу."))
            all_pass = False
            continue
        ok = compare_output(rr.stdout, expected, mode)
        note = ""
        if not ok and rr.crashed:
            note = f"Программа завершилась с ошибкой (код {rr.exit_code})."
        results.append(TestCaseResult(i, stdin, expected, rr.stdout, ok, note))
        if not ok:
            all_pass = False

    return CheckResult(
        passed=all_pass, task_type="output_match", compiled=True,
        test_results=results, duration_seconds=total_time,
    )


# ---------------------------------------------------------------------------
# sfml_rubric checking
# ---------------------------------------------------------------------------
def _run_rubric_check(check: dict, source: str, compiled: cs.CompileResult) -> RubricItemResult:
    cid = check.get("id", "")
    desc = check.get("description_ru", "")
    ctype = check.get("check_type")

    if ctype == "regex_source":
        pat = check.get("pattern", "")
        found = re.search(pat, source) is not None
        return RubricItemResult(cid, desc, found,
                                "Найдено в коде." if found else "Не найдено в коде.")

    if ctype == "count_regex":
        pat = check.get("pattern", "")
        need = int(check.get("min_count", 1))
        cnt = len(re.findall(pat, source))
        ok = cnt >= need
        return RubricItemResult(cid, desc, ok, f"Найдено {cnt}, требуется минимум {need}.")

    if ctype == "runtime":
        # NOTE: fully automated "does it look like a horse" is OUT OF SCOPE.
        # We only confirm the program compiles and does not crash on launch.
        if not compiled.ok or not compiled.executable_path:
            return RubricItemResult(cid, desc, False, "Программа не скомпилировалась.")
        rr = cs.observe_windowed(compiled.executable_path)
        if not rr.ran:
            return RubricItemResult(cid, desc, False, "Не удалось запустить программу.")
        if rr.crashed:
            return RubricItemResult(cid, desc, False,
                                    f"Программа упала вскоре после запуска (код {rr.exit_code}).")
        return RubricItemResult(cid, desc, True,
                                "Программа запустилась и не упала в первые секунды.")

    return RubricItemResult(cid, desc, False, "Неизвестный тип проверки.")


def check_sfml_rubric(source: str, task: dict) -> CheckResult:
    compiled = cs.compile_source(source, use_sfml=True)
    rubric = task.get("rubric_checks", [])

    # If it didn't compile, still report rubric source-checks (helpful), but the
    # runtime check + overall pass will fail.
    results: list[RubricItemResult] = []
    for check in rubric:
        results.append(_run_rubric_check(check, source, compiled))

    all_pass = compiled.ok and all(r.passed for r in results)
    note = ("Помни: автоматически нельзя проверить, что рисунок действительно "
            "похож на задумку — посмотри на открывшееся окно сам и оцени "
            "результат глазами.")
    return CheckResult(
        passed=all_pass,
        task_type="sfml_rubric",
        compiled=compiled.ok,
        compile_error=compiled.compiler_stderr if not compiled.ok else "",
        rubric_results=results,
        runtime_note_ru=note,
    )


# ---------------------------------------------------------------------------
# Dispatcher
# ---------------------------------------------------------------------------
def check_task(source: str, task: dict) -> CheckResult:
    ttype = task.get("type", "output_match")
    if ttype == "sfml_rubric":
        return check_sfml_rubric(source, task)
    return check_output_match(source, task)


# ---------------------------------------------------------------------------
# Code cleanliness (informative only, 1-5; never blocks pass/fail)
# ---------------------------------------------------------------------------
@dataclass
class CleanlinessResult:
    rating: int                  # 1..5
    notes_ru: list[str] = field(default_factory=list)
    positives_ru: list[str] = field(default_factory=list)


def code_cleanliness(source: str, difficulty: int = 1) -> CleanlinessResult:
    notes: list[str] = []
    positives: list[str] = []
    score = 5

    lines = source.splitlines()
    code_lines = [ln for ln in lines if ln.strip()]

    # Mixed tabs/spaces in indentation
    has_tab_indent = any(ln.startswith("\t") for ln in lines)
    has_space_indent = any(ln.startswith(" ") for ln in lines)
    if has_tab_indent and has_space_indent:
        notes.append("В отступах смешаны табы и пробелы — выбери что-то одно (обычно пробелы).")
        score -= 1
    else:
        positives.append("Отступы оформлены единообразно.")

    # Comments expected for difficulty > 2
    has_comment = bool(re.search(r"//|/\*", source))
    if difficulty > 2 and not has_comment:
        notes.append("Для задач посложнее полезно добавить хотя бы один комментарий, поясняющий код.")
        score -= 1
    elif has_comment:
        positives.append("В коде есть поясняющие комментарии.")

    # Commented-out dead code (heuristic: // followed by code-like tokens)
    dead = sum(1 for ln in lines if re.match(r"\s*//\s*(?:int|for|while|if|std::|cout|cin|return)\b", ln))
    if dead >= 2:
        notes.append("Есть закомментированный «мёртвый» код — лучше удалить лишнее.")
        score -= 1

    # Overly long lines
    long_lines = [i + 1 for i, ln in enumerate(lines) if len(ln) > 100]
    if long_lines:
        notes.append(f"Слишком длинные строки (например, строка {long_lines[0]}) — их тяжело читать.")
        score -= 1

    # Single-letter non-loop variable names (soft suggestion)
    declared = re.findall(r"\b(?:int|double|float|char|bool|auto|string)\s+([a-zA-Z_]\w*)", source)
    loopish = {"i", "j", "k", "n", "m", "t"}
    bad_names = [v for v in declared if len(v) == 1 and v not in loopish]
    if bad_names:
        notes.append(f"Имена-однобуквы (например, `{bad_names[0]}`) делают код менее понятным — "
                     "давай переменным осмысленные имена.")
        # soft: don't subtract for this

    score = max(1, min(5, score))
    if not notes:
        positives.append("Код выглядит аккуратно — так держать!")
    return CleanlinessResult(rating=score, notes_ru=notes, positives_ru=positives)


if __name__ == "__main__":
    task = {
        "type": "output_match",
        "comparison_mode": "trim_trailing_whitespace",
        "test_cases": [{"stdin": "", "expected_stdout": "Привет, мир!"}],
    }
    src = '#include <iostream>\nint main(){ std::cout << "Привет, мир!"; }\n'
    res = check_task(src, task)
    print("passed:", res.passed, "compiled:", res.compiled)
    print(code_cleanliness(src, 1))
