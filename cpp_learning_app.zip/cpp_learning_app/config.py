"""
config.py
=========
Central configuration for the C++ learning desktop app.

Responsibilities:
  - OS detection
  - Cross-platform paths (user data dir, db path, logs, config file)
  - Per-OS compiler invocation details
  - Per-OS SFML linker flags (loaded from / written to a JSON config file,
    NOT hardcoded inline, since exact flags vary by SFML version + OS)
  - App-wide constants (timeouts, limits, default AI model)

All comments / identifiers here are intentionally in English (internal,
the end user never reads this file). User-facing strings live in
ui/strings_ru.py and the content/*.json files.
"""

from __future__ import annotations

import json
import platform
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# App identity
# ---------------------------------------------------------------------------
APP_NAME = "cpp_learning_app"
APP_DISPLAY_NAME = "C++ с нуля"  # window title (user-facing -> Russian)
APP_AUTHOR = "cpp_learning_app"

# ---------------------------------------------------------------------------
# OS detection
# ---------------------------------------------------------------------------
_SYS = platform.system().lower()  # 'windows' | 'darwin' | 'linux'


def is_windows() -> bool:
    return _SYS.startswith("win")


def is_macos() -> bool:
    return _SYS == "darwin"


def is_linux() -> bool:
    return _SYS == "linux"


def os_key() -> str:
    """Stable short key used to index per-OS config (flags, paths, etc.)."""
    if is_windows():
        return "windows"
    if is_macos():
        return "macos"
    return "linux"


# ---------------------------------------------------------------------------
# Paths (cross-platform via platformdirs; fallback if not installed)
# ---------------------------------------------------------------------------
def _user_data_dir() -> Path:
    try:
        import platformdirs  # type: ignore

        return Path(platformdirs.user_data_dir(APP_NAME, APP_AUTHOR))
    except Exception:
        # Minimal fallback so the app still runs before deps are installed.
        home = Path.home()
        if is_windows():
            base = Path.home() / "AppData" / "Roaming"
        elif is_macos():
            base = home / "Library" / "Application Support"
        else:
            base = home / ".local" / "share"
        return base / APP_NAME


USER_DATA_DIR: Path = _user_data_dir()
DB_PATH: Path = USER_DATA_DIR / "progress.db"
CONFIG_FILE: Path = USER_DATA_DIR / "app_config.json"
SFML_FLAGS_FILE: Path = USER_DATA_DIR / "sfml_flags.json"

# Logs live next to the source during development; documented in README.
PROJECT_ROOT: Path = Path(__file__).resolve().parent
LOG_DIR: Path = PROJECT_ROOT / "logs"
APP_LOG_FILE: Path = LOG_DIR / "app.log"
AI_LOG_FILE: Path = LOG_DIR / "ai.log"

CONTENT_DIR: Path = PROJECT_ROOT / "content"
LESSONS_DIR: Path = CONTENT_DIR / "lessons"
TASKS_DIR: Path = CONTENT_DIR / "tasks"
COURSE_STRUCTURE_FILE: Path = CONTENT_DIR / "course_structure.json"


def ensure_dirs() -> None:
    """Create all directories the app expects to exist. Safe to call repeatedly."""
    for d in (USER_DATA_DIR, LOG_DIR, CONTENT_DIR, LESSONS_DIR, TASKS_DIR):
        d.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------------------
# Compiler configuration
# ---------------------------------------------------------------------------
COMPILER_CANDIDATES = ["g++", "clang++"]  # checked in order during detection
CPP_STANDARD = "c++17"

# Execution safety limits (used by compiler_service.py)
COMPILE_TIMEOUT_SECONDS = 20
RUN_TIMEOUT_SECONDS = 5            # catches infinite loops in console tasks
SFML_RUNTIME_OBSERVE_SECONDS = 2  # how long we watch an SFML window before killing it
MAX_OUTPUT_BYTES = 256 * 1024     # cap captured stdout/stderr

# Sanitizer flags used for the memory-bugs block (Block 4).
SANITIZER_FLAGS = ["-fsanitize=address", "-g"]


# ---------------------------------------------------------------------------
# SFML linker flags (per OS) — persisted to JSON so they can be tuned without
# touching source. These are sensible defaults; onboarding may overwrite them.
# ---------------------------------------------------------------------------
_DEFAULT_SFML_FLAGS = {
    "linux": ["-lsfml-graphics", "-lsfml-window", "-lsfml-system"],
    "macos": ["-lsfml-graphics", "-lsfml-window", "-lsfml-system"],
    # Windows/MinGW typically needs include + lib dirs too; user fills these in
    # via onboarding. Defaults assume SFML on PATH / standard MinGW layout.
    "windows": ["-lsfml-graphics", "-lsfml-window", "-lsfml-system"],
}


def get_sfml_flags() -> list[str]:
    """Return SFML linker flags for the current OS, loading overrides from disk."""
    flags = dict(_DEFAULT_SFML_FLAGS)
    try:
        if SFML_FLAGS_FILE.exists():
            saved = json.loads(SFML_FLAGS_FILE.read_text(encoding="utf-8"))
            if isinstance(saved, dict):
                flags.update(saved)
    except Exception:
        pass
    return list(flags.get(os_key(), _DEFAULT_SFML_FLAGS["linux"]))


def save_sfml_flags(flags_by_os: dict) -> None:
    ensure_dirs()
    SFML_FLAGS_FILE.write_text(
        json.dumps(flags_by_os, ensure_ascii=False, indent=2), encoding="utf-8"
    )


# ---------------------------------------------------------------------------
# AI configuration (Groq, OpenAI-compatible endpoint)
# ---------------------------------------------------------------------------
GROQ_BASE_URL = "https://api.groq.com/openai/v1"
GROQ_CHAT_ENDPOINT = f"{GROQ_BASE_URL}/chat/completions"
# Model name is configurable; this is only a default. ai_client.py must handle
# the case where Groq has deprecated this model and surface a Russian error.
DEFAULT_AI_MODEL = "llama-3.3-70b-versatile"
# Selectable models in Settings (all Groq, OpenAI-compatible).
GROQ_MODELS = [
    "llama-3.3-70b-versatile",
    "llama-3.1-8b-instant",
    "openai/gpt-oss-20b",
]
AI_REQUEST_TIMEOUT_SECONDS = 15
AI_MAX_RETRIES = 3


# ---------------------------------------------------------------------------
# Theme defaults
# ---------------------------------------------------------------------------
DEFAULT_THEME = "dark"  # 'dark' | 'light'


# ---------------------------------------------------------------------------
# Diagnostics helper (used by onboarding + the dev smoke test below)
# ---------------------------------------------------------------------------
def describe_environment() -> dict:
    return {
        "python_version": sys.version.split()[0],
        "os": os_key(),
        "platform": platform.platform(),
        "user_data_dir": str(USER_DATA_DIR),
        "db_path": str(DB_PATH),
        "sfml_flags": get_sfml_flags(),
        "default_ai_model": DEFAULT_AI_MODEL,
    }


if __name__ == "__main__":
    # Quick manual sanity check: `python config.py`
    ensure_dirs()
    import pprint

    pprint.pprint(describe_environment())
