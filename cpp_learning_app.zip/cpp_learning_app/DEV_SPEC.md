

---

## ROLE AND CONTEXT

You are acting as a senior software architect and full-stack developer. You will build a complete, professional, locally-running desktop application that teaches a complete programming beginner the C++ language, from absolute zero to junior-developer level, with real compilation, real code execution, an AI-powered explanation layer, and persistent progress tracking.

**Critical constraint about the end user**: the person who will use this app has ZERO programming experience. They cannot read or write code, cannot debug, cannot install dependencies without exact step-by-step instructions, and relies entirely on AI coding agents (like you) to build and fix this software for them. This means:
- Every error you produce during development must be handled and explained to them in plain language if it requires their action (e.g., "please install X").
- Never assume they can read a stack trace, edit a config file, or run a terminal command without being told the exact, copy-pasteable command.
- After every major step, produce a short plain-language README section (in Russian — see language requirements below) explaining what was built, how to run it, and what to check.

**Critical constraint about the application's language**: this is non-negotiable. **Every single piece of user-facing text in the application — UI labels, buttons, menu items, lesson theory text, task descriptions, error explanations, AI assistant responses, progress reports, tooltips, onboarding text, README files meant for the end user, everything — must be written in Russian (русский язык), with zero exceptions.** Code comments, variable names, function names, commit messages, and internal technical documentation (architecture docs meant for you, the developer agent) may remain in English, since the end user will never read those. But anything that renders on screen or that the AI assistant says to the user must be Russian. When you generate the AI system prompt for the in-app assistant (see section 6), that system prompt must explicitly and forcefully instruct the assistant model to respond ONLY in Russian, regardless of what language any error message or stack trace happens to contain.

---

## 1. TECH STACK — FIXED DECISIONS, DO NOT DEVIATE

- **Language for the application itself**: Python 3.11+. The end user does not know Node.js and explicitly does not want it. Do not introduce any Node.js/Electron dependency.
- **UI framework**: Flet (https://flet.dev) — a Python framework that renders a native-feeling desktop window (built on Flutter under the hood, but the developer never touches Dart/Flutter directly, only Python). Use `flet` pip package, target desktop mode (`ft.app(target=main, view=ft.AppView.FLET_APP)`), not web mode.
- **Code editor component**: the user wants an editing experience similar to VS Code — syntax highlighting for C++, line numbers, bracket matching, at minimum. Investigate and use a Monaco Editor embed inside a Flet `WebView`/`HTML` control, OR a CodeMirror 6 embed (lighter weight, easier to theme, well-documented Python+web integration) inside a Flet webview control. Pick whichever integrates more reliably inside a Flet desktop app without requiring a bundled Chromium/Node toolchain. Document the decision and the fallback (if Monaco/CodeMirror embedding proves unreliable inside Flet's webview, fall back to Flet's own `TextField` with a custom regex-based C++ syntax highlighter overlay — still must visually resemble VS Code's dark theme, with line numbers).
- **C++ compiler**: g++ via MinGW-w64 on Windows, or system g++/clang on macOS/Linux. The application calls the compiler via Python's `subprocess` module. The application must NOT bundle its own compiler — it detects an existing installation and, if missing, shows the user a clear Russian-language step-by-step installation guide with a button that opens the correct download page for their detected OS.
- **Graphics library for visual tasks**: SFML (Simple and Fast Multimedia Library) for C++. This is required starting from a specific block of tasks (see section 4, Block 6) where the user writes code that opens a window and draws shapes (e.g., "draw a horse using basic shapes"). The application must detect whether SFML is installed and linkable, and if not, provide an exact, OS-specific installation guide in Russian (for Windows: download links + exact linker flags to add; for Linux: exact `apt`/`dnf`/`pacman` install commands; for macOS: exact `brew install sfml` command). Compilation commands for SFML tasks must include the correct linker flags (e.g. `-lsfml-graphics -lsfml-window -lsfml-system` on Linux/macOS, or the appropriate MinGW SFML linking flags on Windows) — store these flags in a config file per OS, not hardcoded inline, since exact flags vary by SFML version and OS.
- **Database / progress storage**: SQLite via Python's built-in `sqlite3` module. No external database server. Single local file, e.g. `%APPDATA%/cpp_learning_app/progress.db` on Windows or `~/.local/share/cpp_learning_app/progress.db` on Linux/macOS (use `platformdirs` pip package to resolve this cross-platform correctly — do not hardcode paths).
- **AI provider**: Groq API (OpenAI-compatible chat completions endpoint, https://api.groq.com/openai/v1/chat/completions). The user has a free-tier Groq API key. Build a thin wrapper module `ai_client.py` that:
  - Reads the API key from a local config file or environment variable, never hardcoded in source.
  - Defaults to a fast, currently-available Groq-hosted model suitable for code explanation (at the time you build this, check Groq's model list via their docs/API — do not assume a specific model name will still exist; make the model name a configurable setting with a sensible default, and handle the case where the configured model has been deprecated by Groq, showing the user a clear Russian error with instructions to check available models).
  - Implements retry logic with exponential backoff for rate-limit errors (HTTP 429), since free-tier keys hit limits easily.
  - Implements a hard timeout (e.g. 15 seconds) after which it falls back gracefully to a Russian message: "Не удалось получить ответ от ИИ-помощника. Попробуй ещё раз через минуту, либо посмотри объяснение в теории урока." Never let an AI failure crash the app or block the user from proceeding.
  - Logs (locally, not sent anywhere) every AI request and response for debugging purposes, with timestamps, to help diagnose the "weak free model gives wrong explanations" problem over time.

---

## 2. CORE PRINCIPLE — SEPARATION OF DETERMINISTIC LOGIC FROM AI

This is the most important architectural decision in this project and must be respected everywhere. The user explicitly does not trust their free, weak AI key to be the source of truth for anything. Therefore:

- **Task correctness checking is NEVER done by AI.** A task is correct or incorrect based on deterministic, scriptable checks only:
  - For console/text-output tasks: exact (or whitespace-normalized, documented in task config) string match between the program's stdout and a stored expected output, OR a set of test-input/expected-output pairs run automatically (see section 4 for the task schema).
  - For SFML graphical tasks (e.g. "draw a horse"): correctness CANNOT be pixel-matched reliably against a single "correct" image, since infinite valid drawings exist. Instead, build a **rubric-based automated check**: the checking script inspects the user's source code (via simple static analysis: regex/AST-lite scanning for required SFML API calls) for evidence that required elements are present — e.g. "creates a `sf::RenderWindow`", "calls `window.draw(...)` at least N times", "uses at least 2 different shape types (`sf::CircleShape`, `sf::RectangleShape`, `sf::ConvexShape`, etc.)", "has a main loop that calls `window.display()`". This produces a checklist-style pass/fail per rubric item, not a binary correct/incorrect — see the "mini-report" format in section 4.4. The AI is then used ONLY to write the human-readable summary paragraph of that already-computed checklist, in Russian — it does not decide whether requirements were met, the script does.
  - **The AI is explicitly forbidden from being the final arbiter of "right" or "wrong".** It only explains results that a deterministic script already computed.
- **Compiler error → human explanation pipeline is two-tiered:**
  1. **Tier 1 (no AI, instant, always available):** a local Python dictionary/pattern-matcher (`error_dictionary.py`) containing at least 40 common g++ error patterns for beginners (missing semicolon, undeclared identifier, mismatched brackets, missing `#include`, using `=` instead of `==`, off-by-one in loop bounds causing out-of-range access — detectable via crash signature if using sanitizers, type mismatch in assignment, calling a function with wrong number of arguments, forgetting `return` in non-void function, scope/visibility errors with classes, missing `std::` namespace prefix, undefined reference / linker errors from missing implementation, etc.). Each pattern maps a regex (matched against raw g++ stderr) to a pre-written, friendly Russian explanation template with placeholders filled in from the matched error (line number, variable name, etc.).
  2. **Tier 2 (AI, only when Tier 1 finds no match):** the raw g++ error, the user's source code, and the current lesson's context are sent to the Groq AI with a carefully engineered Russian-language system prompt (see section 6) asking it to explain the error simply, like to a complete beginner, in Russian, without giving away the full corrected code (it should explain the concept and point at the problem, not just paste a fix) unless the user explicitly asks for the answer.
- **Progress tracking, history, "streaks", and weekly reports are pure data aggregation — zero AI involved.** These are SQL queries against the SQLite database, formatted into Russian-language UI components. AI is never in this loop, so it is always instant and always correct.

This design means: if the Groq free key is slow, rate-limited, or occasionally wrong, the user never loses progress data, never gets a wrongly-graded task, and never gets blocked from continuing — they only occasionally get a worse-quality *explanation* of an error, which they can re-request or read the static lesson theory instead.

---

## 3. APPLICATION ARCHITECTURE — MODULES

Build the project with this folder structure (adjust only if you find a strictly better Python packaging convention, but keep the conceptual separation):

```
cpp_learning_app/
├── main.py                      # Flet app entrypoint
├── config.py                    # paths, constants, OS detection, compiler flags per OS
├── ai_client.py                 # Groq API wrapper (see section 1)
├── compiler_service.py          # subprocess wrapper: compile + run user code, capture stdout/stderr/exit code, enforce execution timeout (e.g. 5s, to catch infinite loops) and memory/output size limits
├── error_dictionary.py          # Tier-1 pattern-matched error explanations (Russian)
├── task_checker.py              # deterministic correctness checking (text-output tasks AND SFML rubric tasks)
├── progress_db.py               # SQLite schema + all read/write functions (see section 5 for schema)
├── content/
│   ├── course_structure.json    # full topic tree, see section 4
│   ├── lessons/                 # one JSON file per lesson: theory text, examples
│   └── tasks/                   # one JSON file per task: prompt, starter code, expected output / rubric, hints, difficulty
├── ui/
│   ├── app_shell.py              # main window layout: sidebar, top bar, content area
│   ├── sidebar.py                 # topic/lesson navigation tree with progress indicators
│   ├── lesson_view.py              # theory display + code editor + run button + output panel
│   ├── code_editor_component.py    # the VS-Code-like editor wrapper (Monaco/CodeMirror webview)
│   ├── report_view.py              # mini-report after task submission (see 4.4)
│   ├── dashboard_view.py           # "today", "this week" stats screens (see section 7)
│   ├── onboarding_view.py          # first-run setup wizard (compiler detection, SFML detection, API key entry)
│   └── theme.py                    # dark theme matching VS Code aesthetic, all strings centralized here for Russian text (do not scatter raw strings across files — see section 8)
├── installers/
│   ├── compiler_setup_guide.py    # OS-detection + Russian install instructions for g++/MinGW
│   └── sfml_setup_guide.py        # OS-detection + Russian install instructions + correct linker flags for SFML
├── tests/                       # pytest tests for compiler_service, task_checker, error_dictionary, progress_db
└── README.md                    # written for the end user, in Russian, explaining how to install and run
```

Build this incrementally across multiple sessions, in this order, and confirm each step runs before moving to the next:
1. `config.py` + empty Flet window that opens (`main.py`) — confirm a window appears.
2. `compiler_service.py` + a hardcoded test: compile and run a trivial "hello world" C++ string, print result to console (not yet in UI) — confirm real compilation works on the developer's machine.
3. `progress_db.py` with schema (section 5) + basic read/write test via pytest.
4. `ui/app_shell.py` + `ui/sidebar.py` with a hardcoded fake topic list — confirm navigation UI renders.
5. `content/course_structure.json` skeleton (even with placeholder lesson titles) wired into the sidebar — confirm real navigation works.
6. `ui/code_editor_component.py` — get the embedded editor rendering with C++ syntax highlighting, confirm typing works, confirm you can read its current text content from Python.
7. `ui/lesson_view.py` wiring the editor + a "Запустить" button to `compiler_service.py`, displaying raw stdout/stderr in an output panel — confirm a real lesson screen compiles and runs user code end to end.
8. `task_checker.py` for text-output tasks, wired to show pass/fail in the UI.
9. `error_dictionary.py` wired in: when compilation fails, try Tier 1 first, display result.
10. `ai_client.py` wired in as Tier 2 fallback when Tier 1 finds no match, AND as an on-demand "Объяснить подробнее" / "Помощь с заданием" button the user can click anytime.
11. `ui/onboarding_view.py` — compiler detection + SFML detection + Groq API key entry screen, shown on first launch only.
12. `ui/dashboard_view.py` — stats screens (section 7).
13. `ui/report_view.py` — mini-report screen (section 4.4), including SFML rubric-based reporting.
14. SFML task type fully wired: extended `compiler_service.py` linker flags, extended `task_checker.py` rubric engine, extended `content/tasks/` schema to support rubric-type tasks.
15. Polish pass: error states, empty states, loading states, window resizing, app icon, packaging instructions (how the user turns this into a runnable .exe/app — investigate PyInstaller or Flet's built-in `flet pack` command, document exact steps).

Do not let the agent (you, Opus) attempt to write all 15 steps in one giant response. Treat each as a discrete task with its own verification.

---

## 4. CONTENT STRUCTURE — THE COURSE ITSELF

### 4.1 Topic blocks

Build `content/course_structure.json` representing this topic tree. Target total task count across the whole course: **300–400 tasks**, distributed roughly as follows (adjust proportionally, this is a guide not a hard law):

1. **Основы (Foundations)** — ~50 tasks. Variables, data types, input/output (`cin`/`cout`), basic arithmetic and operators, type casting, constants, basic string operations.
2. **Управление потоком (Control flow)** — ~55 tasks. `if`/`else`/`switch`, `for`/`while`/`do-while` loops, nested loops, `break`/`continue`, basic arrays (1D and 2D), `std::string` deeper operations.
3. **Функции (Functions)** — ~50 tasks. Function declaration/definition, parameters by value vs by reference, default arguments, overloading, recursion, scope and lifetime, intro to pointers, intro to references.
4. **Память и указатели (Memory & pointers)** — ~40 tasks. Pointers in depth, pointer arithmetic, dynamic memory (`new`/`delete`), common memory bugs (dangling pointers, leaks — taught conceptually with detection via sanitizer flags in `compiler_service.py`, e.g. `-fsanitize=address`), intro to smart pointers (`unique_ptr`, `shared_ptr`).
5. **ООП (OOP)** — ~60 tasks. Classes, constructors/destructors, encapsulation, `this`, static members, inheritance, polymorphism and virtual functions, abstract classes/interfaces, operator overloading.
6. **Графика и визуальные задачи (Graphics with SFML)** — ~25-30 tasks. This is the new block driven by the user's request. Starts simple (open an empty window, change background color), progresses to drawing single shapes, combining shapes into simple figures (the "draw a horse" type task — composed of circles/rectangles/triangles), basic animation (move a shape across the screen using the game loop and a velocity variable), simple keyboard input handling (move a shape with arrow keys), and a small capstone (e.g. "bouncing ball" or "simple drawing canvas where mouse clicks place shapes"). Document clearly in each task's JSON which SFML APIs are expected.
7. **STL и продвинутые темы (STL & intermediate topics)** — ~50 tasks. `std::vector` in depth, `std::map`/`unordered_map`, `std::set`, iterators, lambda expressions, basic algorithms (`sort`, `find`, `count` from `<algorithm>`), exception handling (`try`/`catch`/`throw`), file I/O (`fstream`).
8. **Джуниор-проекты (Junior-level capstone projects)** — ~15-20 larger tasks, each combining multiple prior topics into a small complete program (e.g., simple text-based inventory system, simple calculator with error handling, simple contact book with file persistence, simple SFML mini-game combining graphics + input + basic game state). These should feel like "things you'd be asked to build in a junior interview or first weeks of a job," explicitly bridging the gap from "knows the syntax" to "can build something."

Within each block, order lessons by strict prerequisite dependency — never introduce a concept in a task before its lesson has been presented.

### 4.2 Lesson JSON schema (`content/lessons/*.json`)

Each lesson file must contain (all user-facing strings in Russian):
```json
{
  "lesson_id": "block1_lesson4",
  "block_id": "block1",
  "order_in_block": 4,
  "title": "Переменные и типы данных",
  "estimated_minutes": 15,
  "theory_blocks": [
    {
      "type": "text",
      "content": "Russian explanation, written at an absolute-beginner ('explain like I'm in first grade') reading level: short sentences, concrete everyday analogies (e.g. comparing a variable to a labeled box), no unexplained jargon — if a technical term must be introduced, define it in the same sentence in plain words."
    },
    {
      "type": "code_example",
      "code": "C++ code snippet demonstrating the concept",
      "explanation": "Russian line-by-line or block-level explanation of what this example does and why"
    }
  ],
  "key_takeaways": ["short Russian bullet points summarizing the lesson"],
  "common_mistakes": ["Russian descriptions of mistakes beginners typically make on this topic, used both for theory and to seed error_dictionary.py patterns"],
  "task_ids": ["list of task_id strings belonging to this lesson, in suggested order"]
}
```

**Writing style requirement for all theory_blocks text**: explicitly enforce the "first-grader" explanation style the user requested. Use analogies to physical, everyday objects. Prefer short sentences. Introduce one new idea per paragraph. Always show a tiny concrete example immediately after an abstract explanation, never leave an abstract definition unillustrated.

### 4.3 Task JSON schema (`content/tasks/*.json`)

Two task types: `"output_match"` (the large majority) and `"sfml_rubric"` (Block 6 + relevant capstones).

`output_match` type:
```json
{
  "task_id": "block1_task12",
  "lesson_id": "block1_lesson4",
  "type": "output_match",
  "difficulty": 1,
  "title": "Russian short title",
  "prompt": "Russian task description, clear and concrete, stating exactly what the program must read as input (if any) and print as output, including exact formatting expectations (e.g. 'no trailing space', 'print on a single line')",
  "starter_code": "C++ skeleton code shown in the editor when the user opens this task, with a clear // TODO comment in Russian showing where to write code",
  "test_cases": [
    {"stdin": "", "expected_stdout": "exact expected output string"},
    {"stdin": "5\n", "expected_stdout": "..."}
  ],
  "comparison_mode": "exact | trim_trailing_whitespace | normalize_whitespace",
  "hints": ["Russian hint 1 (gentle nudge)", "Russian hint 2 (more specific)", "Russian hint 3 (near-complete guidance, still not the full answer)"],
  "reference_solution": "a correct C++ solution, used only internally — never shown to the user unless they explicitly request 'показать решение' after attempting and failing, and even then show it behind a confirmation dialog warning that seeing the answer reduces learning"
}
```

`sfml_rubric` type:
```json
{
  "task_id": "block6_task08",
  "lesson_id": "block6_lesson3",
  "type": "sfml_rubric",
  "difficulty": 3,
  "title": "Нарисуй коня из простых фигур",
  "prompt": "Russian description: open a window of at least 600x400, draw a recognizable horse-like figure using at least 4 different SFML shape objects (combination of sf::RectangleShape, sf::CircleShape, sf::ConvexShape, etc.), the window must stay open until closed by the user (proper main loop with event polling), background should be a single solid color of the student's choice",
  "starter_code": "minimal SFML boilerplate: includes, window creation, empty main loop, comment markers in Russian showing where to add drawing code",
  "rubric_checks": [
    {"id": "creates_window", "description_ru": "Создаёт окно через sf::RenderWindow", "check_type": "regex_source", "pattern": "sf::RenderWindow"},
    {"id": "has_event_loop", "description_ru": "Есть цикл обработки событий с pollEvent", "check_type": "regex_source", "pattern": "pollEvent"},
    {"id": "min_shapes", "description_ru": "Используется минимум 4 фигуры", "check_type": "count_regex", "pattern": "sf::(CircleShape|RectangleShape|ConvexShape|Sprite)", "min_count": 4},
    {"id": "calls_draw", "description_ru": "Каждая фигура отрисовывается через window.draw", "check_type": "count_regex", "pattern": "window\\.draw", "min_count": 4},
    {"id": "calls_display", "description_ru": "Окно обновляется через window.display", "check_type": "regex_source", "pattern": "window\\.display"},
    {"id": "compiles_and_runs", "description_ru": "Программа успешно компилируется и запускается без падения в первые 2 секунды", "check_type": "runtime"}
  ],
  "hints": ["Russian hints"],
  "reference_solution": "a working reference solution"
}
```

`task_checker.py` must implement a generic rubric engine reading `check_type` values (`regex_source` = pattern found anywhere in submitted source; `count_regex` = pattern must match at least `min_count` times; `runtime` = the program must compile and, when launched, must not crash within a short observation window — note SFML programs open a window and block, so the runtime check should launch the process, wait ~2 seconds, check it is still running and didn't crash/exit with an error code, then terminate it programmatically since we cannot make a human visually confirm the drawing automatically). Be explicit in code comments that fully automated verification of "does this actually look like a horse" is out of scope — the rubric checks structural/API-usage correctness, and the AI-written summary (section 4.4) should explicitly tell the user the visual result is something they should judge themselves by actually looking at the window that opens.

### 4.4 Mini-report after task submission

After every task submission (both types), generate a Russian-language mini-report shown in `ui/report_view.py`, containing:
- **Результат**: pass/fail (for `output_match`) or a checklist with ✓/✗ per rubric item (for `sfml_rubric`).
- **Чистота кода (code cleanliness)**: a small set of deterministic, non-AI static checks run on every submission regardless of pass/fail — e.g. consistent indentation (detect mixed tabs/spaces), presence of at least minimal comments for tasks above difficulty 2, no obviously dead/commented-out code left in, reasonable variable naming (not single letters except loop counters, flagged as a soft suggestion not an error), line length within a reasonable limit. Score this as a simple 1-5 rating with a short Russian explanation of what was checked, NOT as a blocking gate — it never affects the pass/fail result, it's purely informative ("твой код работает правильно, и вот несколько советов как сделать его чище").
- **Объяснение от ИИ** (only generated on request via a button "Объяснить результат", not automatically on every submission, to conserve free-tier API calls): a short Russian paragraph from the Groq AI summarizing what went right/wrong in plain language, referencing the already-computed rubric/test results — the AI must be instructed never to contradict or re-judge the deterministic result, only explain it.
- **Время решения и количество попыток** for this task, pulled from `progress_db.py`.

---

## 5. PROGRESS DATABASE SCHEMA (`progress_db.py`, SQLite)

Design and implement at minimum these tables (exact column types up to you, but capture this information):

- `lessons_progress`: lesson_id, status (`not_started`/`in_progress`/`completed`), first_opened_at, completed_at, time_spent_seconds.
- `task_attempts`: attempt_id (PK), task_id, lesson_id, submitted_at (timestamp), passed (bool), submitted_code (full text, for history/review), compiler_errors (nullable text), rubric_results_json (nullable, for sfml tasks), attempt_number (sequential per task).
- `task_status`: task_id, lesson_id, best_status (`not_attempted`/`failed`/`passed`), passed_at (nullable), total_attempts.
- `error_log`: timestamp, task_id (nullable), raw_error_text, matched_tier1_pattern_id (nullable), used_ai_fallback (bool) — used both for the "common mistakes" stats feature (section 7) and for future debugging of the error dictionary's coverage gaps.
- `daily_activity`: date, lessons_opened_count, tasks_attempted_count, tasks_passed_count, total_time_seconds, ai_calls_made_count — one row per calendar day, incrementally updated, used directly by the dashboard (section 7).
- `app_settings`: key-value table for things like the Groq API key reference (store only a reference/flag that it's configured; actual key lives in a local config file or OS keychain — investigate using the `keyring` pip package so the raw API key is not sitting in plaintext SQLite), selected AI model name, UI theme preference, last_opened_lesson_id (for the "continue where you left off" feature), onboarding_completed (bool).

Implement a single function `get_resume_point()` that returns the most recent `in_progress` lesson, or the next `not_started` lesson in curriculum order if none is in progress, used to drive the "Продолжить с того места, где остановился" button shown prominently on app launch.

---

## 6. AI SYSTEM PROMPT (THE PROMPT THAT GOES INTO ai_client.py, SENT TO GROQ)

Write, inside `ai_client.py`, a system prompt (in English is fine for this internal instruction-to-the-model, since the constraint is about its OUTPUT language, not the system prompt's own language — but you may also write it in Russian if you judge that improves output reliability with a small/weak model; test both and pick whichever the available Groq model follows more reliably) that enforces, at minimum:
- **Absolute requirement: respond only in Russian.** State this multiple times in the prompt for redundancy, since small/fast models are more prone to drifting into English, especially when the input (compiler errors, C++ keywords) is in English. Explicitly say: "Even though the code, error messages, and technical terms you are shown are in English, your entire response to the user must be written in Russian. Technical terms and keywords (like `int`, `nullptr`, `segmentation fault`) may remain in their original English/technical form since that's standard practice even in Russian-language programming education, but all surrounding explanation, sentences, and grammar must be Russian."
- The model is a teaching assistant for a complete beginner — explain like to a first-grader: short sentences, everyday analogies, define any term it uses.
- The model must NEVER declare a task correct or incorrect — that has already been determined by deterministic code; the model only explains the already-given result.
- The model must not paste a full corrected solution unless the user's message explicitly asks to see the answer/solution (look for Russian phrases like "покажи решение", "дай ответ" in the conversation) — otherwise it should explain the concept and point toward the bug without writing the complete fix.
- Keep responses short — 3-6 sentences for a typical error explanation, longer only if explicitly asked for more detail, to keep free-tier token usage low and responses fast.
- If the model is unsure or the question is outside C++ teaching scope, it should say so honestly in Russian rather than guessing.

Also implement, in `ai_client.py`, a lightweight Russian-language output validator: after receiving the AI response, run a cheap heuristic check (e.g. detect if a large proportion of the response consists of common English stop-words / Latin-alphabet sentences that aren't code) — if the response appears to have drifted into English, either retry once with a stronger reminder appended to the prompt, or fall back to a static Russian message: "ИИ-помощник сейчас ответил не на русском языке. Попробуй нажать кнопку ещё раз." Never show an English AI response to the user.

---

## 7. DASHBOARD / "FISHKI" FEATURES (`ui/dashboard_view.py`)

Build a dashboard screen, accessible from the main navigation, containing (all Russian labels):
- **Отчёт за сегодня (today's report)**: lessons opened today, tasks attempted/passed today, total active time today, a short auto-generated (non-AI, template-based) Russian sentence like "Сегодня ты решил {N} задач и провёл за обучением {M} минут. Так держать!" with the template varying based on whether today's numbers beat the user's recent average (encouraging tone either way — never shame low activity, always be supportive per the wellbeing-friendly tone the rest of this Russian-language app should maintain).
- **Прогресс за неделю (weekly progress)**: a simple bar chart (7 bars, one per day, e.g. using Flet's built-in charting or a simple custom-drawn bar visualization) of tasks completed per day for the last 7 days, plus a weekly total and a comparison to the previous week ("На 3 задачи больше, чем на прошлой неделе").
- **Общий прогресс (overall course progress)**: percentage of total tasks completed across the whole course, broken down per block (8 blocks from section 4.1) as a progress bar per block.
- **Серия дней (streak)**: consecutive days with at least one task attempted, shown prominently, since this is a strong habit-forming mechanic — but be careful per Russian-language tone requirements to never guilt-trip the user if a streak breaks; the broken-streak message should be neutral/encouraging, e.g. "Серия прервалась, но прогресс никуда не делся — начни новую сегодня!", never something punitive.
- **Типичные ошибки (common mistakes)**: a small list, derived from `error_log` table (section 5), of the user's most frequently triggered Tier-1 error patterns, presented as "вот на что стоит обратить внимание" with a link back to the relevant lesson theory for each.

This entire dashboard must compute purely from local SQLite queries — zero AI calls, so it's always instant and always free to view as often as the user likes.

---

## 8. RUSSIAN LANGUAGE ENFORCEMENT — ENGINEERING PRACTICE

To make the "strictly Russian" requirement actually enforceable and maintainable rather than just a wish:
- Centralize ALL user-facing strings (UI labels, button text, static messages — not lesson/task content, which already lives in its own JSON files per section 4) in a single `ui/strings_ru.py` module as a flat dictionary or set of named constants, e.g. `BTN_RUN = "Запустить"`. Never hardcode a literal UI string inline inside a Flet component file. This is both a maintainability practice and a way for you (or the user, with help) to later audit for any stray non-Russian string that slipped in.
- Add a small `tests/test_no_english_strings.py` pytest check that scans all `content/lessons/*.json` and `content/tasks/*.json` files for any field meant to be Russian (title, prompt, theory text, hints, etc.) and flags (does not necessarily hard-fail the build, but warns loudly) any value containing a suspiciously high ratio of Latin-alphabet words outside of recognized code/technical-term exceptions (build a small allowlist of expected English technical terms: `int`, `string`, `vector`, `nullptr`, `SFML`, class/function names, etc.). This is a heuristic safety net, not a perfect guarantee, but catches accidental English creeping into content authored later.
- When you (Opus) generate any of the lesson or task JSON content yourself as part of building this app, you must write that content in Russian directly — do not write it in English "as a placeholder to translate later." There is no later step in this pipeline that translates; if it's written in English, it ships in English.

---

## 9. INSTALLATION / ONBOARDING WIZARD (`ui/onboarding_view.py`)

On first launch (track via `app_settings.onboarding_completed`), before showing the main app, walk the user through, all in Russian, with friendly first-grader-level explanations and exact copy-pasteable commands where relevant:
1. **Compiler check**: attempt to run `g++ --version` via subprocess. If found, show a green confirmation with the detected version. If not found, show OS-specific Russian installation instructions (detect OS via Python's `platform` module) with a button to open the correct download page, and a "Проверить снова" button to re-check after they've installed it. Do not let them proceed to the main app without a working compiler, since literally nothing else works without it.
2. **SFML check**: attempt a tiny test compilation of a minimal SFML "include and create a window object, don't run it" snippet, to verify both that SFML headers are found AND that linking succeeds. If it fails, show OS-specific installation instructions and the exact linker flags that will be used (transparency, even though the user won't understand the flags themselves, builds trust that this isn't a black box). This step CAN be skipped/postponed ("Настроить позже") since SFML is only needed starting from Block 6 — make clear in Russian that this can be done later when they reach the graphics block, and the app should re-check automatically when the user opens a Block 6 lesson if it was skipped.
3. **Groq API key entry**: a text field (masked, like a password field) where the user pastes their Groq API key, with a short Russian explanation of what it's for ("нужен только чтобы ИИ помогал объяснять сложные ошибки — без него приложение тоже работает, просто без подсказок ИИ"), a link/button explaining where to get a free key if they don't have one yet (Groq's console URL), a "Проверить ключ" button that makes one trivial test API call to confirm it works, and explicit messaging that this step is optional and skippable — the app must be fully usable (compiling, running, checking tasks, viewing theory, tracking progress) with zero AI configured, only losing the Tier-2 error explanation fallback and the on-demand "explain more" features.

---

## 10. NON-FUNCTIONAL REQUIREMENTS

- **Visual polish**: this must look like a professional, intentional product, not a quick prototype. Use `ui/theme.py` to define a cohesive dark theme (the user will spend hours in this; default to dark, VS-Code-like, with a light theme toggle as a nice-to-have if time permits), consistent spacing, a real icon for the app window, smooth transitions between lesson navigation where Flet supports it easily.
- **Resilience**: the app must never crash to a blank screen or terminal traceback visible to the user. Wrap all subprocess calls, file I/O, and AI calls in try/except with a friendly Russian fallback message. Log full technical details to a local log file (`logs/app.log`) for later debugging, but never show a raw Python traceback in the UI.
- **Offline-first**: every feature except the on-demand AI explanation and Tier-2 error fallback must work with zero internet connection. Test this explicitly: disconnect network, confirm lessons, code editor, compilation, task checking, progress tracking, and dashboard all still work.
- **Performance**: compilation + execution of a typical small task should complete and show results in well under 2 seconds on typical hardware (excluding SFML windowed tasks, which by nature stay open until closed). If a user's code has an infinite loop, the execution timeout (section 3, `compiler_service.py`) must kill it and report a clear Russian message ("Программа выполнялась слишком долго — возможно, в коде есть бесконечный цикл") rather than hanging the UI.
- **Testing**: write pytest tests for `compiler_service.py` (valid code compiles+runs correctly; code with a syntax error returns the expected error; infinite loop triggers timeout), `task_checker.py` (output_match exact/trim/normalize modes; sfml_rubric regex and count checks against sample source strings), `error_dictionary.py` (each of the ~40 patterns matches its intended sample g++ error string and produces non-empty Russian output), and `progress_db.py` (writes and reads round-trip correctly, `get_resume_point()` returns expected lesson under various seeded states).
- **Packaging**: at the end, document (in the developer-facing README, can be English, plus a simplified Russian end-user version) the exact steps to produce a distributable executable using `flet pack` or PyInstaller, so the user can eventually have a real double-clickable app rather than running `python main.py` from a terminal every time — though running from terminal during development/early use is acceptable and you should tell the user clearly how to do that too (exact command, exact working directory) since they don't know command-line basics.

---

## 11. WORKING AGREEMENT WITH THE HUMAN (REPEAT THIS BACK TO THEM AT THE START)

Before writing any code, restate this plan back to the human in a short Russian-language summary (since the human only reads Russian comfortably) confirming you understood: the tech stack, the 15-step build order from section 3, the 8-block/300-400-task curriculum scope, and the AI-fallback-only design philosophy. Then proceed one numbered step at a time from section 3's build order, stopping after each step to let the human confirm it actually runs on their machine before continuing — they are not a programmer and cannot debug silently in the background, so do not batch multiple unverified steps together.

When the human reports an error after testing a step, ask them to paste the exact full error text (do not let them paraphrase it), and treat that error as the top-priority thing to fix before any new feature work continues.
