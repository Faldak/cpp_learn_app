"""
compiler_service.py
===================
Thin, safe wrapper around the system C++ compiler (g++ / clang++) using
subprocess. Responsible for:

  - Detecting an available compiler.
  - Compiling a C++ source string to a temporary executable.
  - Running that executable with a stdin string, capturing stdout/stderr/exit
    code, enforcing a wall-clock timeout (catches infinite loops) and an output
    size cap.
  - Supporting SFML linker flags (per-OS, from config) for graphical tasks.
  - Supporting AddressSanitizer flags for the memory-bugs block.
  - A special "launch and observe" run mode for SFML windowed programs, which
    block forever: launch, watch ~2s, confirm not crashed, then terminate.

Everything that can fail is wrapped; callers get a structured CompileRunResult,
never an exception bubbling into the UI.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import config


# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------
@dataclass
class CompileResult:
    ok: bool
    compiler_stderr: str = ""
    compiler_stdout: str = ""
    executable_path: Optional[str] = None
    command: list[str] = field(default_factory=list)


@dataclass
class RunResult:
    ran: bool                 # process actually started
    timed_out: bool = False   # killed by our timeout
    crashed: bool = False     # non-zero exit / signal
    exit_code: Optional[int] = None
    stdout: str = ""
    stderr: str = ""
    duration_seconds: float = 0.0


@dataclass
class CompileRunResult:
    """Combined result of compile (+ optional run)."""
    compiled: bool
    compile_error: str = ""
    ran: bool = False
    timed_out: bool = False
    crashed: bool = False
    exit_code: Optional[int] = None
    stdout: str = ""
    stderr: str = ""
    duration_seconds: float = 0.0
    command: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Compiler detection
# ---------------------------------------------------------------------------
_detected_compiler: Optional[str] = None


def detect_compiler() -> Optional[str]:
    """Return the path/name of the first available compiler, or None."""
    global _detected_compiler
    if _detected_compiler:
        return _detected_compiler
    for cand in config.COMPILER_CANDIDATES:
        path = shutil.which(cand)
        if path:
            _detected_compiler = path
            return path
    return None


def compiler_version() -> Optional[str]:
    comp = detect_compiler()
    if not comp:
        return None
    try:
        out = subprocess.run(
            [comp, "--version"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return (out.stdout or out.stderr).splitlines()[0].strip()
    except Exception:
        return None


def _exe_suffix() -> str:
    return ".exe" if config.is_windows() else ""


# ---------------------------------------------------------------------------
# Compilation
# ---------------------------------------------------------------------------
def compile_source(
    source: str,
    *,
    use_sfml: bool = False,
    use_sanitizer: bool = False,
    workdir: Optional[Path] = None,
) -> CompileResult:
    """Compile a C++ source string. Returns CompileResult (does not run)."""
    comp = detect_compiler()
    if not comp:
        return CompileResult(
            ok=False,
            compiler_stderr="NO_COMPILER",  # callers map this to a RU install guide
        )

    cleanup = False
    if workdir is None:
        workdir = Path(tempfile.mkdtemp(prefix="cpp_build_"))
        cleanup = False  # keep so the executable can be run; caller/OS cleans temp
    workdir.mkdir(parents=True, exist_ok=True)

    src_path = workdir / "main.cpp"
    exe_path = workdir / f"program{_exe_suffix()}"
    try:
        src_path.write_text(source, encoding="utf-8")
    except Exception as e:  # pragma: no cover
        return CompileResult(ok=False, compiler_stderr=f"WRITE_ERROR: {e}")

    cmd: list[str] = [comp, f"-std={config.CPP_STANDARD}", str(src_path), "-o", str(exe_path)]
    if use_sanitizer and not config.is_windows():
        # ASan is unreliable on stock MinGW; only enable off-Windows.
        cmd[1:1] = config.SANITIZER_FLAGS
    if use_sfml:
        cmd += config.get_sfml_flags()

    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=config.COMPILE_TIMEOUT_SECONDS,
            cwd=str(workdir),
        )
    except subprocess.TimeoutExpired:
        return CompileResult(
            ok=False,
            compiler_stderr="COMPILE_TIMEOUT",
            command=cmd,
        )
    except Exception as e:  # pragma: no cover
        return CompileResult(ok=False, compiler_stderr=f"COMPILE_EXCEPTION: {e}", command=cmd)

    ok = proc.returncode == 0 and exe_path.exists()
    return CompileResult(
        ok=ok,
        compiler_stderr=proc.stderr or "",
        compiler_stdout=proc.stdout or "",
        executable_path=str(exe_path) if ok else None,
        command=cmd,
    )


# ---------------------------------------------------------------------------
# Running
# ---------------------------------------------------------------------------
def run_executable(
    exe_path: str,
    *,
    stdin: str = "",
    timeout: Optional[float] = None,
) -> RunResult:
    """Run a compiled console program with a timeout and output cap."""
    timeout = timeout if timeout is not None else config.RUN_TIMEOUT_SECONDS
    start = time.monotonic()
    try:
        proc = subprocess.run(
            [exe_path],
            input=stdin,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired as e:
        out = e.stdout or ""
        if isinstance(out, bytes):
            out = out.decode("utf-8", "replace")
        return RunResult(
            ran=True,
            timed_out=True,
            stdout=_cap(out),
            duration_seconds=time.monotonic() - start,
        )
    except Exception as e:  # pragma: no cover
        return RunResult(ran=False, stderr=f"RUN_EXCEPTION: {e}")

    return RunResult(
        ran=True,
        crashed=proc.returncode != 0,
        exit_code=proc.returncode,
        stdout=_cap(proc.stdout or ""),
        stderr=_cap(proc.stderr or ""),
        duration_seconds=time.monotonic() - start,
    )


def observe_windowed(
    exe_path: str,
    *,
    observe_seconds: Optional[float] = None,
) -> RunResult:
    """
    Launch an SFML/windowed program that would block forever, watch it for a
    short window, confirm it didn't crash/exit early, then terminate it.
    Used by the sfml_rubric 'runtime' check.
    """
    observe = observe_seconds if observe_seconds is not None else config.SFML_RUNTIME_OBSERVE_SECONDS
    start = time.monotonic()
    try:
        proc = subprocess.Popen(
            [exe_path],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
    except Exception as e:  # pragma: no cover
        return RunResult(ran=False, stderr=f"LAUNCH_EXCEPTION: {e}")

    time.sleep(observe)
    rc = proc.poll()
    if rc is None:
        # Still alive after observation window -> good (it opened a window).
        proc.terminate()
        try:
            proc.wait(timeout=3)
        except Exception:
            proc.kill()
        return RunResult(
            ran=True,
            crashed=False,
            exit_code=None,
            duration_seconds=time.monotonic() - start,
        )

    # Exited early within the observation window.
    out, err = "", ""
    try:
        out, err = proc.communicate(timeout=2)
    except Exception:
        pass
    return RunResult(
        ran=True,
        crashed=rc != 0,
        exit_code=rc,
        stdout=_cap(out or ""),
        stderr=_cap(err or ""),
        duration_seconds=time.monotonic() - start,
    )


# ---------------------------------------------------------------------------
# Convenience: compile + run a console program in one call
# ---------------------------------------------------------------------------
def compile_and_run(
    source: str,
    *,
    stdin: str = "",
    use_sanitizer: bool = False,
    run_timeout: Optional[float] = None,
) -> CompileRunResult:
    cr = compile_source(source, use_sanitizer=use_sanitizer)
    if not cr.ok:
        return CompileRunResult(
            compiled=False,
            compile_error=cr.compiler_stderr,
            command=cr.command,
        )
    rr = run_executable(cr.executable_path, stdin=stdin, timeout=run_timeout)
    return CompileRunResult(
        compiled=True,
        ran=rr.ran,
        timed_out=rr.timed_out,
        crashed=rr.crashed,
        exit_code=rr.exit_code,
        stdout=rr.stdout,
        stderr=rr.stderr,
        duration_seconds=rr.duration_seconds,
        command=cr.command,
    )


def _cap(text: str) -> str:
    data = text.encode("utf-8", "replace")
    if len(data) > config.MAX_OUTPUT_BYTES:
        data = data[: config.MAX_OUTPUT_BYTES]
        return data.decode("utf-8", "replace") + "\n…(вывод обрезан)"
    return text


# ---------------------------------------------------------------------------
# Manual smoke test: `python compiler_service.py`
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    print("compiler:", detect_compiler(), "|", compiler_version())
    demo = (
        "#include <iostream>\n"
        "int main(){ int n; std::cin>>n; std::cout<<n*2; return 0; }\n"
    )
    res = compile_and_run(demo, stdin="21\n")
    print(res)


# ---------------------------------------------------------------------------
# SFML availability detection (used by onboarding + settings)
# ---------------------------------------------------------------------------
_SFML_AVAILABLE: Optional[bool] = None


def detect_sfml(force: bool = False) -> bool:
    """Return True if a tiny SFML program compiles+links with current flags.

    Result is cached. Pass force=True to re-test (e.g. after user installs SFML).
    """
    global _SFML_AVAILABLE
    if _SFML_AVAILABLE is not None and not force:
        return _SFML_AVAILABLE
    if not detect_compiler():
        _SFML_AVAILABLE = False
        return False
    # Version-agnostic probe: sf::CircleShape(float) exists identically in
    # SFML 2.x AND 3.x, so this compiles+links regardless of installed version.
    # (Do NOT use sf::VideoMode/sf::Event here — their API changed in SFML 3.)
    probe = (
        "#include <SFML/Graphics.hpp>\n"
        "int main(){ sf::CircleShape c(10.f); c.setRadius(5.f); return 0; }\n"
    )
    res = compile_source(probe, use_sfml=True)
    _SFML_AVAILABLE = bool(res.ok)
    return _SFML_AVAILABLE
