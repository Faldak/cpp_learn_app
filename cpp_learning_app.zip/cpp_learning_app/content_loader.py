"""
content_loader.py
=================
Loads the course structure, lessons and tasks from content/*.json and provides
convenient lookups for the UI. Pure data; no AI.
"""

from __future__ import annotations

import json
from functools import lru_cache
from typing import Optional

import config


@lru_cache(maxsize=1)
def course_structure() -> dict:
    if not config.COURSE_STRUCTURE_FILE.exists():
        return {"blocks": []}
    return json.loads(config.COURSE_STRUCTURE_FILE.read_text(encoding="utf-8"))


@lru_cache(maxsize=1)
def _lesson_index() -> dict:
    out = {}
    for f in sorted(config.LESSONS_DIR.glob("*.json")):
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            out[data["lesson_id"]] = data
        except Exception:
            continue
    return out


@lru_cache(maxsize=1)
def _task_index() -> dict:
    out = {}
    for f in sorted(config.TASKS_DIR.glob("*.json")):
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            out[data["task_id"]] = data
        except Exception:
            continue
    return out


def blocks() -> list[dict]:
    return course_structure().get("blocks", [])


def get_lesson(lesson_id: str) -> Optional[dict]:
    return _lesson_index().get(lesson_id)


def get_task(task_id: str) -> Optional[dict]:
    return _task_index().get(task_id)


def lessons_for_block(block_id: str) -> list[dict]:
    out = [l for l in _lesson_index().values() if l.get("block_id") == block_id]
    return sorted(out, key=lambda l: l.get("order_in_block", 0))


def ordered_lesson_ids() -> list[str]:
    ids: list[str] = []
    for b in blocks():
        for l in lessons_for_block(b["block_id"]):
            ids.append(l["lesson_id"])
    return ids


def tasks_for_lesson(lesson_id: str) -> list[dict]:
    lesson = get_lesson(lesson_id)
    if not lesson:
        return []
    out = []
    for tid in lesson.get("task_ids", []):
        t = get_task(tid)
        if t:
            out.append(t)
    return out


def all_task_ids() -> list[str]:
    return list(_task_index().keys())


def task_ids_for_block(block_id: str) -> list[str]:
    ids = []
    for l in lessons_for_block(block_id):
        ids.extend(l.get("task_ids", []))
    return ids


def total_task_count() -> int:
    return len(_task_index())


def reset_cache() -> None:
    course_structure.cache_clear()
    _lesson_index.cache_clear()
    _task_index.cache_clear()
